-- ============================================================================
--  FLUX License Server — схема Cloudflare D1 (SQLite на edge)
--
--  Зеркалит license_server/store.py, чтобы можно было перенести существующую
--  базу с твоего ПК без изменения логики (см. deploy/migrate_from_sqlite.py).
--
--  Применение:
--     npx wrangler d1 execute flux-licenses --remote --file=deploy/schema.sql
--
--  ВАЖНО про лимиты D1 (free: 5 млн чтений и 100 тыс записей строк/день):
--  каждый запрос клиента — это несколько row-reads. Поэтому:
--    * client_polls пишется НЕ на каждый опрос, а только при смене часа
--      (см. worker/src/poll.js) — иначе 1500 клиентов съели бы лимит записей;
--    * audit — единственная по-настоящему растущая таблица, её чистит
--      cron-триггер (deploy/wrangler.toml).
-- ============================================================================

-- сам ключ: хранится ТОЛЬКО sha256-хеш, при утечке базы ключи не восстанавливаются
CREATE TABLE IF NOT EXISTS licenses (
    key_hash        TEXT PRIMARY KEY,
    key_id          TEXT NOT NULL,
    plan            TEXT NOT NULL DEFAULT 'standard',
    customer        TEXT DEFAULT '',
    note            TEXT DEFAULT '',
    issued_at       INTEGER NOT NULL,
    expires_at      INTEGER NOT NULL DEFAULT 0,
    max_activations INTEGER NOT NULL DEFAULT 1,
    offline_days    INTEGER NOT NULL DEFAULT 14,
    status          TEXT NOT NULL DEFAULT 'inactive',
    revoked_at      INTEGER,
    revoke_reason   TEXT DEFAULT '',
    revoke_kind     TEXT DEFAULT '',
    last_seen       INTEGER
);
CREATE INDEX IF NOT EXISTS idx_lic_status ON licenses(status);
CREATE INDEX IF NOT EXISTS idx_lic_key_id ON licenses(key_id);

-- устройства, на которых ключ активирован (HWID + варианты отпечатка)
CREATE TABLE IF NOT EXISTS activations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    key_hash     TEXT NOT NULL,
    hwid         TEXT NOT NULL,
    hwid_label   TEXT DEFAULT '',
    variants     TEXT DEFAULT '[]',
    activated_at INTEGER NOT NULL,
    last_seen    INTEGER NOT NULL,
    ticket_exp   INTEGER NOT NULL DEFAULT 0,
    released     INTEGER NOT NULL DEFAULT 0,
    app_version  TEXT DEFAULT '',
    UNIQUE(key_hash, hwid)
);
CREATE INDEX IF NOT EXISTS idx_act_key ON activations(key_hash);

-- журнал действий: выдача, активация, отказ, отзыв, удаление
CREATE TABLE IF NOT EXISTS audit (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      INTEGER NOT NULL,
    key_id  TEXT DEFAULT '',
    action  TEXT NOT NULL,
    hwid    TEXT DEFAULT '',
    ip      TEXT DEFAULT '',
    detail  TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts DESC);

-- сколько клиентов активно прямо сейчас: по этой цифре сервер дозирует
-- интервал опроса (рандом 5-72ч), чтобы не напрягать систему зря
CREATE TABLE IF NOT EXISTS poll_buckets (
    bucket      INTEGER PRIMARY KEY,   -- unixtime / 3600, то есть час
    clients     INTEGER NOT NULL DEFAULT 0,
    hwid_hashes TEXT NOT NULL DEFAULT '[]'   -- JSON-массив коротких хешей за этот час
);
CREATE INDEX IF NOT EXISTS idx_poll_bucket ON poll_buckets(bucket);

-- окна рейт-лимита (60 секунд каждое).
-- В Workers нет общей памяти между запросами: два запроса могут попасть на разные
-- edge-серверы, поэтому in-memory-словарь из license_server/server.py здесь не
-- работает. Считаем в D1. Таблицу чистит cron-триггер (deploy/wrangler.toml) —
-- иначе она растёт бесконечно.
--
-- Это НЕ защита от перебора ключей (ключ = 19 случайных символов из алфавита 30,
-- перебор нереален). Смысл в том, чтобы один зациклившийся клиент не съел квоту
-- D1, от которой зависят все остальные покупатели.
CREATE TABLE IF NOT EXISTS rl (
    bucket INTEGER NOT NULL,   -- unixtime / 60
    ip     TEXT NOT NULL,
    action TEXT NOT NULL,
    n      INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (bucket, ip, action)
);
