// Доступ к D1 (SQLite на edge). Логика повторяет license_server/store.py, чтобы
// существующие ключи и активации переносились без изменения поведения.
//
// Про лимиты D1 (free: 5 млн row-reads и 100 тыс row-writes в день):
//   * каждый запрос клиента старается обойтись ОДНИМ чтением лицензии;
//   * last_seen обновляется не на каждый опрос, а не чаще раза в час
//     (см. shouldTouch) — иначе 1500 клиентов исчерпали бы лимит записей;
//   * audit пишется только на значимые события (выдача, активация, отказ,
//     удаление), а не на каждый успешный опрос.

export const ST_INACTIVE = 'inactive';
export const ST_ACTIVE = 'active';
export const ST_REVOKED = 'revoked';
export const ST_EXPIRED = 'expired';

export const RK_DELETED = 'deleted';
export const RK_SUSPENDED = 'suspended';

// не обновлять last_seen чаще, чем раз в столько секунд
const TOUCH_THROTTLE = 3600;

export function now() { return Math.floor(Date.now() / 1000); }

export async function q(DB, sql, ...bind) {
  const r = await DB.prepare(sql).bind(...bind).first();
  return r || null;
}

export async function all(DB, sql, ...bind) {
  const r = await DB.prepare(sql).bind(...bind).all();
  return r.results || [];
}

export async function run(DB, sql, ...bind) {
  return DB.prepare(sql).bind(...bind).run();
}

// ------------------------------------------------------------------- аудит
export async function audit(DB, action, keyId = '', hwid = '', ip = '', detail = '') {
  try {
    await run(DB,
      'INSERT INTO audit(ts,key_id,action,hwid,ip,detail) VALUES(?,?,?,?,?,?)',
      now(), String(keyId).slice(0, 32), String(action).slice(0, 32),
      String(hwid).slice(0, 64), String(ip).slice(0, 64), String(detail).slice(0, 400));
  } catch (e) {
    // журнал не должен ронять основной запрос
    console.error('audit failed:', e && e.message);
  }
}

export async function auditLog(DB, limit = 100, keyId = '') {
  const sql = keyId
    ? 'SELECT * FROM audit WHERE key_id=? ORDER BY ts DESC LIMIT ?'
    : 'SELECT * FROM audit ORDER BY ts DESC LIMIT ?';
  const bind = keyId ? [keyId, Number(limit)] : [Number(limit)];
  return all(DB, sql, ...bind);
}

// ------------------------------------------------------------------ лицензии
export async function getByHash(DB, kh) {
  return q(DB, 'SELECT * FROM licenses WHERE key_hash=?', kh);
}

export async function getById(DB, kid) {
  return q(DB, 'SELECT * FROM licenses WHERE key_id=?', String(kid || '').toUpperCase());
}

export async function issue(DB, { plan = 'standard', customer = '', note = '',
                                  expiresAt = 0, maxActivations = 1, offlineDays = 14,
                                  key = null, keyHashFn, makeKeyFn }) {
  let k = key;
  if (!k) {
    for (let i = 0; i < 8; i++) {
      const cand = makeKeyFn();
      if (!(await getByHash(DB, await keyHashFn(cand)))) { k = cand; break; }
    }
  }
  if (!k) throw new Error('не удалось сгенерировать уникальный ключ');
  const kh = await keyHashFn(k);
  if (await getByHash(DB, kh)) throw new Error('такой ключ уже выпущен (коллизия)');
  const kid = (await keyHashFn(k)).slice(0, 12).toUpperCase();
  await run(DB,
    `INSERT INTO licenses(key_hash,key_id,plan,customer,note,issued_at,expires_at,
                          max_activations,offline_days,status)
     VALUES(?,?,?,?,?,?,?,?,?,?)`,
    kh, kid, plan, customer, note, now(), Number(expiresAt),
    Number(maxActivations), Number(offlineDays), ST_INACTIVE);
  await audit(DB, 'issue', kid, '', '', `plan=${plan} customer=${customer}`);
  const rec = await getByHash(DB, kh);
  return { ...rec, key: k };
}

export async function listAll(DB, status = '', limit = 500) {
  const rows = status
    ? await all(DB, 'SELECT * FROM licenses WHERE status=? ORDER BY issued_at DESC LIMIT ?', status, Number(limit))
    : await all(DB, 'SELECT * FROM licenses ORDER BY issued_at DESC LIMIT ?', Number(limit));
  for (const r of rows) r.activations = await activations(DB, r.key_hash, true);
  return rows;
}

export async function countBy(DB, status = '') {
  const r = status
    ? await q(DB, 'SELECT COUNT(*) AS n FROM licenses WHERE status=?', status)
    : await q(DB, 'SELECT COUNT(*) AS n FROM licenses');
  return Number((r && r.n) || 0);
}

// ------------------------------------------------------------------- статусы
export async function revoke(DB, keyId, reason = '', kind = RK_SUSPENDED) {
  const rec = await getById(DB, keyId);
  if (!rec) return null;
  await run(DB,
    'UPDATE licenses SET status=?, revoked_at=?, revoke_reason=?, revoke_kind=? WHERE key_hash=?',
    ST_REVOKED, now(), String(reason).slice(0, 400), kind, rec.key_hash);
  await audit(DB, kind === RK_DELETED ? 'delete' : 'revoke', keyId, '', '',
              `kind=${kind} reason=${String(reason).slice(0, 200)}`);
  return getByHash(DB, rec.key_hash);
}

// удалить ключ навсегда: блокировка + освобождение ВСЕХ устройств
export async function deleteKey(DB, keyId, reason = '') {
  const rec = await getById(DB, keyId);
  if (!rec) return null;
  const n = await releaseAll(DB, rec.key_hash);
  const out = await revoke(DB, keyId, reason, RK_DELETED);
  await audit(DB, 'delete_devices', keyId, '', '', `освобождено устройств: ${n}`);
  return out;
}

export async function suspend(DB, keyId, reason = '') {
  return revoke(DB, keyId, reason, RK_SUSPENDED);
}

export async function unrevoke(DB, keyId) {
  const rec = await getById(DB, keyId);
  if (!rec) return null;
  const acts = await activations(DB, rec.key_hash, true);
  const st = acts.length ? ST_ACTIVE : ST_INACTIVE;
  await run(DB,
    "UPDATE licenses SET status=?, revoked_at=NULL, revoke_reason='', revoke_kind='' WHERE key_hash=?",
    st, rec.key_hash);
  await audit(DB, 'unrevoke', keyId, '', '', `-> ${st}`);
  return getByHash(DB, rec.key_hash);
}

export async function extend(DB, keyId, days) {
  const rec = await getById(DB, keyId);
  if (!rec) return null;
  const base = Math.max(Number(rec.expires_at || 0), now());
  const exp = Number(days) <= 0 ? 0 : base + Number(days) * 86400;
  await run(DB,
    "UPDATE licenses SET expires_at=?, status=CASE WHEN status='expired' THEN 'active' ELSE status END WHERE key_hash=?",
    exp, rec.key_hash);
  await audit(DB, 'extend', keyId, '', '', `+${days} дней -> ${exp || 'бессрочно'}`);
  return getByHash(DB, rec.key_hash);
}

export async function setPlan(DB, keyId, plan) {
  const rec = await getById(DB, keyId);
  if (!rec) return null;
  await run(DB, 'UPDATE licenses SET plan=? WHERE key_hash=?', plan, rec.key_hash);
  await audit(DB, 'set_plan', keyId, '', '', plan);
  return getByHash(DB, rec.key_hash);
}

// ------------------------------------------------------------------ активации
export async function activations(DB, keyHash, activeOnly = true) {
  return activeOnly
    ? all(DB, 'SELECT * FROM activations WHERE key_hash=? AND released=0 ORDER BY activated_at', keyHash)
    : all(DB, 'SELECT * FROM activations WHERE key_hash=? ORDER BY activated_at', keyHash);
}

// ищем совпадение по любому варианту отпечатка: замена сетевой карты или диска
// не должна сбрасывать активацию (см. app/hwid.py)
export async function findActivation(DB, keyHash, variants) {
  const acts = await activations(DB, keyHash, false);
  const want = new Set([String(variants[0] || ''), ...(variants || [])].filter(Boolean));
  for (const a of acts) {
    if (want.has(a.hwid)) return a;
    let vs = [];
    try { vs = JSON.parse(a.variants || '[]'); } catch (e) { vs = []; }
    for (const v of vs) if (want.has(v)) return a;
  }
  return null;
}

export async function addActivation(DB, keyHash, hwid, variants, label = '',
                                    ticketExp = 0, appVersion = '') {
  await run(DB,
    `INSERT INTO activations(key_hash,hwid,hwid_label,variants,activated_at,last_seen,ticket_exp,released,app_version)
     VALUES(?,?,?,?,?,?,?,0,?)
     ON CONFLICT(key_hash,hwid) DO UPDATE SET
       hwid_label=excluded.hwid_label, variants=excluded.variants,
       last_seen=excluded.last_seen, ticket_exp=excluded.ticket_exp,
       released=0, app_version=excluded.app_version`,
    keyHash, hwid, String(label).slice(0, 120), JSON.stringify(variants || []),
    now(), now(), Number(ticketExp), String(appVersion).slice(0, 32));
}

export async function moveActivation(DB, keyHash, oldHwid, newHwid, variants,
                                     label = '', ticketExp = 0, appVersion = '') {
  await run(DB, 'UPDATE activations SET released=1 WHERE key_hash=? AND hwid=?', keyHash, oldHwid);
  await addActivation(DB, keyHash, newHwid, variants, label, ticketExp, appVersion);
  return true;
}

export async function touchActivation(DB, keyHash, hwid) {
  await run(DB, 'UPDATE activations SET last_seen=? WHERE key_hash=? AND hwid=?',
            now(), keyHash, hwid);
}

export async function releaseActivation(DB, keyHash, hwid) {
  const r = await run(DB, 'UPDATE activations SET released=1 WHERE key_hash=? AND hwid=?',
                      keyHash, hwid);
  return Number((r.meta && r.meta.changes) || 0) > 0;
}

export async function releaseAll(DB, keyHash) {
  const r = await run(DB, 'UPDATE activations SET released=1 WHERE key_hash=? AND released=0', keyHash);
  return Number((r.meta && r.meta.changes) || 0);
}

export async function refreshStatus(DB, rec) {
  if (!rec) return rec;
  if (rec.status === ST_REVOKED) return rec;
  const exp = Number(rec.expires_at || 0);
  const acts = await activations(DB, rec.key_hash, true);
  let st;
  if (exp && now() > exp) st = ST_EXPIRED;
  else if (acts.length) st = ST_ACTIVE;
  else st = ST_INACTIVE;
  if (st !== rec.status) {
    await run(DB, 'UPDATE licenses SET status=? WHERE key_hash=?', st, rec.key_hash);
    return getByHash(DB, rec.key_hash);
  }
  return rec;
}

// last_seen лицензии обновляем не чаще раза в час: это экономит row-writes D1
export function shouldTouch(rec) {
  return !rec.last_seen || (now() - Number(rec.last_seen)) > TOUCH_THROTTLE;
}

export async function touchLicense(DB, keyHash) {
  await run(DB, 'UPDATE licenses SET last_seen=? WHERE key_hash=?', now(), keyHash);
}

// ------------------------------------------------------------------- сводка
export async function stats(DB) {
  const [total, inactive, active, revoked, expired] = await Promise.all([
    countBy(DB), countBy(DB, ST_INACTIVE), countBy(DB, ST_ACTIVE),
    countBy(DB, ST_REVOKED), countBy(DB, ST_EXPIRED),
  ]);
  const dev = await q(DB, 'SELECT COUNT(*) AS n FROM activations WHERE released=0');
  const del = await q(DB, 'SELECT COUNT(*) AS n FROM licenses WHERE status=? AND revoke_kind=?',
                      ST_REVOKED, RK_DELETED);
  const sus = await q(DB,
    "SELECT COUNT(*) AS n FROM licenses WHERE status=? AND (revoke_kind IS NULL OR revoke_kind='' OR revoke_kind=?)",
    ST_REVOKED, 'revoked');
  const last = await q(DB, 'SELECT MAX(ts) AS m FROM audit');
  return {
    total, inactive, active, revoked, expired,
    deleted: Number((del && del.n) || 0),
    suspended: Number((sus && sus.n) || 0),
    devices: Number((dev && dev.n) || 0),
    last_event: last ? last.m : null,
  };
}

// ------------------------------------------------- сколько клиентов онлайн
// По этой цифре сервер дозирует интервал опроса (рандом 5-72ч): чем больше
// активных клиентов, тем длиннее интервал у каждого, чтобы не напрягать систему.
export async function activeClients(DB) {
  const since = now() - 6 * 3600;
  const r = await q(DB, 'SELECT COUNT(*) AS n FROM activations WHERE released=0 AND last_seen>?', since);
  return Number((r && r.n) || 0);
}

export async function pruneOldBuckets(DB) {
  await run(DB, 'DELETE FROM poll_buckets WHERE bucket < ?', Math.floor(now() / 3600) - 48);
}

export async function pruneAudit(DB, keepDays = 90) {
  await run(DB, 'DELETE FROM audit WHERE ts < ?', now() - keepDays * 86400);
}
