// Веб-админка Worker'а. Один HTML-файл строкой, без внешних зависимостей:
// в Workers нельзя отдать FileResponse с диска, а CDN-скрипты означали бы, что
// панель не работает при отсутствии интернета у админа.
//
// Логика и тексты совпадают с license_server/admin.html: те же две кнопки
// блокировки («Удалить ключ» навсегда и «Отозвать» на неопределённое время),
// тот же предпросмотр причины, который дословно увидит покупатель.
//
// Дополнительно — карточка «Нагрузка»: сколько клиентов активно сейчас, какой
// интервал опроса сервер им выдаёт и какой прогноз по квоте D1. Это видно сразу,
// без расчётов в уме.

export function renderAdmin(env) {
  const fp = escapeHtml(env.VENDOR_FINGERPRINT || '(не задан)');
  return `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FLUX · лицензии (Cloudflare)</title>
<style>
:root{--bg:#0f1115;--panel:#171a21;--panel2:#1e222b;--line:#2a2f3a;--fg:#e6e8ee;
  --mut:#9aa3b2;--acc:#5cc8ff;--ok:#3ecf8e;--warn:#ffb454;--err:#ff6b6b}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
  font:14px/1.5 -apple-system,Segoe UI,Roboto,Ubuntu,sans-serif}
header{display:flex;gap:14px;align-items:center;padding:14px 20px;
  border-bottom:1px solid var(--line);background:var(--panel);flex-wrap:wrap}
h1{font-size:17px;margin:0;font-weight:600}
h1 small{color:var(--mut);font-weight:400;font-size:12px;margin-left:8px}
.spacer{flex:1}
button,input,select{font:inherit;color:inherit;background:var(--panel2);
  border:1px solid var(--line);border-radius:7px;padding:6px 11px}
button{cursor:pointer}
button:hover{border-color:var(--acc)}
button.primary{background:#1d3a52;border-color:#2c5a7d}
button.danger{background:#3a1f1f;border-color:#6b2c2c}
button.warn{background:#3a2f1a;border-color:#6b5228}
button.ok{background:#1c3a2b;border-color:#2c6b45}
button:disabled{opacity:.5;cursor:progress}
main{padding:18px 20px;max-width:1500px;margin:0 auto}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.card .n{font-size:26px;font-weight:600}
.card .l{color:var(--mut);font-size:12px;margin-top:2px}
.card.rev .n{color:var(--err)} .card.act .n{color:var(--ok)}
.card.ina .n{color:var(--warn)} .card.exp .n{color:var(--mut)}
section{background:var(--panel);border:1px solid var(--line);border-radius:10px;
  padding:14px 16px;margin-bottom:18px}
section>h2{font-size:14px;margin:0 0 12px;color:var(--mut);text-transform:uppercase;
  letter-spacing:.06em}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:7px 9px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--mut);font-weight:500;font-size:12px;position:sticky;top:0;background:var(--panel)}
tr:hover td{background:#1b1f28}
.badge{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11.5px;
  border:1px solid var(--line)}
.badge.active{color:var(--ok);border-color:#2c6b45;background:#14281e}
.badge.inactive{color:var(--warn);border-color:#6b5228;background:#28200f}
.badge.revoked{color:var(--err);border-color:#6b2c2c;background:#2a1616}
.badge.expired{color:var(--mut)}
.mono{font-family:Consolas,Menlo,monospace;font-size:12px}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.row label{color:var(--mut);font-size:12.5px}
.grow{flex:1}
#log{font-family:Consolas,monospace;font-size:12px;white-space:pre-wrap;
  background:#0b0d11;border:1px solid var(--line);border-radius:8px;padding:10px;
  max-height:220px;overflow:auto;color:#9fe3a0}
.devices{color:var(--mut);font-size:12px;margin-top:4px}
#gate{max-width:460px;margin:12vh auto;background:var(--panel);border:1px solid var(--line);
  border-radius:12px;padding:22px}
#gate input{width:100%;margin:10px 0;padding:10px;font-family:Consolas,monospace}
.err{color:var(--err)}
.hide{display:none}
.keybox{background:#14281e;border:1px solid #2c6b45;border-radius:8px;padding:12px;margin-top:10px}
.keybox .k{font-family:Consolas,monospace;font-size:17px;letter-spacing:.05em;color:var(--ok);
  word-break:break-all}
.hint{color:var(--mut);font-size:12px;margin-top:6px}
#bmOv{position:fixed;inset:0;background:#000b;display:flex;align-items:flex-start;
  justify-content:center;padding:26px;z-index:50;overflow-y:auto}
#bmBox{background:var(--panel);border:1px solid var(--line);border-radius:12px;
  width:560px;max-width:96vw;padding:22px;border-left:3px solid var(--err)}
#bmBox h2{margin:0 0 4px;font-size:17px}
#bmBox .sub{color:var(--mut);font-size:12.5px;font-family:Consolas,monospace;margin-bottom:12px}
.bmwarn{font-size:13px;line-height:1.55;background:#2a1616;border:1px solid #6b2c2c;
  border-radius:8px;padding:11px 13px;margin-bottom:6px}
.bmwarn:not(.hard){background:#2a2416;border-color:#6b5a2c}
.bmwarn code{display:block;margin-top:6px;color:#ffc9c9;font-family:Consolas,monospace;
  font-size:12.5px;background:#00000040;border-radius:5px;padding:5px 7px;word-break:break-word}
.lbl{display:block;font-size:12.5px;color:var(--mut);margin-top:12px}
#bmReason,#bmCustom{width:100%;margin-top:6px}
#bmPrev{margin-top:14px;font-size:12px;color:var(--mut)}
#bmPrevText{font-family:Consolas,monospace;font-size:12.5px;color:var(--fg);
  background:#0b0d11;border:1px solid var(--line);border-radius:6px;padding:8px 10px;
  word-break:break-word;white-space:pre-wrap;margin-top:5px}
#bmErr{color:var(--err);font-size:12.5px;margin-top:10px;min-height:16px}
table.load{font-size:12.5px}
table.load td,table.load th{padding:5px 8px}
.ok-mark{color:var(--ok)} .bad-mark{color:var(--err)}
</style>
</head>
<body>

<div id="gate">
  <h1 style="margin-bottom:6px">FLUX · лицензии</h1>
  <div class="hint" style="margin-bottom:12px">Сервер работает на Cloudflare Workers,
    поэтому не зависит от того, включён ли твой компьютер. Введи токен администратора
    — он задан секретом <code>ADMIN_TOKEN</code> в настройках Worker'а.</div>
  <input id="tok" type="password" placeholder="токен админки" autocomplete="off">
  <div class="row">
    <label><input type="checkbox" id="remember" checked> запомнить в этом браузере</label>
    <div class="spacer"></div>
    <button class="primary" id="loginBtn">Войти</button>
  </div>
  <div id="gateErr" class="err" style="margin-top:10px"></div>
</div>

<div id="app" class="hide">
<header>
  <h1>FLUX · лицензии <small id="fp">публичный ключ вендора ${fp}</small></h1>
  <div class="spacer"></div>
  <div class="row">
    <select id="fStatus">
      <option value="">все статусы</option>
      <option value="active">активные</option>
      <option value="inactive">не активированы</option>
      <option value="revoked">заблокированы</option>
      <option value="expired">истекли</option>
    </select>
    <input id="fSearch" placeholder="поиск: id, клиент, примечание" style="min-width:230px">
    <button id="refreshBtn">⟳ Обновить</button>
    <button id="logoutBtn">Выйти</button>
  </div>
</header>

<main>
  <div class="cards" id="cards"></div>

  <section>
    <h2>Нагрузка и дозирование опроса</h2>
    <div class="row" id="loadNow" style="margin-bottom:10px"></div>
    <table class="load">
      <thead><tr><th>клиентов</th><th>интервал опроса</th><th>опросов/день</th>
        <th>D1 чтений/день</th><th>% квоты</th><th>D1 записей/день</th><th>% квоты</th>
        <th>трафик</th></tr></thead>
      <tbody id="loadRows"></tbody>
    </table>
    <div class="hint">Интервал выдаётся клиенту случайно в пределах ступени (±25%),
      чтобы все не пришли одновременно. Билет живёт дольше максимального интервала,
      поэтому честный клиент не блокируется из-за того, что сервер велел ему «спать».</div>
  </section>

  <section>
    <h2>Выдать ключ</h2>
    <div class="row">
      <label>план
        <select id="nPlan">
          <option value="standard">standard</option>
          <option value="pro">pro</option>
          <option value="ultimate">ultimate</option>
          <option value="trial">trial</option>
        </select>
      </label>
      <label>дней <input id="nDays" type="number" value="0" style="width:80px" title="0 = бессрочно"></label>
      <label>устройств <input id="nDev" type="number" value="1" min="1" style="width:70px"></label>
      <label>офлайн, дней <input id="nOff" type="number" value="5" min="1" style="width:70px"
        title="окно обратного отсчёта; должно быть больше максимального интервала опроса"></label>
      <label>клиент <input id="nCust" placeholder="почта или имя" style="min-width:190px"></label>
      <label>сколько <input id="nCount" type="number" value="1" min="1" max="500" style="width:70px"></label>
      <label>примечание <input id="nNote" placeholder="счёт, заказ" style="min-width:150px"></label>
      <button class="ok" id="issueBtn">Выдать</button>
    </div>
    <div id="issued"></div>
    <div class="hint">Ключ показывается ОДИН раз: в базе хранится только его sha256-хеш.
      Скопируй и отправь покупателю сразу.</div>
  </section>

  <section>
    <h2>Лицензии</h2>
    <div style="max-height:52vh;overflow:auto">
    <table>
      <thead><tr>
        <th>id</th><th>статус</th><th>план</th><th>клиент</th><th>выдан</th>
        <th>действует до</th><th>устройства</th><th>последний контакт</th><th>действия</th>
      </tr></thead>
      <tbody id="rows"></tbody>
    </table>
    </div>
  </section>

  <section>
    <h2>Журнал</h2>
    <div class="row" style="margin-bottom:8px">
      <label>записей <input id="aLimit" type="number" value="60" style="width:80px"></label>
      <label>фильтр <input id="aFilter" placeholder="key_id или действие" style="min-width:180px"></label>
      <button id="auditBtn">Показать</button>
    </div>
    <div id="log">—</div>
  </section>
</main>
</div>

<div id="bmOv" class="hide">
  <div id="bmBox">
    <h2 id="bmTitle">Удалить ключ</h2>
    <div class="sub">ключ <span id="bmId"></span></div>
    <div class="bmwarn" id="bmWarn"></div>
    <label class="lbl" for="bmReason">Причина — её дословно увидит покупатель в окне активации
      <select id="bmReason"></select>
    </label>
    <div id="bmCustomRow" class="hide">
      <label class="lbl" for="bmCustom">Своя причина
        <input id="bmCustom" maxlength="200" placeholder="например: ключ передан третьим лицам">
      </label>
    </div>
    <div id="bmPrev"><b>Так это будет выглядеть у пользователя:</b>
      <div id="bmPrevText"></div></div>
    <div id="bmErr"></div>
    <div class="row" style="justify-content:flex-end;margin-top:14px">
      <button id="bmCancel">Отмена</button>
      <button id="bmOk" class="danger">Удалить ключ</button>
    </div>
  </div>
</div>

<script>
const $ = id => document.getElementById(id);
let TOK = localStorage.getItem('flux_admin_token') || '';
let CACHE = [];

// тексты блокировки — те же формулировки, что в app/license_fmt.py и в воркере.
// Держим их здесь дословно, чтобы предпросмотр не врал.
const TITLES = {
  deleted: 'Этот ключ доступа был удалён',
  suspended: 'Этот ключ доступа отозван на неопределённое время',
};
function revokeMessage(kind, reason) {
  const k = kind === 'deleted' ? 'deleted' : 'suspended';
  const r = String(reason || '').trim();
  if (k === 'suspended' && !r) return TITLES[k];
  if (r) return TITLES[k] + '. Причина: ' + r;
  return TITLES[k] + (k === 'deleted'
    ? '. Причина не указана разработчиком.'
    : '. Ключ приостановлен до решения разработчика.');
}

async function api(path, body) {
  const opt = { headers: { 'Authorization': 'Bearer ' + TOK } };
  if (body !== undefined) {
    opt.method = 'POST'; opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(body);
  }
  const r = await fetch(path, opt);
  const d = await r.json().catch(() => ({ ok: false, message: 'HTTP ' + r.status }));
  if (!r.ok && !d.ok) throw new Error(d.message || ('HTTP ' + r.status));
  return d;
}

const fmtDate = ts => ts ? new Date(ts * 1000).toLocaleDateString('ru-RU') : 'бессрочно';
const fmtDt = ts => ts ? new Date(ts * 1000).toLocaleString('ru-RU',
  { day:'2-digit', month:'2-digit', year:'2-digit', hour:'2-digit', minute:'2-digit' }) : '—';
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g,
  c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));

async function login() {
  TOK = $('tok').value.trim();
  $('gateErr').textContent = '';
  if (!TOK) { $('gateErr').textContent = 'введи токен'; return; }
  try {
    await loadStats();
    if ($('remember').checked) localStorage.setItem('flux_admin_token', TOK);
    $('gate').classList.add('hide'); $('app').classList.remove('hide');
    await refresh();
  } catch (e) { $('gateErr').textContent = 'не пускает: ' + e.message; TOK = ''; }
}

async function loadStats() {
  const d = await api('/admin/api/stats');
  const s = d.stats;
  $('fp').textContent = 'публичный ключ вендора ' + (d.key_fingerprint || '') +
    ' · активно клиентов: ' + (d.active_clients || 0);
  $('cards').innerHTML = [
    ['Всего лицензий', s.total, ''], ['Активны', s.active, 'act'],
    ['Не активированы', s.inactive, 'ina'], ['Заблокированы', s.revoked, 'rev'],
    ['  из них удалено', s.deleted, 'rev'], ['  из них приостановлено', s.suspended, 'ina'],
    ['Истекли', s.expired, 'exp'], ['Привязано устройств', s.devices, ''],
  ].map(([l, n, c]) => '<div class="card ' + c + '"><div class="n">' + n +
    '</div><div class="l">' + l + '</div></div>').join('');

  const p = d.poll || {};
  $('loadNow').innerHTML =
    '<div class="card" style="flex:1"><div class="n">' + (d.active_clients || 0) + '</div>' +
    '<div class="l">клиентов активно сейчас (отметились за 6 ч)</div></div>' +
    '<div class="card" style="flex:1"><div class="n">' +
      ((p.next_check_in_seconds || 0) / 3600).toFixed(1) + ' ч</div>' +
    '<div class="l">интервал опроса, который сервер выдаёт сейчас</div></div>' +
    '<div class="card" style="flex:1"><div class="n">' + (p.ticket_ttl_hours || 0) + ' ч</div>' +
    '<div class="l">живёт билет (обратный отсчёт у покупателя)</div></div>' +
    '<div class="card" style="flex:1"><div class="n">' + (p.min_hours || 0) + '–' + (p.max_hours || 0) + ' ч</div>' +
    '<div class="l">допустимый диапазон интервала</div></div>';
  $('loadRows').innerHTML = (p.forecast || []).map(f => {
    const ro = f.d1_read_pct_of_free > 80, wo = f.d1_write_pct_of_free > 80;
    return '<tr><td>' + f.clients + '</td><td>' + f.interval_hours + ' ч</td>' +
      '<td>' + f.polls_per_day.toLocaleString('ru-RU') + '</td>' +
      '<td>' + f.d1_reads_per_day.toLocaleString('ru-RU') + '</td>' +
      '<td class="' + (ro ? 'bad-mark' : 'ok-mark') + '">' + f.d1_read_pct_of_free + '%</td>' +
      '<td>' + f.d1_writes_per_day.toLocaleString('ru-RU') + '</td>' +
      '<td class="' + (wo ? 'bad-mark' : 'ok-mark') + '">' + f.d1_write_pct_of_free + '%</td>' +
      '<td>' + f.mb_per_month + ' МБ/мес</td></tr>';
  }).join('');
}

async function refresh() {
  await loadStats();
  const st = $('fStatus').value;
  const d = await api('/admin/api/licenses?limit=500' + (st ? '&status=' + st : ''));
  CACHE = d.licenses || [];
  render();
}

function render() {
  const q = $('fSearch').value.trim().toLowerCase();
  const rows = CACHE.filter(r => !q ||
    (r.key_id + ' ' + (r.customer || '') + ' ' + (r.note || '')).toLowerCase().includes(q));
  $('rows').innerHTML = rows.map(r => {
    const acts = (r.activations || []).filter(a => !a.released);
    const dev = acts.length ? acts.map(a =>
      '<div class="devices mono">' + esc(a.hwid.slice(0, 16).toUpperCase()) + '… ' +
      fmtDt(a.last_seen) + (a.hwid_label ? ' · ' + esc(a.hwid_label) : '') + '</div>').join('')
      : '<div class="devices">не привязан</div>';
    const note = r.status === 'revoked'
      ? '<div class="devices" style="color:var(--err)">' +
        (r.revoke_kind === 'deleted' ? '✕ удалён' : '⏸ приостановлен') +
        (r.revoke_reason ? ': ' + esc(r.revoke_reason) : '') + '</div>' : '';
    const acts2 = r.status !== 'revoked'
      ? '<button class="danger" data-a="delete" data-id="' + esc(r.key_id) +
          '" title="Удалить ключ навсегда: все устройства освобождаются, вернуть нельзя">Удалить ключ</button>' +
        '<button class="warn" data-a="suspend" data-id="' + esc(r.key_id) +
          '" title="Отозвать на неопределённое время: можно вернуть кнопкой «Вернуть»">Отозвать</button>'
      : '<button class="ok" data-a="restore" data-id="' + esc(r.key_id) +
          '" data-kind="' + esc(r.revoke_kind || '') + '" title="' +
          (r.revoke_kind === 'deleted'
            ? 'Ключ был УДАЛЁН — восстановление вернёт его как приостановленный'
            : 'Снять блокировку') + '">' +
          (r.revoke_kind === 'deleted' ? 'Восстановить' : 'Вернуть') + '</button>';
    return '<tr>' +
      '<td class="mono">' + esc(r.key_id) + '</td>' +
      '<td><span class="badge ' + esc(r.status) + '">' + esc(r.status) + '</span>' + note + '</td>' +
      '<td>' + esc(r.plan) + '</td>' +
      '<td>' + (esc(r.customer) || '<span class="devices">—</span>') +
        (r.note ? '<div class="devices">' + esc(r.note) + '</div>' : '') + '</td>' +
      '<td>' + fmtDt(r.issued_at) + '</td><td>' + fmtDate(r.expires_at) + '</td>' +
      '<td>' + acts.length + '/' + r.max_activations + dev + '</td>' +
      '<td>' + fmtDt(r.last_seen) + '</td>' +
      '<td><div class="row">' +
        '<button data-a="extend" data-id="' + esc(r.key_id) + '" title="продлить на 90 дней">+90д</button>' +
        '<button data-a="release" data-id="' + esc(r.key_id) + '" title="освободить все устройства">освоб.</button>' +
        acts2 +
      '</div></td></tr>';
  }).join('') || '<tr><td colspan="9" class="devices">ничего не найдено</td></tr>';
}

const REASONS = ['возврат средств', 'нарушение лицензионного соглашения',
  'подозрение на перепродажу ключа', 'ключ скомпрометирован (утечка)',
  'оплата не подтверждена', 'запрошено владельцем ключа'];

function openBlockModal(id, kind) {
  const deleted = kind === 'delete';
  $('bmId').textContent = id;
  $('bmTitle').textContent = deleted ? 'Удалить ключ' : 'Отозвать ключ';
  $('bmWarn').className = 'bmwarn' + (deleted ? ' hard' : '');
  $('bmWarn').innerHTML = deleted
    ? 'Ключ будет <b>удалён навсегда</b>. Все привязанные устройства освобождаются, '
      + 'приложение у покупателя блокируется. Пользователь увидит:'
      + '<code>' + esc(revokeMessage('deleted', '…')) + '</code>'
      + 'Отменить удаление нельзя — только выпустить новый ключ.'
    : 'Ключ будет <b>отозван на неопределённое время</b>. Приложение у покупателя '
      + 'блокируется, но блокировку можно снять кнопкой «Вернуть». Пользователь увидит:'
      + '<code>' + esc(revokeMessage('suspended', '')) + '</code>';
  $('bmReason').innerHTML = '<option value="">' + (deleted ? 'причина не указана' : 'без причины') + '</option>' +
    REASONS.map(v => '<option value="' + esc(v) + '">' + esc(v) + '</option>').join('') +
    '<option value="__custom__">своя причина…</option>';
  $('bmReason').value = '';
  $('bmCustom').value = '';
  $('bmCustomRow').classList.add('hide');
  $('bmOk').className = deleted ? 'danger' : 'warn';
  $('bmOk').textContent = deleted ? 'Удалить ключ' : 'Отозвать';
  $('bmOk').dataset.id = id; $('bmOk').dataset.kind = kind;
  $('bmErr').textContent = '';
  $('bmOv').classList.remove('hide');
  updatePreview();
}
function currentReason() {
  const v = $('bmReason').value;
  return v === '__custom__' ? $('bmCustom').value.trim() : v;
}
function updatePreview() {
  const kind = $('bmOk').dataset.kind === 'delete' ? 'deleted' : 'suspended';
  $('bmPrevText').textContent = revokeMessage(kind, currentReason());
}
function closeBlockModal() { $('bmOv').classList.add('hide'); }

async function submitBlock() {
  const id = $('bmOk').dataset.id, kind = $('bmOk').dataset.kind;
  const reason = currentReason();
  if ($('bmReason').value === '__custom__' && !reason) {
    $('bmErr').textContent = 'введи свою причину или выбери готовую из списка'; return;
  }
  $('bmOk').disabled = true;
  try {
    const r = await api('/admin/api/' + kind, { key_id: id, reason });
    log(kind + ' ' + id + ' -> ' + (r.license ? r.license.status : 'ok') +
        (reason ? ' («' + reason + '»)' : ''));
    closeBlockModal(); await refresh();
  } catch (e) { $('bmErr').textContent = 'ошибка: ' + e.message; }
  finally { $('bmOk').disabled = false; }
}

async function action(a, id) {
  const body = { key_id: id };
  if (a === 'delete' || a === 'suspend') { openBlockModal(id, a); return; }
  if (a === 'restore') {
    const kind = (CACHE.find(r => r.key_id === id) || {}).revoke_kind || '';
    if (kind === 'deleted' && !confirm('Ключ ' + id + ' был УДАЛЁН навсегда.\\n' +
        'Восстановить его как приостановленный?\\nПокупателю придётся активировать ключ заново.')) return;
    a = 'unrevoke';
  }
  if (a === 'extend') {
    const d = prompt('Продлить на сколько дней? (0 = сделать бессрочной)', '90');
    if (d === null) return;
    body.days = parseInt(d, 10) || 0;
  }
  if (a === 'release' && !confirm('Освободить ВСЕ устройства у ' + id + '?\\n' +
      'Ключ можно будет активировать заново.')) return;
  try {
    const r = await api('/admin/api/' + a, body);
    log(a + ' ' + id + ' -> ' + (r.license ? r.license.status : 'ok'));
    await refresh();
  } catch (e) { alert('ошибка: ' + e.message); }
}

function log(t) {
  $('log').textContent = new Date().toLocaleTimeString('ru-RU') + '  ' + t + '\\n' + $('log').textContent;
}

async function issue() {
  try {
    const d = await api('/admin/api/issue', {
      plan: $('nPlan').value, days: parseInt($('nDays').value, 10) || 0,
      devices: parseInt($('nDev').value, 10) || 1, offline: parseInt($('nOff').value, 10) || 5,
      n: parseInt($('nCount').value, 10) || 1,
      customer: $('nCust').value.trim(), note: $('nNote').value.trim() });
    $('issued').innerHTML = (d.issued || []).map(k =>
      '<div class="keybox"><div class="k">' + esc(k.key) + '</div>' +
      '<div class="hint">id ' + esc(k.key_id) + ' · план ' + esc(k.plan) +
      ' · действует до ' + fmtDate(k.expires_at) +
      ' · окно отсчёта ' + (k.offline_days || '?') + ' дн</div></div>').join('');
    log('выдано ключей: ' + (d.issued || []).length);
    await refresh();
  } catch (e) { alert('ошибка выдачи: ' + e.message); }
}

async function audit() {
  try {
    const f = $('aFilter').value.trim();
    const d = await api('/admin/api/audit?limit=' + ($('aLimit').value || 60) +
                        (f ? '&key_id=' + encodeURIComponent(f) : ''));
    $('log').textContent = (d.records || []).map(r =>
      fmtDt(r.ts) + '  ' + String(r.action).padEnd(18) + ' ' + String(r.key_id || '').padEnd(14) +
      ' ' + String((r.hwid || '').slice(0, 12)).padEnd(13) + ' ' +
      String(r.ip || '').padEnd(15) + (r.detail || '')).join('\\n') || 'журнал пуст';
  } catch (e) { $('log').textContent = 'ошибка: ' + e.message; }
}

$('loginBtn').onclick = login;
$('tok').onkeydown = e => { if (e.key === 'Enter') login(); };
$('logoutBtn').onclick = () => { localStorage.removeItem('flux_admin_token'); location.reload(); };
$('refreshBtn').onclick = refresh;
$('fStatus').onchange = refresh;
$('fSearch').oninput = render;
$('issueBtn').onclick = issue;
$('auditBtn').onclick = audit;
$('bmCancel').onclick = closeBlockModal;
$('bmOk').onclick = submitBlock;
$('bmOv').addEventListener('mousedown', e => { if (e.target === $('bmOv')) closeBlockModal(); });
$('bmReason').onchange = () => {
  $('bmCustomRow').classList.toggle('hide', $('bmReason').value !== '__custom__');
  if ($('bmReason').value === '__custom__') $('bmCustom').focus();
  updatePreview();
};
$('bmCustom').oninput = updatePreview;
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('bmOv').classList.contains('hide')) closeBlockModal();
});
document.addEventListener('click', e => {
  const b = e.target.closest('button[data-a]');
  if (b) action(b.dataset.a, b.dataset.id);
});
if (TOK) { $('tok').value = TOK; login(); }
</script>
</body>
</html>
`;
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
