// Клиентское API: activate / ping / heartbeat / keystatus / deactivate.
//
// Wire-протокол совпадает с license_server/server.py, поэтому существующий клиент
// (app/licensing.py) работает против Workers без переделки. Отличия:
//   * добавлен /v1/ping — дешёвый опрос БЕЗ передачи билета (~325 Б за обмен);
//   * ответы содержат next_check_in — когда сервер велит прийти в следующий раз
//     (рандом 5-72ч в зависимости от числа активных клиентов);
//   * offline_until билета = 5 суток, то есть обратный отсчёт, который видит
//     пользователь: «5 дн -> 3 дн -> 1 дн -> 15 ч -> 0 -> окно активации».

import {
  extractKey, normalizeKey, keyHash, keyId, revokeInfo,
  makeTicket, ticketPayload, verifyPayload,
} from './crypto.mjs';
import * as S from './db.mjs';
import { json, err, readJson, clientIp, rateLimited, rlLimit } from './http.mjs';
import { nextCheckInSeconds, TICKET_TTL_H, humanizeLeft } from './sched.mjs';

// ctx = { privKey, pubKey } — импортированные CryptoKey, готовятся один раз на запрос
export async function handleActivate(request, env, ctx) {
  const DB = env.DB;
  const ip = clientIp(request);
  if (await rateLimited(DB, ip, 'activate', rlLimit(env, 'activate'))) {
    await S.audit(DB, 'rate_limit', '', '', ip, 'activate');
    return err('rate_limited', 'слишком много попыток активации. Подожди минуту.', 429);
  }
  const data = await readJson(request);
  const rawKey = String(data.key || '');
  // принимаем ключ, вставленный куском письма — как в клиентском окне активации
  const key = extractKey(rawKey) || normalizeKey(rawKey);
  if (!key) return err('invalid_key', 'ключ не прошёл проверку формата');

  const hwid = String(data.hwid || '').trim().toLowerCase();
  if (hwid.length < 16) return err('bad_hwid', 'не удалось снять отпечаток устройства');
  const variants = (data.hwid_variants || [])
    .map(v => String(v).trim().toLowerCase()).filter(Boolean);
  if (!variants.includes(hwid)) variants.unshift(hwid);

  const kh = await keyHash(key);
  let rec = await S.getByHash(DB, kh);
  const kid = await keyId(key);
  if (!rec) {
    await S.audit(DB, 'activate_unknown', kid, hwid, ip, 'ключ не найден в базе');
    return err('invalid_key', 'такого ключа не существует. Проверь, нет ли опечатки.', 404);
  }
  rec = await S.refreshStatus(DB, rec);

  if (rec.status === S.ST_REVOKED) {
    const info = revokeInfo(rec);
    await S.audit(DB, 'activate_denied', kid, hwid, ip, `${info.kind}: ${info.reason}`);
    return err('revoked', info.message || 'ключ заблокирован. Обратись к разработчику.', 403,
               { revoke: info });
  }
  if (rec.expires_at && S.now() > rec.expires_at) {
    await S.audit(DB, 'activate_denied', kid, hwid, ip, 'истёк срок');
    return err('expired', 'срок действия лицензии истёк', 403);
  }

  // --- привязка к устройству -------------------------------------------------
  const existing = await S.findActivation(DB, kh, variants);
  let migrated = false;
  if (existing && !existing.released && existing.hwid !== hwid) {
    // та же машина, изменился один компонент железа -> переносим место, а не
    // занимаем второе (иначе одна машина съела бы весь лимит активаций)
    await S.moveActivation(DB, kh, existing.hwid, hwid, variants,
                           String(data.hwid_label || '').slice(0, 120), 0,
                           String(data.app_version || '').slice(0, 32));
    migrated = true;
    await S.audit(DB, 'hwid_migrated', rec.key_id, hwid, ip,
                  `${existing.hwid.slice(0, 12)}… -> ${hwid.slice(0, 12)}…`);
  }
  if (!existing || existing.released) {
    const acts = await S.activations(DB, kh, true);
    if (acts.length >= Number(rec.max_activations)) {
      const others = acts.slice(0, 3)
        .map(a => a.hwid.slice(0, 12).toUpperCase() + '…').join(', ');
      await S.audit(DB, 'activate_denied', kid, hwid, ip,
                    `лимит устройств (${rec.max_activations}), занято: ${others}`);
      return err('already_bound',
        `ключ уже активирован на другом устройстве (${others}). ` +
        `Лицензия привязывается к одному компьютеру при первом вводе. ` +
        `Чтобы перенести: на старом устройстве нажми «Деактивировать» ` +
        `или попроси разработчика освободить место.`, 409,
        { bound: acts.map(a => ({ hwid: a.hwid, label: a.hwid_label || '',
                                  activated_at: a.activated_at })) });
    }
  }

  const clients = await S.activeClients(DB);
  const nextIn = nextCheckInSeconds(clients, rec.key_id);
  const offlineDays = Math.max(1, Number(rec.offline_days) || TICKET_TTL_H / 24);
  const ticket = await makeTicket(ctx.privKey, {
    key, hwid, plan: rec.plan, expires: Number(rec.expires_at || 0),
    offlineDays, customer: rec.customer || '', extra: { license: rec.key_id },
    nextCheckIn: nextIn,
  });

  if (migrated) await S.touchActivation(DB, kh, hwid);
  else await S.addActivation(DB, kh, hwid, variants,
        String(data.hwid_label || '').slice(0, 120),
        S.now() + offlineDays * 86400, String(data.app_version || '').slice(0, 32));
  await S.touchLicense(DB, kh);
  await S.audit(DB, 'activate', rec.key_id, hwid, ip,
                `plan=${rec.plan} offline=${offlineDays}d next=${nextIn}s clients=${clients}`);

  const ttl = offlineDays * 86400;
  return json({
    ok: true, ticket, plan: rec.plan, license_id: rec.key_id,
    expires: Number(rec.expires_at || 0),
    offline_until: ticketPayload(ticket).offline_until,
    // когда прийти снова и сколько живёт билет — по ним клиент рисует отсчёт
    next_check_in: nextIn,
    next_check_in_hours: +(nextIn / 3600).toFixed(1),
    ticket_ttl_hours: TICKET_TTL_H,
    seconds_left: ttl,
    left_human: humanizeLeft(ttl),
    heartbeat_hours: +(nextIn / 3600).toFixed(1),   // совместимость со старым клиентом
    hwid_migrated: migrated,
    active_clients: clients,
    message: migrated
      ? 'отпечаток устройства обновлён (изменился один компонент железа), место в лицензии сохранено'
      : 'лицензия активирована и привязана к этому устройству',
  });
}

// ЛЁГКИЙ опрос: жив ли ключ, сколько осталось, когда прийти снова.
// Билет не передаётся — в этом смысл: ~325 Б вместо ~856 Б за обмен.
export async function handlePing(request, env, ctx) {
  const DB = env.DB;
  const ip = clientIp(request);
  if (await rateLimited(DB, ip, 'ping', rlLimit(env, 'ping'))) {
    return err('rate_limited', 'слишком частые проверки', 429);
  }
  const data = await readJson(request);
  const kid = String(data.key_id || data.kid || '').toUpperCase();
  const key = extractKey(String(data.key || '')) || normalizeKey(String(data.key || ''));

  let rec = null;
  if (kid) rec = await S.getById(DB, kid);
  if (!rec && key) rec = await S.getByHash(DB, await keyHash(key));
  if (!rec) return err('invalid_key', 'лицензия не найдена', 404);

  rec = await S.refreshStatus(DB, rec);
  const clients = await S.activeClients(DB);
  const nextIn = nextCheckInSeconds(clients, rec.key_id);

  if (rec.status === S.ST_REVOKED) {
    const info = revokeInfo(rec);
    await S.audit(DB, 'ping_revoked', rec.key_id, '', ip, `${info.kind}: ${info.reason}`);
    // причина дословно — клиент показывает её в окне активации
    return json({ ok: false, revoked: true, blocked: true, revoke: info,
                  reason: info.reason_text, message: info.message,
                  next_check_in: nextIn }, 403);
  }
  const exp = Number(rec.expires_at || 0);
  if (exp && S.now() > exp) {
    return json({ ok: false, expired: true, blocked: true, next_check_in: nextIn,
                  message: 'срок действия лицензии истёк' }, 403);
  }

  // сколько осталось жить билету — из этого клиент рисует обратный отсчёт.
  // Берём из подписанного билета, а не «на глаз»: подделать число клиент не
  // может, оно внутри подписи вендора.
  const ticket = (data.ticket && typeof data.ticket === 'object') ? data.ticket : null;
  let leftSec = null;
  if (ticket) {
    const off = Number(ticketPayload(ticket).offline_until || 0);
    if (off) leftSec = Math.max(0, off - S.now());
  }

  // last_seen пишем не чаще раза в час — экономим row-writes D1
  if (S.shouldTouch(rec)) await S.touchLicense(DB, rec.key_hash);

  return json({
    ok: true, revoked: false, blocked: false, plan: rec.plan, key_id: rec.key_id,
    expires: exp,
    next_check_in: nextIn,
    next_check_in_hours: +(nextIn / 3600).toFixed(1),
    ticket_ttl_hours: TICKET_TTL_H,
    seconds_left: leftSec,
    left_human: leftSec == null ? null : humanizeLeft(leftSec),
    active_clients: clients,
    heartbeat_hours: +(nextIn / 3600).toFixed(1),
  });
}

// Полный heartbeat: проверка билета и перевыпуск. Дёргается РЕДКО (когда окно
// билета подходит к концу), поэтому может позволить себе передать билет.
export async function handleHeartbeat(request, env, ctx) {
  const DB = env.DB;
  const ip = clientIp(request);
  if (await rateLimited(DB, ip, 'heartbeat', rlLimit(env, 'heartbeat'))) {
    return err('rate_limited', 'слишком частые проверки', 429);
  }
  const data = await readJson(request);
  const hwid = String(data.hwid || '').trim().toLowerCase();
  const ticket = data.ticket || {};

  let rec = null;
  const raw = String(data.key || '');
  if (raw) {
    const k = extractKey(raw) || normalizeKey(raw);
    if (k) rec = await S.getByHash(DB, await keyHash(k));
  }
  if (!rec && ticket && typeof ticket === 'object') {
    const tKid = ticketPayload(ticket).kid;
    if (tKid) rec = await S.getById(DB, tKid);
  }
  if (!rec) return err('unknown', 'не удалось определить лицензию', 404);

  rec = await S.refreshStatus(DB, rec);
  if (rec.status === S.ST_REVOKED) {
    const info = revokeInfo(rec);
    await S.audit(DB, 'heartbeat_revoked', rec.key_id, hwid, ip, `${info.kind}: ${info.reason}`);
    return json({ ok: false, revoked: true, reason: info.reason_text,
                  revoke: info, message: info.message }, 403);
  }
  if (rec.expires_at && S.now() > rec.expires_at) {
    return json({ ok: false, expired: true, message: 'срок действия лицензии истёк' }, 403);
  }

  const clients = await S.activeClients(DB);
  const nextIn = nextCheckInSeconds(clients, rec.key_id);
  const offlineDays = Math.max(1, Number(rec.offline_days) || TICKET_TTL_H / 24);
  const payload = ticketPayload(ticket);

  const sigOk = (hwid && ctx.pubKey && ticket.sig)
    ? await verifyPayload(ctx.pubKey, payload, ticket.sig)
    : false;
  const valid = sigOk && payload.hwid === hwid;

  if (valid) {
    await S.touchActivation(DB, rec.key_hash, hwid);
    if (S.shouldTouch(rec)) await S.touchLicense(DB, rec.key_hash);
    const off = Number(payload.offline_until || 0);
    return json({ ok: true, revoked: false, plan: rec.plan,
                  expires: Number(rec.expires_at || 0),
                  seconds_left: off ? Math.max(0, off - S.now()) : null,
                  left_human: off ? humanizeLeft(Math.max(0, off - S.now())) : null,
                  next_check_in: nextIn, next_check_in_hours: +(nextIn / 3600).toFixed(1),
                  ticket_ttl_hours: TICKET_TTL_H,
                  heartbeat_hours: +(nextIn / 3600).toFixed(1) });
  }

  // билет недействителен (истекло окно, сменилось железо) -> перевыпуск, но
  // только если устройство уже зарегистрировано за этим ключом
  const variants = (data.hwid_variants || [])
    .map(v => String(v).trim().toLowerCase()).filter(Boolean);
  if (hwid && !variants.includes(hwid)) variants.unshift(hwid);
  const act = await S.findActivation(DB, rec.key_hash, variants);
  if (!act) {
    await S.audit(DB, 'heartbeat_denied', rec.key_id, hwid, ip, 'устройство не найдено');
    return err('not_activated',
      'это устройство не активировано данным ключом. Выполни активацию заново.', 403);
  }
  const newTicket = await makeTicket(ctx.privKey, {
    key: '', hwid: act.hwid, plan: rec.plan, expires: Number(rec.expires_at || 0),
    offlineDays, customer: rec.customer || '', extra: { license: rec.key_id },
    nextCheckIn: nextIn,
  });
  await S.addActivation(DB, rec.key_hash, act.hwid, variants, act.hwid_label || '',
                        S.now() + offlineDays * 86400,
                        String(data.app_version || '').slice(0, 32));
  await S.touchLicense(DB, rec.key_hash);
  await S.audit(DB, 'heartbeat_renew', rec.key_id, act.hwid, ip,
                `перевыпуск; next=${nextIn}s clients=${clients}`);
  const ttl = offlineDays * 86400;
  return json({ ok: true, revoked: false, renewed: true, ticket: newTicket,
                plan: rec.plan, expires: Number(rec.expires_at || 0),
                offline_until: ticketPayload(newTicket).offline_until,
                seconds_left: ttl, left_human: humanizeLeft(ttl),
                next_check_in: nextIn, next_check_in_hours: +(nextIn / 3600).toFixed(1),
                ticket_ttl_hours: TICKET_TTL_H,
                heartbeat_hours: +(nextIn / 3600).toFixed(1) });
}

export async function handleKeystatus(request, env) {
  const DB = env.DB;
  const ip = clientIp(request);
  if (await rateLimited(DB, ip, 'keystatus', rlLimit(env, 'keystatus'))) {
    return err('rate_limited', 'слишком много запросов — подожди минуту', 429);
  }
  const data = await readJson(request);
  const raw = String(data.key || '');
  const key = extractKey(raw) || normalizeKey(raw);
  if (!key) return err('invalid_key', 'ключ не прошёл проверку формата', 400,
                       { format_ok: false });

  const rec = await S.getByHash(DB, await keyHash(key));
  const kid = await keyId(key);
  if (!rec) {
    await S.audit(DB, 'keystatus_unknown', kid, '', ip, 'ключ не найден');
    return err('invalid_key', 'такого ключа не существует. Проверь, нет ли опечатки.', 404,
               { exists: false, format_ok: true, key_id: kid });
  }
  const r2 = await S.refreshStatus(DB, rec);
  // наружу — только факт существования и статус: ни план, ни срок, ни клиент,
  // ни устройства, чтобы эндпоинт не стал инструментом разведки по чужим лицензиям
  const out = { ok: true, exists: true, format_ok: true, key_id: r2.key_id,
                status: r2.status, blocked: false, message: '' };
  if (r2.status === S.ST_REVOKED) {
    const info = revokeInfo(r2);
    Object.assign(out, { blocked: true, revoked: true, revoke: info, message: info.message });
    await S.audit(DB, 'keystatus_blocked', kid, '', ip, `${info.kind}: ${info.reason}`);
  } else if (r2.expires_at && S.now() > r2.expires_at) {
    Object.assign(out, { blocked: true, expired: true,
                         message: 'срок действия лицензии истёк' });
    await S.audit(DB, 'keystatus_expired', kid, '', ip, 'истёк срок');
  } else {
    out.message = 'ключ действителен — можно активировать';
    await S.audit(DB, 'keystatus_ok', kid, '', ip, r2.status);
  }
  return json(out);
}

export async function handleDeactivate(request, env) {
  const DB = env.DB;
  const ip = clientIp(request);
  const data = await readJson(request);
  const key = extractKey(String(data.key || '')) || normalizeKey(String(data.key || ''));
  const hwid = String(data.hwid || '').trim().toLowerCase();
  if (!key || !hwid) return err('bad_request', 'нужны key и hwid');
  const rec = await S.getByHash(DB, await keyHash(key));
  if (!rec) return err('invalid_key', 'ключ не найден', 404);
  const ok = await S.releaseActivation(DB, rec.key_hash, hwid);
  await S.audit(DB, 'deactivate', rec.key_id, hwid, ip, ok ? 'освобождено' : 'не найдено');
  await S.refreshStatus(DB, rec);
  return json({ ok: true, released: ok,
    message: ok
      ? 'устройство освобождено, лицензию можно активировать на другом компьютере'
      : 'это устройство и так не было активировано' });
}
