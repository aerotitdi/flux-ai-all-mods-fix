// Админка Worker'а: выдача ключей, удаление, отзыв, статистика, журнал.
//
// Авторизация — заголовок `Authorization: Bearer <ADMIN_TOKEN>`, токен хранится в
// секрете Worker'а. Сравнение через constantTimeEq, чтобы не мерить время ответа.

import * as S from './db.mjs';
import { json, err, readJson, clientIp } from './http.mjs';
import { constantTimeEq, makeKey, keyHash, keyId, normalizeKind, revokeInfo,
         maskKey, RK_DELETED, RK_SUSPENDED } from './crypto.mjs';
import { estimateLoad, nextCheckInSeconds, TICKET_TTL_H, MIN_INTERVAL_H,
         MAX_INTERVAL_H } from './sched.mjs';

function requireAdmin(request, env) {
  const tok = String(env.ADMIN_TOKEN || '');
  if (!tok) return err('no_admin_token',
    'токен админки не задан. Выполни: npx wrangler secret put ADMIN_TOKEN', 503);
  const hdr = request.headers.get('Authorization') || '';
  const got = hdr.toLowerCase().startsWith('bearer ')
    ? hdr.slice(7).trim()
    : new URL(request.url).searchParams.get('token') || '';
  if (!got || !constantTimeEq(got, tok)) return err('forbidden', 'нет доступа', 403);
  return null;
}

// Веб-панель отдаётся отдельным модулем (admin_ui.js), чтобы этот файл оставался
// только про API.
import { renderAdmin } from './admin_ui.mjs';

export function handleAdminPage(request, env) {
  return new Response(renderAdmin(env), {
    status: 200,
    headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

export async function handleStats(request, env) {
  const denied = requireAdmin(request, env); if (denied) return denied;
  const DB = env.DB;
  const stats = await S.stats(DB);
  const clients = await S.activeClients(DB);
  return json({
    ok: true, stats,
    key_fingerprint: env.VENDOR_FINGERPRINT || '',
    // как сейчас дозируется нагрузка — это видно и в админке, чтобы не гадать
    active_clients: clients,
    poll: {
      next_check_in_seconds: nextCheckInSeconds(clients, 'ADMIN-PREVIEW'),
      min_hours: MIN_INTERVAL_H, max_hours: MAX_INTERVAL_H,
      ticket_ttl_hours: TICKET_TTL_H,
      forecast: [50, 100, 500, 1000, 1500, 3000].map(estimateLoad),
    },
  });
}

export async function handleLicenses(request, env) {
  const denied = requireAdmin(request, env); if (denied) return denied;
  const u = new URL(request.url);
  const rows = await S.listAll(env.DB, u.searchParams.get('status') || '',
                               Number(u.searchParams.get('limit') || 300));
  for (const r of rows) {
    delete r.key_hash;                       // хеш наружу не отдаём
    for (const a of (r.activations || [])) delete a.key_hash;
  }
  return json({ ok: true, licenses: rows });
}

export async function handleIssue(request, env) {
  const denied = requireAdmin(request, env); if (denied) return denied;
  const data = await readJson(request);
  const n = Math.max(1, Math.min(500, Number(data.n) || 1));
  const days = Number(data.days) || 0;
  const expires = days <= 0 ? 0 : S.now() + days * 86400;
  const out = [];
  for (let i = 0; i < n; i++) {
    const rec = await S.issue(env.DB, {
      plan: String(data.plan || 'standard'),
      customer: String(data.customer || ''),
      note: String(data.note || ''),
      expiresAt: expires,
      maxActivations: Math.max(1, Number(data.devices) || 1),
      // окно билета по умолчанию = TTL из планировщика (5 суток), чтобы обратный
      // отсчёт согласовывался с максимальным интервалом опроса
      offlineDays: Math.max(1, Number(data.offline) || TICKET_TTL_H / 24),
      keyHashFn: keyHash, makeKeyFn: makeKey,
    });
    out.push({ key: rec.key, key_id: rec.key_id, plan: rec.plan,
               expires_at: rec.expires_at, offline_days: rec.offline_days });
  }
  return json({ ok: true, issued: out,
                note: 'ключ показывается один раз — в базе только его sha256-хеш' });
}

export async function handleAction(request, env, action) {
  const denied = requireAdmin(request, env); if (denied) return denied;
  const DB = env.DB;
  const data = await readJson(request);
  const kid = String(data.key_id || '');
  if (!kid) return err('bad_request', 'нужен key_id');
  const ip = clientIp(request);
  let rec;

  switch (action) {
    case 'revoke': {
      const kind = normalizeKind(String(data.kind || RK_SUSPENDED));
      const reason = String(data.reason || '');
      rec = kind === RK_DELETED ? await S.deleteKey(DB, kid, reason)
                                : await S.revoke(DB, kid, reason, kind);
      break;
    }
    // кнопка «Удалить ключ»: блокировка навсегда + освобождение всех устройств
    case 'delete':
      rec = await S.deleteKey(DB, kid, String(data.reason || '')); break;
    // кнопка «Отозвать на неопределённое время»
    case 'suspend':
      rec = await S.suspend(DB, kid, String(data.reason || '')); break;
    case 'unrevoke':
      rec = await S.unrevoke(DB, kid); break;
    case 'extend':
      rec = await S.extend(DB, kid, Number(data.days) || 0); break;
    case 'plan':
      rec = await S.setPlan(DB, kid, String(data.plan || 'standard')); break;
    case 'release': {
      const r0 = await S.getById(DB, kid);
      if (!r0) return err('not_found', `лицензия ${kid} не найдена`, 404);
      const hw = String(data.hwid || '').trim().toLowerCase();
      const n = hw ? await S.releaseActivation(DB, r0.key_hash, hw)
                   : await S.releaseAll(DB, r0.key_hash);
      await S.audit(DB, 'release', kid, hw, ip, `освобождено: ${n ? 1 : 0}`);
      rec = await S.getById(DB, kid);
      break;
    }
    default:
      return err('unknown_action', `неизвестное действие: ${action}`, 404);
  }
  if (!rec) return err('not_found', `лицензия ${kid} не найдена`, 404);
  const kh = rec.key_hash;
  rec = await S.refreshStatus(DB, rec);
  const out = { ...rec };
  delete out.key_hash;
  out.activations = await S.activations(DB, kh, false);
  for (const a of out.activations) delete a.key_hash;
  // сразу отдаём текст, который увидит покупатель, — админка показывает его
  // в предпросмотре ДО подтверждения действия
  out.revoke_preview = rec.status === S.ST_REVOKED ? revokeInfo(rec) : null;
  return json({ ok: true, license: out });
}

export async function handleAudit(request, env) {
  const denied = requireAdmin(request, env); if (denied) return denied;
  const u = new URL(request.url);
  return json({ ok: true,
    records: await S.auditLog(env.DB, Number(u.searchParams.get('limit') || 100),
                              u.searchParams.get('key_id') || '') });
}

export { requireAdmin, maskKey };
