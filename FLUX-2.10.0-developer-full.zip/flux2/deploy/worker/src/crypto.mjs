// Криптография лицензий на Cloudflare Workers.
//
// КРИТИЧНО: этот модуль обязан давать БАЙТ-В-БАЙТ те же подписи, что
// license_server/crypto.py. Клиент проверяет билет офлайн встроенным публичным
// ключом вендора (app/_vendor_key.py) и ничего не знает о том, где работает
// сервер. Если канонический JSON разъедется хоть на один пробел — все
// существующие клиенты перестанут принимать билеты после переезда на Workers.
//
// Поэтому здесь явно реализовано:
//   canonical_json  = Python json.dumps(sort_keys=True, separators=(",",":"),
//                                       ensure_ascii=False)
//   key_hash        = sha256("flux2::" + key)
//   key_id          = key_hash(key)[:12].upper()
//   sign            = base64url_nopad(Ed25519(canonical_json(payload)))
//
// Совместимость проверяется тестом deploy/test_worker_parity.py, который
// подписывает один payload и в Python, и в этом модуле, и сверяет результаты.

// --- канонический JSON -------------------------------------------------------
// Python сортирует ключи по кодовым точкам и не экранирует не-ASCII. Стандартный
// JSON.stringify не сортирует ключи, поэтому сортируем вручную и рекурсивно.
export function canonicalJson(value) {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('non-finite number in ticket payload');
    // Python печатает целые без ".0", а JSON.stringify(1.0) === "1" — совпадает.
    // Для дробных оба используют кратчайшее представление, расхождений на наших
    // данных (целые таймстемпы) не возникает.
    return String(value);
  }
  if (typeof value === 'string') return jsonString(value);
  if (Array.isArray(value)) return '[' + value.map(canonicalJson).join(',') + ']';
  if (typeof value === 'object') {
    const keys = Object.keys(value).sort();
    const parts = [];
    for (const k of keys) {
      if (value[k] === undefined) continue;   // Python такого ключа просто не имеет
      parts.push(jsonString(k) + ':' + canonicalJson(value[k]));
    }
    return '{' + parts.join(',') + '}';
  }
  throw new Error('unsupported type in canonicalJson: ' + typeof value);
}

// Python json.dumps с ensure_ascii=False экранирует только " \ и управляющие
// символы; не-ASCII оставляет как есть (в UTF-8).
function jsonString(s) {
  let out = '"';
  for (const ch of s) {
    const c = ch.codePointAt(0);
    if (ch === '"') out += '\\"';
    else if (ch === '\\') out += '\\\\';
    else if (c < 0x20) {
      const map = { 8: 'b', 9: 't', 10: 'n', 12: 'f', 13: 'r' };
      out += map[c] ? '\\' + map[c] : '\\u' + c.toString(16).padStart(4, '0');
    } else out += ch;
  }
  return out + '"';
}

// --- хеши и идентификаторы ---------------------------------------------------
const te = new TextEncoder();

export async function sha256Hex(data) {
  const buf = await crypto.subtle.digest('SHA-256', te.encode(data));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}

// ТОТ ЖЕ префикс, что в app/license_fmt.py::key_hash — иначе хеши не совпадут
// и сервер не найдёт ни одного существующего ключа.
export async function keyHash(key) {
  return sha256Hex('flux2::' + key);
}

export async function keyId(key) {
  const src = String(key || '').trim();
  const h = src.startsWith('-----BEGIN')
    ? await sha256Hex('flux2::' + src)
    : await keyHash(normalizeKey(src) || src);
  return h.slice(0, 12).toUpperCase();
}

// --- формат ключа (копия app/license_fmt.py) ---------------------------------
export const ALPHABET = '23456789ABCDEFGHJKMNPQRSTVWXYZ';
const KEY_BODY_LEN = 20;
const PREFIX = 'FLX2';

function checkChar(body) {
  let total = 0;
  for (let i = 0; i < body.length; i++) {
    const idx = ALPHABET.indexOf(body[i]);
    if (idx < 0) return '?';
    total += (idx + 1) * (i + 3);
  }
  return ALPHABET[total % ALPHABET.length];
}

export function stripPrefix(s) {
  let out = '';
  for (const ch of String(s || '').trim().toUpperCase()) {
    if (/[0-9A-Z]/i.test(ch)) out += ch;
  }
  out = out.toUpperCase();
  for (const p of ['FLX2', 'FLUX2', 'FLUX', 'FLX']) {
    if (out.startsWith(p)) return out.slice(p.length);
  }
  return out;
}

export function normalizeKey(raw) {
  if (!raw) return null;
  const s = stripPrefix(raw);
  if (s.length !== KEY_BODY_LEN) return null;
  for (const ch of s) if (!ALPHABET.includes(ch)) return null;
  if (checkChar(s.slice(0, -1)) !== s[s.length - 1]) return null;
  const groups = [];
  for (let i = 0; i < s.length; i += 5) groups.push(s.slice(i, i + 5));
  return PREFIX + '-' + groups.join('-');
}

export function maskKey(key) {
  const k = normalizeKey(key) || String(key || '');
  const parts = k.split('-');
  if (parts.length !== 5) return k.slice(0, 4) + '…';
  return [parts[0], parts[1], '*****', '*****', parts[4]].join('-');
}

// извлечение ключа из вставленного куском письма — та же логика, что в клиенте
const KEY_IN_TEXT = new RegExp(
  '(?:FLX2|FLUX2|FLUX|FLX)?[\\s\\-_–—]*' +
  '([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})[\\s\\-_–—]*' +
  '([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})[\\s\\-_–—]*' +
  '([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})[\\s\\-_–—]*' +
  '([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})', 'g');

export function extractKey(text) {
  if (!text) return null;
  const up = String(text).toUpperCase();
  const direct = normalizeKey(up);
  if (direct) return direct;
  KEY_IN_TEXT.lastIndex = 0;
  let m;
  while ((m = KEY_IN_TEXT.exec(up)) !== null) {
    const cand = normalizeKey(m.slice(1).join(''));
    if (cand) return cand;
  }
  return null;
}

export function makeKey() {
  const bytes = new Uint8Array(KEY_BODY_LEN - 1);
  crypto.getRandomValues(bytes);
  let body = '';
  for (const b of bytes) body += ALPHABET[b % ALPHABET.length];
  body += checkChar(body);
  const groups = [];
  for (let i = 0; i < body.length; i += 5) groups.push(body.slice(i, i + 5));
  return PREFIX + '-' + groups.join('-');
}

// --- блокировка ключа (те же тексты, что видит покупатель) --------------------
export const RK_DELETED = 'deleted';
export const RK_SUSPENDED = 'suspended';
export const RK_REVOKED = 'revoked';

export function normalizeKind(kind) {
  const k = String(kind || '').trim().toLowerCase();
  if (k === RK_DELETED || k === RK_SUSPENDED || k === RK_REVOKED) return k;
  if (['delete', 'del', 'purged', 'removed'].includes(k)) return RK_DELETED;
  return RK_SUSPENDED;
}

const TITLES = {
  deleted: 'Этот ключ доступа был удалён',
  suspended: 'Этот ключ доступа отозван на неопределённое время',
  revoked: 'Этот ключ доступа отозван',
};
const DEFAULT_REASON = {
  deleted: 'причина не указана разработчиком',
  suspended: 'ключ приостановлен до решения разработчика',
  revoked: 'причина не указана разработчиком',
};

export function revokeReasonText(kind, reason) {
  const r = String(reason || '').trim();
  return r || DEFAULT_REASON[normalizeKind(kind)];
}

export function revokeMessage(kind, reason) {
  const k = normalizeKind(kind);
  const r = String(reason || '').trim();
  if (k === RK_SUSPENDED && !r) return TITLES[k];
  if (r) return `${TITLES[k]}. Причина: ${r}`;
  const d = DEFAULT_REASON[k];
  return `${TITLES[k]}. ${d.charAt(0).toUpperCase()}${d.slice(1)}.`;
}

export function revokeTitle(kind) { return TITLES[normalizeKind(kind)]; }
export function isPermanent(kind) { return normalizeKind(kind) === RK_DELETED; }

export function revokeInfo(rec) {
  if (!rec || rec.status !== 'revoked') return null;
  const kind = normalizeKind(rec.revoke_kind || RK_REVOKED);
  const reason = String(rec.revoke_reason || '').trim();
  return {
    kind, reason,
    reason_text: revokeReasonText(kind, reason),
    title: revokeTitle(kind),
    message: revokeMessage(kind, reason),
    permanent: isPermanent(kind),
    revoked_at: Number(rec.revoked_at || 0),
    key_id: rec.key_id || '',
  };
}

// --- Ed25519 ------------------------------------------------------------------
// Workers поддерживают Ed25519 через legacy-имя "NODE-ED25519" (WebCrypto).
// Алгоритм тот же, что использует Python cryptography, поэтому подписи взаимны.
const ED_ALG = { name: 'NODE-ED25519', namedCurve: 'NODE-ED25519' };

function b64ToBytes(b64) {
  const pad = b64.length % 4 ? '='.repeat(4 - (b64.length % 4)) : '';
  const std = (b64 + pad).replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(std);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesToB64urlNoPad(bytes) {
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

// Приватный ключ хранится в секрете Worker'а как PEM PKCS8 (тот же файл
// license_server/keys/vendor_private.pem). Извлекаем DER из PEM и импортируем.
export async function importPrivatePem(pem) {
  const der = pemToDer(pem);
  return crypto.subtle.importKey('pkcs8', der, ED_ALG, false, ['sign']);
}

export async function importPublicPem(pem) {
  const der = pemToDer(pem);
  return crypto.subtle.importKey('spki', der, ED_ALG, false, ['verify']);
}

function pemToDer(pem) {
  const body = String(pem).replace(/-----BEGIN [^-]+-----/, '')
    .replace(/-----END [^-]+-----/, '').replace(/\s+/g, '');
  if (!body) throw new Error('пустой PEM: проверь секрет VENDOR_PRIVATE_KEY_PEM');
  return b64ToBytes(body);
}

export async function signPayload(privateKey, payload) {
  const data = te.encode(canonicalJson(payload));
  const sig = await crypto.subtle.sign(ED_ALG, privateKey, data);
  return bytesToB64urlNoPad(new Uint8Array(sig));
}

export async function verifyPayload(publicKey, payload, sigB64) {
  try {
    const data = te.encode(canonicalJson(payload));
    return await crypto.subtle.verify(ED_ALG, publicKey, b64ToBytes(sigB64), data);
  } catch (e) {
    return false;
  }
}

function randomHex(nBytes) {
  const b = new Uint8Array(nBytes);
  crypto.getRandomValues(b);
  return [...b].map(x => x.toString(16).padStart(2, '0')).join('');
}

// Билет активации. Структура payload ОБЯЗАНА совпадать с crypto.make_ticket,
// иначе клиент отвергнет билет как неполный/незнакомый.
export async function makeTicket(privateKey, {
  key, hwid, plan, expires, issued = null, offlineDays = 14, customer = '', extra = null,
  nextCheckIn = 0,
}) {
  const now = Math.floor(Date.now() / 1000);
  const iss = Number(issued || now);
  const payload = {
    v: 1,
    kid: await keyId(key),
    hwid,
    plan,
    customer,
    issued: iss,
    expires: Number(expires || 0),
    offline_until: iss + Number(offlineDays) * 86400,
    nonce: randomHex(8),
  };
  if (extra) payload.extra = extra;
  // следующее предписанное сервером время отметки — ВНУТРИ подписи, поэтому
  // клиент не может сам «назначить себе» более редкую проверку или, наоборот,
  // продлить окно, подделав поле.
  if (nextCheckIn) payload.next_check = iss + Number(nextCheckIn);
  return { payload, sig: await signPayload(privateKey, payload) };
}

export function ticketPayload(ticket) {
  return (ticket && ticket.payload) || {};
}

export function constantTimeEq(a, b) {
  const x = te.encode(String(a || ''));
  const y = te.encode(String(b || ''));
  if (x.length !== y.length) return false;
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

export function randomToken(bytes = 24) {
  const b = new Uint8Array(bytes);
  crypto.getRandomValues(b);
  return bytesToB64urlNoPad(b);
}
