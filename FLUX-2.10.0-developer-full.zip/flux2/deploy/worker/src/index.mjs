// Точка входа FLUX License Server на Cloudflare Workers.
//
// Секреты (npx wrangler secret put ИМЯ):
//   VENDOR_PRIVATE_KEY_PEM  содержимое license_server/keys/vendor_private.pem
//   VENDOR_PUBLIC_KEY_PEM   содержимое license_server/keys/vendor_public.pem
//   ADMIN_TOKEN             токен веб-админки
// Необязательный var (wrangler.toml):
//   VENDOR_FINGERPRINT      отпечаток публичного ключа — показывается в админке
//
// Биндинг: DB -> D1 database "flux-licenses"

import { importPrivatePem, importPublicPem } from './crypto.mjs';
import { handleActivate, handlePing, handleHeartbeat, handleKeystatus,
         handleDeactivate } from './client.mjs';
import { handleStats, handleLicenses, handleIssue, handleAction, handleAudit,
         handleAdminPage } from './admin.mjs';
import { json, err } from './http.mjs';
import { pruneAudit, pruneOldBuckets } from './db.mjs';

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' } });
    }

    // крипто-ключи импортируем один раз на запрос; если секрета нет — падаем
    // внятно, а не «подпись недействительна» через полгода
    let c = {};
    try {
      if (!env.VENDOR_PRIVATE_KEY_PEM) {
        return err('misconfigured',
          'сервер не настроен: нет секрета VENDOR_PRIVATE_KEY_PEM. ' +
          'Выполни: npx wrangler secret put VENDOR_PRIVATE_KEY_PEM', 503);
      }
      c = {
        privKey: await importPrivatePem(env.VENDOR_PRIVATE_KEY_PEM),
        pubKey: env.VENDOR_PUBLIC_KEY_PEM ? await importPublicPem(env.VENDOR_PUBLIC_KEY_PEM) : null,
      };
    } catch (e) {
      return err('misconfigured',
        'не удалось импортировать ключ вендора: ' + (e && e.message) +
        '. Проверь, что секрет содержит PEM целиком (-----BEGIN … -----END …).', 503);
    }

    try {
      // --- клиентское API ---------------------------------------------------
      if (path === '/health' || path === '/') {
        return json({ ok: true, service: 'flux-license', runtime: 'cloudflare-workers',
                      version: 2, time: Math.floor(Date.now() / 1000) });
      }
      // GET-эндпоинты: веб-админка и три читательских метода админ-API.
      // Они ОБЯЗАНЫ быть GET: так же устроен license_server/server.py, и админка
      // (admin_ui.js) дёргает их через fetch без тела запроса.
      if (request.method === 'GET') {
        if (path === '/admin') return handleAdminPage(request, env);
        switch (path) {
          case '/admin/api/stats':    return await handleStats(request, env);
          case '/admin/api/licenses': return await handleLicenses(request, env);
          case '/admin/api/audit':    return await handleAudit(request, env);
        }
        if (path.startsWith('/admin/api/')) return methodNotAllowed();
        return json({ ok: false, error: 'not_found',
                      message: 'нет такого эндпоинта: ' + path }, 404);
      }

      if (request.method !== 'POST') {
        return json({ ok: false, error: 'method_not_allowed',
                      message: 'нужен GET или POST, пришло ' + request.method }, 405);
      }

      // POST-эндпоинты
      switch (path) {
        case '/v1/activate':   return await handleActivate(request, env, c);
        case '/v1/ping':       return await handlePing(request, env, c);
        case '/v1/heartbeat':  return await handleHeartbeat(request, env, c);
        case '/v1/keystatus':  return await handleKeystatus(request, env);
        case '/v1/deactivate': return await handleDeactivate(request, env);
        case '/admin/api/issue':    return await handleIssue(request, env);
      }
      const m = path.match(/^\/admin\/api\/([a-z]+)$/);
      if (m) return await handleAction(request, env, m[1]);
      return json({ ok: false, error: 'not_found', message: 'нет такого эндпоинта: ' + path }, 404);
    } catch (e) {
      console.error('worker error:', e && e.stack || e);
      return err('internal', 'внутренняя ошибка сервера лицензий', 500);
    }
  },

  // cron (см. wrangler.toml): чистим журнал и старые окна рейт-лимита, иначе
  // таблицы audit и rl растут бесконечно и съедают квоту D1 по записям.
  async scheduled(event, env, ctx) {
    try {
      await pruneAudit(env.DB, 90);
      await pruneOldBuckets(env.DB);
      await env.DB.prepare('DELETE FROM rl WHERE bucket < ?')
        .bind(Math.floor(Date.now() / 1000 / 60) - 2).run();
    } catch (e) {
      console.error('scheduled cleanup failed:', e && e.message);
    }
  },
};

function methodNotAllowed() {
  return json({ ok: false, error: 'method_not_allowed',
                message: 'этот эндпоинт принимает POST' }, 405);
}
