// HTTP-мелочи Worker'а: ответы, рейт-лимит, IP клиента.

import { now, q, run, audit } from './db.mjs';

const RL_WINDOW = 60;

export function clientIp(request) {
  return request.headers.get('CF-Connecting-IP')
      || (request.headers.get('X-Forwarded-For') || '').split(',')[0].trim()
      || '?';
}

export function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      // запросы идут из desktop-клиента, а не из браузера, но CORS не мешает и
      // позволяет отлаживать админку с локальной страницы
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    },
  });
}

export function err(code, message, status = 400, extra = {}) {
  return json({ ok: false, error: code, message, ...extra }, status);
}

export async function readJson(request) {
  try { return await request.json(); } catch (e) { return {}; }
}

// Рейт-лимит по D1.
//
// В Workers нет постоянной памяти между запросами (каждый запрос может попасть на
// другой edge-сервер), поэтому in-memory-словарь, как в license_server/server.py,
// здесь не работает. Считаем в таблице rl окнами по 60 секунд.
//
// Это НЕ защита от перебора ключей: ключ — 19 случайных символов из алфавита 30
// символов, перебор нереален. Смысл в другом — не дать одному клиенту (или
// зациклившемуся скрипту) съесть квоту D1, от которой зависят остальные.
// Лимиты по умолчанию совпадают с license_server/server.py. Их можно поднять
// переменными Worker'а (RL_ACTIVATE / RL_HEARTBEAT / RL_KEYSTATUS / RL_PING) —
// это нужно для сквозных тестов, которые делают десятки активаций с одного IP.
// В продакшене переменные не задаются, действуют значения ниже.
export const RL_DEFAULTS = {
  activate: 8, heartbeat: 60, keystatus: 40, ping: 60,
};

export function rlLimit(env, action) {
  const v = Number(env && env['RL_' + action.toUpperCase()]);
  return Number.isFinite(v) && v > 0 ? v : (RL_DEFAULTS[action] || 60);
}

export async function rateLimited(DB, ip, action, limit) {
  const bucket = Math.floor(now() / RL_WINDOW);
  const row = await q(DB, 'SELECT n FROM rl WHERE bucket=? AND ip=? AND action=?',
                      bucket, String(ip).slice(0, 45), action);
  const n = Number((row && row.n) || 0) + 1;
  if (row) {
    await run(DB, 'UPDATE rl SET n=? WHERE bucket=? AND ip=? AND action=?',
              n, bucket, String(ip).slice(0, 45), action);
  } else {
    await run(DB, 'INSERT INTO rl(bucket,ip,action,n) VALUES(?,?,?,?)',
              bucket, String(ip).slice(0, 45), action, n);
    // чистим старые окна, иначе таблица rl растёт бесконечно
    await run(DB, 'DELETE FROM rl WHERE bucket < ?', bucket - 2);
  }
  return n > limit;
}

export { audit };
