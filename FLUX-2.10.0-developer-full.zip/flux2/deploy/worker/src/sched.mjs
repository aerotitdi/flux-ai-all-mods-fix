// Дозирование нагрузки: когда клиенту прийти в следующий раз и сколько живёт билет.
//
// ЗАДАЧА (слова заказчика): «рандомно от 5 часов до 72 часа, зависит от того,
// сколько флюксов сейчас включено и работает, чтобы лишний раз не напрягать
// систему».
//
// РЕШЕНИЕ
//   1. Сервер считает, сколько клиентов отметилось за последние 6 часов.
//   2. По этому числу выбирает ЦЕЛЕВОЙ интервал ступенями: чем больше клиентов,
//      тем реже стучится каждый. Суммарная нагрузка растёт ступенчато, а не
//      линейно, поэтому free tier D1 держит тысячи клиентов.
//   3. Конкретному клиенту интервал выдаётся с ДЖИТТЕРОМ ±25%. Без него все 1500
//      клиентов, активированные одной рассылкой, пришли бы одновременно
//      (thundering herd) и создали пик квоты.
//   4. Интервал возвращается ВНУТРИ ПОДПИСАННОГО билета (payload.next_check),
//      поэтому клиент не может назначить себе более редкую проверку или продлить
//      окно: подпись вендора он не воспроизведёт.
//
// ПОЧЕМУ ЧАСТЫЙ ОПРОС ДЕШЁВ: /v1/ping не передаёт билет. Раньше клиент слал весь
// подписанный билет на каждую проверку (626 Б из 856 Б всего обмена). Пинг шлёт
// только key_id — обмен выходит ~325 Б. Замеры: tests/test_worker.py [трафик].

export const MIN_INTERVAL_H = 5;
export const MAX_INTERVAL_H = 72;

// Сколько часов живёт билет. ОБЯЗАНО превышать максимальный интервал опроса,
// иначе честный клиент заблокируется просто потому, что сервер велел ему спать
// 72 часа, а окно билета было ровно 72 часа.
//
//   72ч макс. интервал + 48ч запас = 120ч = 5 суток
//
// Запас покрывает: недоступность сервера, выключенный ПК покупателя на выходных,
// обрыв сети. Пока окно не истекло, FLUX работает полностью офлайн — то есть
// покупатель не зависит ни от твоего ПК, ни от Cloudflare.
export const TICKET_TTL_H = MAX_INTERVAL_H + 48;

// Ступени подобраны так, чтобы суммарная нагрузка на D1 оставалась в free tier
// (5 млн чтений / 100 тыс записей в день) с запасом минимум в 10 раз.
// Расчёт нагрузки — в estimateLoad() ниже и в tests/test_worker.py.
const TIERS = [
  { maxClients:    50, hours:  6 },   // мало клиентов — отзыв быстрый
  { maxClients:   200, hours: 12 },
  { maxClients:   500, hours: 24 },
  { maxClients:  1000, hours: 48 },
  { maxClients: Infinity, hours: MAX_INTERVAL_H },
];

export function targetIntervalHours(clients) {
  const n = Math.max(0, Number(clients) || 0);
  for (const t of TIERS) if (n <= t.maxClients) return t.hours;
  return MAX_INTERVAL_H;
}

// Детерминированный псевдорандом (FNV-1a) по key_id клиента.
//
// НАМЕРЕННО не crypto.randomUUID/Math.random: интервал должен быть СТАБИЛЬНЫМ для
// одного клиента между запросами. Иначе на каждой отметке клиент получал бы новое
// случайное число и в среднем опрашивал чаще, чем предусмотрено. При этом у
// разных клиентов джиттер разный — стадо рассеивается.
export function jitterHours(seed, spread) {
  const s = String(seed || 'flux');
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const unit = ((h >>> 0) % 100000) / 100000;   // в [0, 1)
  return (unit - 0.5) * 2 * spread;             // +/- spread часов
}

export function nextCheckInSeconds(clients, keyId) {
  const target = targetIntervalHours(clients);
  const hours = Math.min(MAX_INTERVAL_H,
                Math.max(MIN_INTERVAL_H, target + jitterHours(keyId, target * 0.25)));
  return Math.round(hours * 3600);
}

// Обратный отсчёт для пользователя — ровно тот сценарий, что описал заказчик:
// «3 дня, дальше 1 день, дальше 15 часов, дальше 10 часов, дальше 0 — конец».
export function humanizeLeft(seconds) {
  const s = Math.max(0, Math.round(Number(seconds) || 0));
  if (s <= 0) return '0 ч';
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return h ? `${d} дн ${h} ч` : `${d} дн`;
  if (h > 0) return m ? `${h} ч ${m} мин` : `${h} ч`;
  return m > 0 ? `${m} мин` : 'меньше минуты';
}

// Размер обмена пинга В БАЙТАХ ТЕЛА: запрос ~25 Б (только key_id) + ответ ~240 Б.
// HTTP-заголовки не считаем: они одинаковы у любого ответа и в квоту D1 не
// попадают. Значение подтверждено замером в test/api.test.mjs, раздел [5].
// Число ОБЯЗАНО совпадать с license_server/sched.py::PING_BYTES — расхождение
// ловит test/sched_parity.test.mjs.
export const PING_BYTES = 270;

// Оценка нагрузки до того, как в неё упрёмся. Используется в /admin (карточка
// «прогноз нагрузки») и в тестах.
export function estimateLoad(clients) {
  const n = Math.max(0, Number(clients) || 0);
  const intervalH = targetIntervalHours(n);
  const pollsPerDay = n * 24 / intervalH;
  const reads = pollsPerDay * 1.2;              // пинг = 1 чтение + доля refresh_status
  const writes = n * 24 * 0.35;                 // last_seen не чаще раза в час
  return {
    clients: n,
    interval_hours: intervalH,
    polls_per_day: Math.round(pollsPerDay),
    d1_reads_per_day: Math.round(reads),
    d1_writes_per_day: Math.round(writes),
    d1_read_pct_of_free: +(reads / 5_000_000 * 100).toFixed(3),
    d1_write_pct_of_free: +(writes / 100_000 * 100).toFixed(2),
    bytes_per_poll: PING_BYTES,
    mb_per_month: +(pollsPerDay * PING_BYTES * 30 / 1048576).toFixed(2),
  };
}
