// Тестовый воркер-обёртка: поднимает модули криптографии и планировщика внутри
// настоящего рантайма Workers и возвращает результаты одним JSON.
//
// Отдельный файл (а не строка в тесте) потому, что miniflare не умеет резолвить
// import в string-script без scriptPath — а нам нужны именно РЕАЛЬНЫЕ модули
// воркера, а не их копия: тест проверяет байт-в-байт совместимость подписи с
// Python, поэтому подменять код нельзя.
import * as C from '../src/crypto.mjs';
import * as S from '../src/sched.mjs';

export default {
  async fetch(request, env) {
    const body = await request.json();
    const out = {};
    const sk = await C.importPrivatePem(env.PRIV);
    const pk = await C.importPublicPem(env.PUB);

    // --- канонический JSON и подпись -----------------------------------------
    out.canon = C.canonicalJson(body.payload);
    out.sig = await C.signPayload(sk, body.payload);
    out.verifies_python = await C.verifyPayload(pk, body.payload, body.sig_py);
    out.rejects_tampered_plan =
      await C.verifyPayload(pk, { ...body.payload, plan: 'ultimate' }, body.sig_py) === false;
    out.rejects_extended_window =
      await C.verifyPayload(pk, { ...body.payload, offline_until: 1760000000 + 315360000 },
                            body.sig_py) === false;
    out.rejects_bad_sig =
      await C.verifyPayload(pk, body.payload, body.sig_py.slice(0, -4) + 'AAAA') === false;
    out.rejects_no_sig = await C.verifyPayload(pk, body.payload, '') === false;

    // --- формат ключа ---------------------------------------------------------
    out.normalize = C.normalizeKey(body.key);
    out.extract = C.extractKey('Ваш ключ: ' + body.key + ' — сохраните его');
    out.extract_lower = C.extractKey(body.key.toLowerCase());
    out.extract_spaces = C.extractKey(body.key.replace(/-/g, ' '));
    out.extract_garbage = C.extractKey('привет, это не ключ');
    out.mask = C.maskKey(body.key);
    out.keyHash = await C.keyHash(body.key);
    out.keyId = await C.keyId(body.key);
    out.makeKeyValid = C.normalizeKey(C.makeKey()) !== null;

    // --- тексты причин --------------------------------------------------------
    out.revoke_del = C.revokeMessage('deleted', 'возврат средств');
    out.revoke_sus = C.revokeMessage('suspended', '');
    out.revoke_sus_r = C.revokeMessage('suspended', 'оплата не подтверждена');
    out.revoke_info = C.revokeInfo({ status: 'revoked', revoke_kind: 'deleted',
                                     revoke_reason: 'возврат средств', revoked_at: 1760000000,
                                     key_id: 'ABC123DEF456' });
    out.revoke_info_sus = C.revokeInfo({ status: 'revoked', revoke_kind: '',
                                         revoke_reason: '', key_id: 'X' });
    out.revoke_info_active = C.revokeInfo({ status: 'active' });
    out.normalize_kind = [C.normalizeKind('delete'), C.normalizeKind('suspended'),
                          C.normalizeKind('что угодно'), C.normalizeKind('')];
    out.is_permanent = [C.isPermanent('deleted'), C.isPermanent('suspended')];
    out.constant_time_eq = [C.constantTimeEq('abc', 'abc'), C.constantTimeEq('abc', 'abd'),
                            C.constantTimeEq('abc', 'ab')];

    // --- билет ----------------------------------------------------------------
    // issued = body.now (актуальное время), а не фиксированная константа:
    // verify_ticket в Python честно отвергает билет, чьё окно уже истекло,
    // и тест падал бы просто из-за устаревшей даты.
    out.ticket = await C.makeTicket(sk, {
      key: body.key, hwid: 'ab'.repeat(32), plan: 'pro', expires: 0,
      issued: body.now, offlineDays: 5, customer: 'Иван Петров',
      extra: { license: 'ABC123DEF456' }, nextCheckIn: 43200,
    });
    out.ticket_payload = C.ticketPayload(out.ticket);
    out.ticket_no_next = C.ticketPayload(await C.makeTicket(sk, {
      key: body.key, hwid: 'ab'.repeat(32), plan: 'pro', expires: 0,
      issued: body.now, offlineDays: 5,
    }));

    // --- планировщик нагрузки -------------------------------------------------
    out.ttl = S.TICKET_TTL_H;
    out.bounds = [S.MIN_INTERVAL_H, S.MAX_INTERVAL_H];
    out.target = [1, 50, 51, 100, 200, 500, 1000, 1500, 5000].map(S.targetIntervalHours);
    out.load = { l100: S.estimateLoad(100), l500: S.estimateLoad(500),
                 l1500: S.estimateLoad(1500), l5000: S.estimateLoad(5000) };
    out.human = [432000, 259200, 86400, 54000, 36000, 3600, 600, 60, 0].map(S.humanizeLeft);
    const set = new Set();
    for (let i = 0; i < 500; i++) set.add(S.nextCheckInSeconds(1500, 'KEY' + i));
    out.jitter_unique = set.size;
    out.jitter_stable = S.nextCheckInSeconds(1500, 'KEY7') === S.nextCheckInSeconds(1500, 'KEY7');
    const vals = [...set].map(x => x / 3600);
    out.jitter_min = Math.min(...vals);
    out.jitter_max = Math.max(...vals);
    out.jitter_spread_ok = out.jitter_max > out.jitter_min;

    return new Response(JSON.stringify(out), {
      headers: { 'Content-Type': 'application/json' },
    });
  },
};
