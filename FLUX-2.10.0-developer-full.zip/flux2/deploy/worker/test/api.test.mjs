// Интеграционные тесты FLUX License Server на Workers: настоящий workerd + D1.
//
// Проверяем ПОЛНЫЙ цикл по HTTP, а не вызовы функций: выдача ключа -> активация
// -> пинг -> удаление ключа -> блокировка с причиной -> восстановление. Плюс то,
// ради чего всё затевалось: покупатели НЕ зависят от ПК разработчика, а обмен
// дешёвый.
//
// Запуск:  cd deploy && node worker/test/api.test.mjs
//          (или npm test)

import { Miniflare } from 'miniflare';
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { splitSql } from '../src/sqlsplit.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..', '..');
const DEPLOY = path.resolve(HERE, '..', '..');

const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

// --- ключи вендора и Python-эталон ------------------------------------------
const PY = JSON.parse(execFileSync('python3', ['-c', `
import json, sys
sys.path.insert(0, ${JSON.stringify(ROOT)})
from license_server import crypto, keys
if not keys.exists(): keys.init()
print(json.dumps({
  "priv": open(keys.PRIV_PATH, encoding="utf-8").read(),
  "pub":  open(keys.PUB_PATH,  encoding="utf-8").read(),
  "fp":   keys.fingerprint(),
}, ensure_ascii=False))
`], { encoding: 'utf8', cwd: ROOT }).trim().split('\n').pop());

const SCHEMA = fs.readFileSync(path.join(DEPLOY, 'schema.sql'), 'utf8');
const ADMIN_TOKEN = 'test-admin-token-workers';

// --- поднимаем воркер с реальной D1 ------------------------------------------
const mf = new Miniflare({
  modules: true,
  scriptPath: path.join(DEPLOY, 'worker', 'src', 'index.mjs'),
  bindings: {
    VENDOR_PRIVATE_KEY_PEM: PY.priv,
    VENDOR_PUBLIC_KEY_PEM: PY.pub,
    VENDOR_FINGERPRINT: PY.fp,
    ADMIN_TOKEN,
    // тест делает десятки активаций с одного IP — обычный лимит (8/мин) его бы
    // остановил посреди сценария. Сам механизм рейт-лимита проверяется отдельно
    // в разделе [13] на воркере с ДЕФОЛТНЫМИ лимитами.
    RL_ACTIVATE: '5000', RL_HEARTBEAT: '5000', RL_KEYSTATUS: '5000', RL_PING: '5000',
  },
  d1Databases: { DB: 'flux-licenses-test' },
});

// Применяем схему. Парсер — src/sqlsplit.mjs: наивный split(";") здесь не годится,
// потому что в комментариях схемы есть ";", а многострочные CREATE TABLE он рвёт
// пополам. Раньше из-за этого схема «применялась» без единой таблицы.
const db = await mf.getD1Database('DB');
await db.batch(splitSql(SCHEMA).map(s => db.prepare(s)));

async function call(p, body, admin = false) {
  const r = await mf.dispatchFetch('https://lic.test' + p, {
    method: body === undefined ? 'GET' : 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(admin ? { Authorization: 'Bearer ' + ADMIN_TOKEN } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let d = null;
  try { d = await r.json(); } catch (e) { d = { ok: false, parse: 'не JSON' }; }
  return { status: r.status, d };
}

// Python-проверка билета той же функцией, что и app/licensing.py
function pyVerify(ticket, hwid) {
  fs.writeFileSync('/tmp/wapi_ticket.json', JSON.stringify(ticket));
  const out = execFileSync('python3', ['-c', `
import json, sys
sys.path.insert(0, ${JSON.stringify(ROOT)})
from license_server import crypto, keys
tk = json.load(open('/tmp/wapi_ticket.json', encoding='utf-8'))
pub = keys.load_public_key()
ok, why = crypto.verify_ticket(pub, tk, ${JSON.stringify(hwid)})
p = crypto.ticket_payload(tk)
print(json.dumps({"ok": ok, "why": why, "plan": p.get("plan"),
                  "kid": p.get("kid"), "next_h": (p.get("next_check") or 0) - p.get("issued", 0),
                  "ttl_h": (p.get("offline_until") or 0) - p.get("issued", 0)},
                 ensure_ascii=False))
`], { encoding: 'utf8', cwd: ROOT }).trim().split('\n').pop();
  return JSON.parse(out);
}

const HWID = 'a1'.repeat(16);
const HWID2 = 'b2'.repeat(16);

console.log('\n[1] Сервер жив и не зависит от ПК разработчика');
{
  const { status, d } = await call('/health');
  check('/health отвечает 200', status === 200, String(status));
  check('runtime = cloudflare-workers', d.runtime === 'cloudflare-workers', JSON.stringify(d));
  check('сервис опознан', d.service === 'flux-license', JSON.stringify(d));
}

console.log('\n[2] Админка: выдача ключа');
let key = null, kid = null;
{
  const r0 = await call('/admin/api/stats');
  check('без токена — 403', r0.status === 403, String(r0.status));
  const r1 = await call('/admin/api/stats', undefined, true);
  check('с токеном stats отдаётся', r1.status === 200 && r1.d.ok, JSON.stringify(r1.d).slice(0, 160));
  check('в stats есть отпечаток ключа вендора', r1.d.key_fingerprint === PY.fp, r1.d.key_fingerprint);
  check('в stats есть прогноз нагрузки', Array.isArray(r1.d.poll?.forecast), JSON.stringify(r1.d.poll));
  check('в stats видно активных клиентов', typeof r1.d.active_clients === 'number');

  const r2 = await call('/admin/api/issue', { plan: 'pro', customer: 'buyer@mail.com',
                                              devices: 1, offline: 5, n: 1 }, true);
  check('issue работает', r2.status === 200 && r2.d.ok, JSON.stringify(r2.d).slice(0, 200));
  check('ключ выдан один раз', Array.isArray(r2.d.issued) && r2.d.issued.length === 1);
  key = r2.d.issued[0].key;
  kid = r2.d.issued[0].key_id;
  check('ключ формата FLX2-…', /^FLX2-[23456789A-HJ-NP-TV-Z]{5}(-[23456789A-HJ-NP-TV-Z]{5}){3}$/.test(key), key);
  check('окно отсчёта = 5 суток', r2.d.issued[0].offline_days === 5, String(r2.d.issued[0].offline_days));
}

console.log('\n[3] Активация ключа покупателем');
let ticket = null;
{
  // вставляем ключ куском письма — как это делает покупатель
  const email = `Спасибо за покупку FLUX!\n\nВаш ключ доступа: ${key}\n\nСохраните его.\nЗаказ №4471`;
  const r = await call('/v1/activate', { key: email, hwid: HWID, hwid_variants: [HWID],
                                         hwid_label: 'DESKTOP-TEST', app_version: '2.10.0' });
  check('активация по тексту письма прошла', r.status === 200 && r.d.ok, JSON.stringify(r.d).slice(0, 240));
  check('план определился', r.d.plan === 'pro', String(r.d.plan));
  check('license_id совпадает', r.d.license_id === kid, `${r.d.license_id} != ${kid}`);
  ticket = r.d.ticket;
  check('билет выдан', !!(ticket && ticket.payload && ticket.sig));

  const v = pyVerify(ticket, HWID);
  check('Python-клиент принимает билет Workers-сервера', v.ok === true, `${v.ok} / ${v.why}`);
  check('в билете правильный plan', v.plan === 'pro', String(v.plan));
  check('в билете правильный kid', v.kid === kid, `${v.kid} != ${kid}`);
  check('окно билета = 120 ч (5 суток)', v.ttl_h === 120 * 3600, String(v.ttl_h / 3600) + ' ч');
  check('next_check зашит в подпись', v.next_h >= 5 * 3600 && v.next_h <= 72 * 3600,
        String(v.next_h / 3600) + ' ч');

  check('сервер вернул next_check_in', r.d.next_check_in >= 5 * 3600 && r.d.next_check_in <= 72 * 3600,
        String(r.d.next_check_in));
  check('сервер вернул ticket_ttl_hours=120', r.d.ticket_ttl_hours === 120, String(r.d.ticket_ttl_hours));
  check('сервер вернул отсчёт в секундах', r.d.seconds_left === 5 * 86400, String(r.d.seconds_left));
  check('сервер вернул отсчёт текстом', r.d.left_human === '5 дн', String(r.d.left_human));
}

console.log('\n[4] Привязка к одному устройству');
{
  const r = await call('/v1/activate', { key, hwid: HWID2, hwid_variants: [HWID2] });
  check('второе устройство отклонено', r.status === 409, String(r.status));
  check('error = already_bound', r.d.error === 'already_bound', String(r.d.error));
  check('в ответе список занятых устройств', Array.isArray(r.d.bound) && r.d.bound.length === 1,
        JSON.stringify(r.d.bound));
  check('в сообщении объяснено, как перенести', /Деактивировать/.test(r.d.message || ''), r.d.message);

  const r2 = await call('/v1/activate', { key, hwid: HWID, hwid_variants: [HWID] });
  check('то же устройство активируется повторно', r2.status === 200 && r2.d.ok, String(r2.status));
  check('место не потрачено дважды', r2.d.hwid_migrated === false || r2.d.ok === true);
}

console.log('\n[5] Лёгкий пинг: состояние без передачи билета');
{
  const before = JSON.stringify({ key, hwid: HWID });
  const r = await call('/v1/ping', { key_id: kid });
  check('пинг по key_id работает', r.status === 200 && r.d.ok, JSON.stringify(r.d).slice(0, 200));
  check('пинг вернул план', r.d.plan === 'pro', String(r.d.plan));
  check('пинг вернул next_check_in', typeof r.d.next_check_in === 'number');
  check('пинг вернул ticket_ttl_hours', r.d.ticket_ttl_hours === 120);
  check('пинг НЕ требует билет', r.d.ok === true);
  check('пинг не отдаёт hwid', r.d.hwid === undefined, JSON.stringify(r.d));
  check('пинг не отдаёт customer', r.d.customer === undefined, JSON.stringify(r.d));

  // замеряем размер обмена — это и есть экономия трафика
  const respBytes = Buffer.byteLength(JSON.stringify(r.d));
  const reqBytes = Buffer.byteLength(JSON.stringify({ key_id: kid }));
  check(`пинг: запрос ${reqBytes} Б`, reqBytes < 60, String(reqBytes));
  check(`пинг: ответ ${respBytes} Б (< 400)`, respBytes < 400, String(respBytes));
  check('пинг в разы легче старого heartbeat (626 Б только на билет)',
        reqBytes < 626, `${reqBytes} vs 626`);

  const r2 = await call('/v1/ping', { key_id: 'НЕТУТАКОГО' });
  check('пинг неизвестного ключа — 404', r2.status === 404, String(r2.status));
}

console.log('\n[6] keystatus: проверка до активации');
{
  const r = await call('/v1/keystatus', { key });
  check('keystatus отвечает', r.status === 200 && r.d.ok, JSON.stringify(r.d).slice(0, 200));
  check('keystatus: ключ жив', r.d.blocked === false);
  check('keystatus: статус active', r.d.status === 'active', String(r.d.status));
  check('keystatus НЕ отдаёт план', r.d.plan === undefined, JSON.stringify(Object.keys(r.d)));
  check('keystatus НЕ отдаёт устройства', r.d.activations === undefined);
  check('keystatus НЕ отдаёт срок', r.d.expires_at === undefined);

  const r2 = await call('/v1/keystatus', { key: 'мусор' });
  check('keystatus на мусор — 400', r2.status === 400, String(r2.status));
  check('keystatus на мусор: format_ok=false', r2.d.format_ok === false);
}

console.log('\n[7] УДАЛЕНИЕ ключа -> покупатель видит причину');
{
  const r = await call('/admin/api/delete', { key_id: kid, reason: 'возврат средств' }, true);
  check('delete через API прошёл', r.status === 200 && r.d.ok, JSON.stringify(r.d).slice(0, 200));
  check('в базе status=revoked', r.d.license.status === 'revoked', String(r.d.license.status));
  check('в базе revoke_kind=deleted', r.d.license.revoke_kind === 'deleted',
        String(r.d.license.revoke_kind));
  check('в базе причина', r.d.license.revoke_reason === 'возврат средств');
  check('API вернул предпросмотр текста для покупателя',
        r.d.license.revoke_preview?.message === 'Этот ключ доступа был удалён. Причина: возврат средств',
        JSON.stringify(r.d.license.revoke_preview));
  check('key_hash наружу не отдан', r.d.license.key_hash === undefined);

  const p = await call('/v1/ping', { key_id: kid });
  check('пинг сразу сообщил о блокировке', p.status === 403 && p.d.revoked === true,
        JSON.stringify(p.d).slice(0, 200));
  check('пинг вернул kind=deleted', p.d.revoke?.kind === 'deleted', JSON.stringify(p.d.revoke));
  check('пинг вернул permanent=true', p.d.revoke?.permanent === true);
  check('пинг вернул ДОСЛОВНЫЙ текст',
        p.d.message === 'Этот ключ доступа был удалён. Причина: возврат средств', p.d.message);
  check('пинг вернул title', p.d.revoke?.title === 'Этот ключ доступа был удалён',
        String(p.d.revoke?.title));

  const a = await call('/v1/activate', { key, hwid: HWID, hwid_variants: [HWID] });
  check('активация удалённым ключом отклонена', a.status === 403, String(a.status));
  check('в отказе есть причина', /возврат средств/.test(a.d.message || ''), a.d.message);
  check('в отказе есть объект revoke', a.d.revoke?.kind === 'deleted');

  const ks = await call('/v1/keystatus', { key });
  check('keystatus: заблокирован', ks.d.blocked === true);
  check('keystatus: причина видна', /удалён/.test(ks.d.message || ''), ks.d.message);

  const hb = await call('/v1/heartbeat', { key, hwid: HWID, ticket });
  check('heartbeat отклонён', hb.status === 403 && hb.d.revoked === true, String(hb.status));
  check('heartbeat вернул причину', hb.d.revoke?.kind === 'deleted', JSON.stringify(hb.d.revoke));

  const rel = await call('/admin/api/licenses', undefined, true);
  const row = (rel.d.licenses || []).find(x => x.key_id === kid);
  check('у удалённого ключа освобождены устройства',
        (row.activations || []).filter(x => !x.released).length === 0,
        JSON.stringify(row && row.activations));
}

console.log('\n[8] Отзыв на неопределённое время и возврат');
{
  const r = await call('/admin/api/issue', { plan: 'standard', devices: 1, offline: 5 }, true);
  const k2 = r.d.issued[0].key, id2 = r.d.issued[0].key_id;
  const act = await call('/v1/activate', { key: k2, hwid: HWID, hwid_variants: [HWID] });
  check('второй ключ активирован', act.status === 200 && act.d.ok, String(act.status));

  const s = await call('/admin/api/suspend', { key_id: id2, reason: '' }, true);
  check('suspend прошёл', s.status === 200 && s.d.ok, JSON.stringify(s.d).slice(0, 200));
  check('kind=suspended', s.d.license.revoke_kind === 'suspended', String(s.d.license.revoke_kind));
  check('предпросмотр — «отозван на неопределённое время»',
        s.d.license.revoke_preview?.message === 'Этот ключ доступа отозван на неопределённое время',
        s.d.license.revoke_preview?.message);
  check('без причины нет хвоста «Причина:»',
        !/Причина:/.test(s.d.license.revoke_preview?.message || ''),
        s.d.license.revoke_preview?.message);

  const p = await call('/v1/ping', { key_id: id2 });
  check('пинг сообщил об отзыве', p.status === 403 && p.d.revoked === true);
  check('пинг: kind=suspended', p.d.revoke?.kind === 'suspended');
  check('пинг: permanent=false (можно вернуть)', p.d.revoke?.permanent === false);
  check('пинг: текст про неопределённое время',
        /отозван на неопределённое время/.test(p.d.message || ''), p.d.message);

  const u = await call('/admin/api/unrevoke', { key_id: id2 }, true);
  check('unrevoke прошёл', u.status === 200 && u.d.ok);
  check('revoke_kind очищен', !u.d.license.revoke_kind, String(u.d.license.revoke_kind));
  const p2 = await call('/v1/ping', { key_id: id2 });
  check('после возврата пинг успешен', p2.status === 200 && p2.d.ok === true, JSON.stringify(p2.d));
  const act2 = await call('/v1/activate', { key: k2, hwid: HWID, hwid_variants: [HWID] });
  check('после возврата ключ снова активируется', act2.status === 200 && act2.d.ok,
        JSON.stringify(act2.d).slice(0, 200));
}

console.log('\n[9] Heartbeat перевыпускает билет с новым отсчётом');
{
  const r = await call('/admin/api/issue', { plan: 'ultimate', devices: 1, offline: 5 }, true);
  const k3 = r.d.issued[0].key;
  const act = await call('/v1/activate', { key: k3, hwid: HWID, hwid_variants: [HWID] });
  const hb = await call('/v1/heartbeat', { key: k3, hwid: HWID, hwid_variants: [HWID],
                                           ticket: act.d.ticket, app_version: '2.10.0' });
  check('heartbeat успешен', hb.status === 200 && hb.d.ok === true, JSON.stringify(hb.d).slice(0, 200));
  check('heartbeat вернул отсчёт', typeof hb.d.seconds_left === 'number', JSON.stringify(hb.d));
  check('heartbeat вернул отсчёт текстом', /дн|ч|мин/.test(hb.d.left_human || ''), hb.d.left_human);
  check('heartbeat вернул next_check_in', hb.d.next_check_in >= 5 * 3600);
  check('heartbeat не вернул чужих данных', hb.d.customer === undefined);
}

console.log('\n[10] Деактивация освобождает устройство');
{
  const r = await call('/admin/api/issue', { plan: 'standard', devices: 1, offline: 5 }, true);
  const k4 = r.d.issued[0].key;
  await call('/v1/activate', { key: k4, hwid: HWID, hwid_variants: [HWID] });
  const d = await call('/v1/deactivate', { key: k4, hwid: HWID });
  check('деактивация прошла', d.status === 200 && d.d.released === true, JSON.stringify(d.d));
  const a2 = await call('/v1/activate', { key: k4, hwid: HWID2, hwid_variants: [HWID2] });
  check('после деактивации ключ встал на другое устройство',
        a2.status === 200 && a2.d.ok === true, JSON.stringify(a2.d).slice(0, 200));
}

console.log('\n[11] Продление и смена плана');
{
  const r = await call('/admin/api/issue', { plan: 'trial', days: 30, devices: 1 }, true);
  const id5 = r.d.issued[0].key_id;
  const e = await call('/admin/api/extend', { key_id: id5, days: 90 }, true);
  check('extend прошёл', e.status === 200 && e.d.ok, JSON.stringify(e.d).slice(0, 200));
  check('срок увеличился', e.d.license.expires_at > Math.floor(Date.now() / 1000) + 100 * 86400,
        String(e.d.license.expires_at));
  const p = await call('/admin/api/plan', { key_id: id5, plan: 'ultimate' }, true);
  check('смена плана прошла', p.d.license.plan === 'ultimate', String(p.d.license.plan));
  const e0 = await call('/admin/api/extend', { key_id: id5, days: 0 }, true);
  check('extend 0 делает лицензию бессрочной', e0.d.license.expires_at === 0,
        String(e0.d.license.expires_at));
}

console.log('\n[12] Журнал аудита');
{
  const r = await call('/admin/api/audit?limit=200', undefined, true);
  const acts = new Set((r.d.records || []).map(x => x.action));
  check('аудит отдаётся', r.status === 200 && Array.isArray(r.d.records));
  for (const want of ['issue', 'activate', 'activate_denied', 'delete', 'ping_revoked',
                      'heartbeat_revoked', 'unrevoke', 'deactivate', 'keystatus_ok']) {
    check(`в аудите есть ${want}`, acts.has(want), [...acts].join(','));
  }
  check('в аудите пишется reason удаления',
        (r.d.records || []).some(x => x.action === 'delete' && /возврат средств/.test(x.detail || '')));
}

console.log('\n[13] Рейт-лимит защищает квоту D1');
{
  // отдельный воркер БЕЗ поднятых лимитов: здесь проверяется именно дефолт 8/мин.
  // Основной воркер в этом тесте намеренно работает с RL_ACTIVATE=5000, иначе
  // сквозной сценарий не проходит, и рейт-лимит остался бы непроверенным.
  const mfRl = new Miniflare({
    modules: true,
    scriptPath: path.join(DEPLOY, 'worker', 'src', 'index.mjs'),
    bindings: { VENDOR_PRIVATE_KEY_PEM: PY.priv, VENDOR_PUBLIC_KEY_PEM: PY.pub,
                ADMIN_TOKEN },
    d1Databases: { DB: 'flux-rl-test' },
  });
  const rlDb = await mfRl.getD1Database('DB');
  await rlDb.batch(splitSql(SCHEMA).map(s => rlDb.prepare(s)));

  const rlCall = async (p, body) => {
    const r = await mfRl.dispatchFetch('https://lic.test' + p, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + ADMIN_TOKEN },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    return { status: r.status, d: await r.json().catch(() => ({})) };
  };
  const r = await rlCall('/admin/api/issue', { plan: 'standard', devices: 1 });
  const k6 = r.d.issued[0].key;
  let limited = false, attempts = 0;
  for (let i = 0; i < 14; i++) {
    attempts++;
    const x = await rlCall('/v1/activate', { key: k6, hwid: 'c3'.repeat(16), hwid_variants: [] });
    if (x.status === 429) { limited = true; break; }
  }
  check('активации ограничены рейт-лимитом (8/мин)', limited === true,
        'за 14 попыток ни одного 429');
  check('лимит сработал примерно на 9-й попытке', attempts >= 8 && attempts <= 12,
        String(attempts));
  check('в 429 сказано подождать', /Подожди минуту|подожди/.test(
        (await rlCall('/v1/activate', { key: k6, hwid: 'c3'.repeat(16) })).d.message || ''),
        'текст 429 не внятный');
  await mfRl.dispose();
}

console.log('\n[14] Обработка ошибок конфигурации');
{
  const mf2 = new Miniflare({
    modules: true,
    scriptPath: path.join(DEPLOY, 'worker', 'src', 'index.mjs'),
    bindings: { VENDOR_PRIVATE_KEY_PEM: '', VENDOR_PUBLIC_KEY_PEM: '', ADMIN_TOKEN },
    d1Databases: { DB: 'flux-broken' },
  });
  const r = await mf2.dispatchFetch('https://lic.test/v1/activate', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
  });
  const d = await r.json();
  check('без приватного ключа — 503, а не «подпись недействительна»', r.status === 503, String(r.status));
  check('в ошибке сказано, какой секрет задать',
        /VENDOR_PRIVATE_KEY_PEM/.test(d.message || ''), d.message);
  await mf2.dispose();

  const mf3 = new Miniflare({
    modules: true,
    scriptPath: path.join(DEPLOY, 'worker', 'src', 'index.mjs'),
    bindings: { VENDOR_PRIVATE_KEY_PEM: 'это не PEM', VENDOR_PUBLIC_KEY_PEM: '', ADMIN_TOKEN },
    d1Databases: { DB: 'flux-bad-pem' },
  });
  const r3 = await mf3.dispatchFetch('https://lic.test/health');
  const d3 = await r3.json();
  check('битый PEM — 503 с внятным текстом', r3.status === 503 && /PEM/.test(d3.message || ''),
        `${r3.status} ${d3.message}`);
  await mf3.dispose();
}

console.log('\n[15] OPTIONS и неизвестные маршруты');
{
  const r = await mf.dispatchFetch('https://lic.test/v1/activate', { method: 'OPTIONS' });
  check('OPTIONS отдаёт 204 (CORS preflight)', r.status === 204, String(r.status));
  check('CORS-заголовки на месте', r.headers.get('Access-Control-Allow-Origin') === '*');
  const r2 = await call('/v1/нет-такого');
  check('неизвестный клиентский маршрут — 404', r2.status === 404, String(r2.status));
  const r3 = await call('/admin/api/нет-такого', {}, true);
  check('неизвестное админ-действие — 404', r3.status === 404, String(r3.status));
  const r4 = await call('/admin');
  check('веб-админка отдаётся', r4.status === 200 || (r4.d && r4.d.parse === 'не JSON'),
        String(r4.status));
}

await mf.dispose();
console.log(`\n${'='.repeat(64)}`);
console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
process.exit(FAIL.length ? 1 : 0);
