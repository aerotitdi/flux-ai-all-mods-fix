"""Генерирует эталонные значения планировщика из Python (license_server/sched.py).

Вызывается из sched_parity.test.mjs. Отдельный файл, а не `-c` строка: путь до
корня проекта нужно резолвить относительно расположения теста, и в `-c` это
превращается в нечитаемую кашу из экранированных кавычек.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
sys.path.insert(0, ROOT)

from license_server import sched          # noqa: E402

CLIENTS = [0, 1, 25, 50, 51, 100, 200, 201, 500, 501, 1000, 1001,
           1500, 3000, 5000, 10000]
KEYS = [f"KEY{i}" for i in range(200)] + ["ABC123DEF456", "", "x"]
SECS = [432000, 277200, 172800, 86400, 54000, 36000, 21600, 3600, 600, 60, 1, 0]

out = {
    "consts": {"MIN": sched.MIN_INTERVAL_H, "MAX": sched.MAX_INTERVAL_H,
               "TTL": sched.TICKET_TTL_H, "PING_BYTES": sched.PING_BYTES},
    "target": {str(c): sched.target_interval_hours(c) for c in CLIENTS},
    "jitter": {f"{c}|{k}": sched.jitter_hours(k, sched.target_interval_hours(c) * 0.25)
               for c in (500, 1500) for k in KEYS[:60]},
    "next": {f"{c}|{k}": sched.next_check_in_seconds(c, k) for c in CLIENTS for k in KEYS},
    "human": {str(s): sched.humanize_left(s) for s in SECS},
    "load": {str(c): sched.estimate_load(c) for c in CLIENTS},
}
print(json.dumps(out, ensure_ascii=False))
