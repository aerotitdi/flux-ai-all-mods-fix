// Harness для сверки планировщика: повторяет вычисления sched.mjs для всех
// входных значений, которые прислал Python-эталон, и возвращает их одним JSON.
//
// Отдельный файл потому, что miniflare не резолвит import в строковом скрипте —
// а нам нужны именно НАСТОЯЩИЕ модули воркера, а не их копия: тест проверяет,
// что две реализации одной формулы не разъехались.
import * as S from '../src/sched.mjs';

export default {
  async fetch(request) {
    const PY = await request.json();
    const out = {
      consts: { MIN: S.MIN_INTERVAL_H, MAX: S.MAX_INTERVAL_H,
                TTL: S.TICKET_TTL_H, PING_BYTES: S.PING_BYTES },
      target: {}, jitter: {}, next: {}, human: {}, load: {},
    };
    for (const k of Object.keys(PY.target)) out.target[k] = S.targetIntervalHours(Number(k));
    for (const k of Object.keys(PY.jitter)) {
      const [clients, keyId] = k.split('|');
      out.jitter[k] = S.jitterHours(keyId, S.targetIntervalHours(Number(clients)) * 0.25);
    }
    for (const k of Object.keys(PY.next)) {
      const [clients, keyId] = k.split('|');
      out.next[k] = S.nextCheckInSeconds(Number(clients), keyId);
    }
    for (const k of Object.keys(PY.human)) out.human[k] = S.humanizeLeft(Number(k));
    for (const k of Object.keys(PY.load)) out.load[k] = S.estimateLoad(Number(k));
    return new Response(JSON.stringify(out), {
      headers: { 'Content-Type': 'application/json' },
    });
  },
};
