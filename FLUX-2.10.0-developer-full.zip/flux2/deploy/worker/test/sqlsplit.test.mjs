// Тест разбора SQL-скрипта на утверждения.
//
// Зачем отдельный тест: наивный split(';') + «отбросить блок, начинающийся с
// комментария» молча выбрасывал CREATE TABLE из deploy/schema.sql, потому что
// каждый блок схемы предваряется комментарием. Схема «применялась» без ошибок, но
// без единой таблицы — а выяснялось это только на первом запросе.
//
// Запуск:  cd deploy && node worker/test/sqlsplit.test.mjs

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { splitSql } from '../src/sqlsplit.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DEPLOY = path.resolve(HERE, '..', '..');

const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

const SCHEMA = fs.readFileSync(path.join(DEPLOY, 'schema.sql'), 'utf8');

console.log('\n[1] Разбор реальной схемы deploy/schema.sql');
const stmts = splitSql(SCHEMA);
check('утверждений больше нуля', stmts.length > 0, String(stmts.length));
check('нет пустых утверждений', stmts.every(s => s.length > 0));
check('ни одно не начинается с комментария',
      stmts.every(s => !s.startsWith('--')),
      stmts.find(s => s.startsWith('--'))?.slice(0, 80));
check('все 5 CREATE TABLE на месте',
      ['licenses', 'activations', 'audit', 'poll_buckets', 'rl']
        .every(t => stmts.some(s => new RegExp(`CREATE TABLE IF NOT EXISTS ${t}\\b`).test(s))),
      stmts.filter(s => s.includes('CREATE TABLE')).map(s => s.slice(0, 50)).join(' | '));
check('все CREATE INDEX на месте',
      stmts.filter(s => s.startsWith('CREATE INDEX')).length >= 5,
      String(stmts.filter(s => s.startsWith('CREATE INDEX')).length));
check('многострочные CREATE TABLE не разорваны',
      stmts.filter(s => s.includes('CREATE TABLE')).every(s => /\)\s*$/.test(s.trim()) || s.includes(');') || s.trim().endsWith(')')),
      stmts.find(s => s.includes('CREATE TABLE'))?.slice(-60));
check('внутри утверждений не осталось ";" в конце',
      stmts.every(s => !s.trim().endsWith(';')), stmts[0]?.slice(-30));

console.log('\n[2] Синтаксические ловушки');
{
  const tricky = [
    "-- комментарий с точкой с запятой; вот так\nCREATE TABLE a(x INTEGER);",
    "CREATE TABLE b(s TEXT DEFAULT 'a;b');",
    "INSERT INTO a(x) VALUES('многострочный\nтекст; с точкой');",
    "-- только комментарий, без SQL",
    "",
    "  \n  ",
    "CREATE INDEX i ON a(x);",
  ].join('\n');
  const got = splitSql(tricky);
  check('комментарий с «;» не создаёт лишнее утверждение',
        got.filter(s => s.includes('CREATE TABLE a')).length === 1, JSON.stringify(got));
  check('строковый литерал с «;» не рвёт утверждение',
        got.some(s => s.includes("DEFAULT 'a;b'")), JSON.stringify(got));
  check('блок «только комментарий» отброшен',
        !got.some(s => s.includes('только комментарий')), JSON.stringify(got));
  check('пустые блоки отброшены', got.every(s => s.trim().length > 0));
  check('CREATE INDEX выжил', got.some(s => s.startsWith('CREATE INDEX')), JSON.stringify(got));
}

console.log('\n[3] Разбор дампа миграции (если он есть)');
{
  const dumpPath = process.env.FLUX_MIGRATION_DUMP;
  if (!dumpPath || !fs.existsSync(dumpPath)) {
    console.log('  (пропущено: задай FLUX_MIGRATION_DUMP=/path/to/dump.sql)');
  } else {
    const d = splitSql(fs.readFileSync(dumpPath, 'utf8'));
    check('дамп разобрался на утверждения', d.length > 0, String(d.length));
    check('все утверждения — INSERT', d.every(s => s.startsWith('INSERT INTO')),
          d.find(s => !s.startsWith('INSERT INTO'))?.slice(0, 80));
    check('каждый INSERT заканчивается на ")"', d.every(s => s.trim().endsWith(')')),
          d[0]?.slice(-40));
    check('в дампе нет приватного ключа',
          !fs.readFileSync(dumpPath, 'utf8').includes('PRIVATE KEY'));
  }
}

console.log(`\n${'='.repeat(64)}`);
console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
process.exit(FAIL.length ? 1 : 0);
