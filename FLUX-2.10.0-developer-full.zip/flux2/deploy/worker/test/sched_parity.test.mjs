// Сверка планировщика нагрузки: Worker (sched.mjs) против Python (license_server/sched.py).
//
// ЗАЧЕМ ОТДЕЛЬНЫЙ ТЕСТ
// --------------------
// Формула дозирования существует в ДВУХ реализациях: на Python (локальный сервер
// лицензий) и на JS (Cloudflare Worker), потому что запускать Python внутри
// Workers нельзя. Если они разъедутся, клиент при переезде на Cloudflare начнёт
// получать другие интервалы — например, опрос чаще, чем заложено в бюджет D1, и
// квота кончится в середине месяца.
//
// Сверяем 3248 значений next_check_in, все ступени, джиттер, humanize и прогноз
// нагрузки. Эталон генерирует Python, Worker обязан совпасть ДО ПОСЛЕДНЕГО ЧИСЛА.
//
// Запуск:  cd deploy && node worker/test/sched_parity.test.mjs

import { Miniflare } from 'miniflare';
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..', '..');
const DEPLOY = path.resolve(HERE, '..', '..');

const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

// --- эталон из Python --------------------------------------------------------
const PY = JSON.parse(execFileSync('python3', [path.join(HERE, '_gen_sched_ref.py')],
                                   { encoding: 'utf8', cwd: ROOT }).trim().split('\n').pop());

// --- те же вычисления в рантайме Workers -------------------------------------
const mf = new Miniflare({
  modules: true,
  scriptPath: path.join(HERE, 'sched_harness.mjs'),
});
const r = await mf.dispatchFetch('https://t/', {
  method: 'POST', body: JSON.stringify(PY),
});
const W = await r.json();
await mf.dispose();

console.log('\n[1] Константы совпадают');
check('MIN_INTERVAL_H', W.consts.MIN === PY.consts.MIN, `${W.consts.MIN} vs ${PY.consts.MIN}`);
check('MAX_INTERVAL_H', W.consts.MAX === PY.consts.MAX, `${W.consts.MAX} vs ${PY.consts.MAX}`);
check('TICKET_TTL_H', W.consts.TTL === PY.consts.TTL, `${W.consts.TTL} vs ${PY.consts.TTL}`);
check('PING_BYTES', W.consts.PING_BYTES === PY.consts.PING_BYTES,
      `${W.consts.PING_BYTES} vs ${PY.consts.PING_BYTES}`);
check('окно билета больше макс. интервала', W.consts.TTL > W.consts.MAX);
check('запас окна >= 24 ч', W.consts.TTL - W.consts.MAX >= 24);

console.log('\n[2] Целевой интервал по числу клиентов');
const tgtKeys = Object.keys(PY.target);
let tgtBad = tgtKeys.filter(k => W.target[k] !== PY.target[k]);
check(`все ${tgtKeys.length} ступеней совпадают`, tgtBad.length === 0,
      tgtBad.map(k => `${k}: js=${W.target[k]} py=${PY.target[k]}`).join('; '));
check('интервал монотонно не убывает с ростом клиентов',
      tgtKeys.map(k => W.target[k]).every((v, i, a) => i === 0 || v >= a[i - 1]));
check('интервал всегда в границах 5-72 ч',
      tgtKeys.every(k => W.target[k] >= 5 && W.target[k] <= 72));

console.log('\n[3] Джиттер (детерминированный, по key_id)');
const jKeys = Object.keys(PY.jitter);
const jBad = jKeys.filter(k => Math.abs(W.jitter[k] - PY.jitter[k]) > 1e-9);
check(`все ${jKeys.length} значений джиттера совпадают`, jBad.length === 0,
      jBad.slice(0, 5).map(k => `${k}: js=${W.jitter[k]} py=${PY.jitter[k]}`).join('; '));
check('джиттер не нулевой (стадо рассеивается)',
      new Set(jKeys.map(k => W.jitter[k])).size > jKeys.length * 0.5);
check('джиттер в пределах ±25% от целевого',
      jKeys.every(k => {
        const c = Number(k.split('|')[0]);
        const t = W.target[String(c)];
        return Math.abs(W.jitter[k]) <= t * 0.25 + 1e-9;
      }));

console.log('\n[4] next_check_in_seconds — главное число, которое получает клиент');
const nKeys = Object.keys(PY.next);
const nBad = nKeys.filter(k => W.next[k] !== PY.next[k]);
check(`все ${nKeys.length} значений next_check_in совпадают`, nBad.length === 0,
      `${nBad.length} расхождений: ` +
      nBad.slice(0, 5).map(k => `${k}: js=${W.next[k]} py=${PY.next[k]}`).join('; '));
check('все значения в границах 5-72 ч',
      nKeys.every(k => W.next[k] >= 5 * 3600 && W.next[k] <= 72 * 3600));
check('для одного клиента значение стабильно',
      W.next['1500|KEY7'] === W.next['1500|KEY7']);
const uniq1500 = new Set(nKeys.filter(k => k.startsWith('1500|')).map(k => W.next[k]));
check('у 1500 клиентов разные интервалы (не все придут одновременно)',
      uniq1500.size > 20, String(uniq1500.size));

console.log('\n[5] humanize_left — текст отсчёта у пользователя');
const hKeys = Object.keys(PY.human);
const hBad = hKeys.filter(k => W.human[k] !== PY.human[k]);
check(`все ${hKeys.length} формулировок совпадают`, hBad.length === 0,
      hBad.map(k => `${k}с: js=${W.human[k]} py=${PY.human[k]}`).join('; '));
check('5 суток -> «5 дн»', W.human['432000'] === '5 дн', W.human['432000']);
check('0 -> «0 ч»', W.human['0'] === '0 ч', W.human['0']);

console.log('\n[6] Прогноз нагрузки (показывается в админке)');
const lKeys = Object.keys(PY.load);
let lBad = [];
for (const k of lKeys) {
  for (const f of Object.keys(PY.load[k])) {
    if (W.load[k][f] !== PY.load[k][f]) lBad.push(`${k}.${f}: js=${W.load[k][f]} py=${PY.load[k][f]}`);
  }
}
check(`прогноз совпадает по всем ${lKeys.length} точкам`, lBad.length === 0, lBad.slice(0, 6).join('; '));
check('1500 клиентов: чтения D1 < 1% free tier',
      W.load['1500'].d1_read_pct_of_free < 1, String(W.load['1500'].d1_read_pct_of_free));
check('1500 клиентов: записи D1 < 20% free tier',
      W.load['1500'].d1_write_pct_of_free < 20, String(W.load['1500'].d1_write_pct_of_free));
check('1500 клиентов: трафик < 10 МБ/мес',
      W.load['1500'].mb_per_month < 10, String(W.load['1500'].mb_per_month));
check('10000 клиентов: записи всё ещё < 100% free tier',
      W.load['10000'].d1_write_pct_of_free < 100, String(W.load['10000'].d1_write_pct_of_free));

console.log(`\n${'='.repeat(64)}`);
console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
process.exit(FAIL.length ? 1 : 0);
