// Тесты FLUX License Server на Cloudflare Workers.
//
// ЗАЧЕМ ЗАПУСКАЕМ В РАНИМТЕ WORKERS, А НЕ В NODE
// ----------------------------------------------
// Ed25519 здесь вызывается как "NODE-ED25519" — это legacy-имя WebCrypto, которое
// поддерживает Cloudflare Workers, но НЕ поддерживает Node.js. Поэтому тест в Node
// упал бы с NotSupportedError, ничего не проверив. Поднимаем workerd (настоящий
// рантайм Workers, тот же, что в продакшене) через miniflare и гоняем код в нём.
//
// ЧТО ПРОВЕРЯЕМ (это цена ошибки — все покупатели теряют лицензии)
// ---------------------------------------------------------------
//  1. Worker подписывает билет БАЙТ-В-БАЙТ как license_server/crypto.py, и
//     Python-клиент принимает эту подпись. Если канонический JSON разъедется хоть
//     на пробел — после переезда на Workers отвалятся все существующие клиенты.
//  2. Python-подпись проверяется в Worker'е (обратная совместимость).
//  3. Подделку/продление билета Worker отвергает.
//  4. Формат ключа, извлечение из письма, тексты причин совпадают с Python.
//
// Запуск:  cd deploy/worker && node test/crypto_parity.test.mjs
//          (нужны miniflare + wrangler: npm install в каталоге deploy)

import { Miniflare } from 'miniflare';
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..', '..');            // .../flux2
const DEPLOY = path.resolve(ROOT, 'deploy');

const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

// --- эталон из Python: ключи вендора, подпись, формат ------------------------
const py = execFileSync('python3', ['-c', `
import json, sys, os
sys.path.insert(0, ${JSON.stringify(ROOT)})
from license_server import crypto, keys
if not keys.exists(): keys.init()
sk = keys.load_private_key()
key = crypto.make_key()
payload = {"v":1,"kid":"ABC123DEF456","hwid":"ab"*32,"plan":"pro",
           "customer":"Иван Петров <i@x.ru>","issued":1760000000,"expires":0,
           "offline_until":1760432000,"nonce":"deadbeef01",
           "extra":{"license":"ABC123DEF456"}}
print(json.dumps({
  "priv_pem": open(keys.PRIV_PATH, encoding="utf-8").read(),
  "pub_pem":  open(keys.PUB_PATH,  encoding="utf-8").read(),
  "payload":  payload,
  "sig_py":   crypto.sign(sk, payload),
  "canon_py": crypto.canonical_json(payload),
  "key": key,
  "key_id": crypto.key_id(key),
  "key_hash": crypto.key_hash(key),
  "extract": crypto.extract_key("Ваш ключ: " + key + " — сохраните его"),
  "revoke_del": crypto.revoke_message("deleted", "возврат средств"),
  "revoke_sus": crypto.revoke_message("suspended", ""),
  "revoke_sus_r": crypto.revoke_message("suspended", "оплата не подтверждена"),
  "fp": crypto.key_id(open(keys.PUB_PATH, encoding="utf-8").read().strip()),
}, ensure_ascii=False))
`], { encoding: 'utf8', cwd: ROOT });
const PY = JSON.parse(py.trim().split('\n').pop());

// --- поднимаем настоящий рантайм Workers (workerd) ---------------------------
// scriptPath указывает на test/harness.js: miniflare резолвит его import'ы
// относительно этого файла, поэтому воркер тянет НАСТОЯЩИЕ src/crypto.js и
// src/sched.js, а не их копию.
const mf = new Miniflare({
  modules: true,
  scriptPath: path.join(HERE, 'harness.mjs'),
  bindings: { PRIV: PY.priv_pem, PUB: PY.pub_pem },
});

const res = await mf.dispatchFetch('https://test.local/', {
  method: 'POST',
  body: JSON.stringify({ payload: PY.payload, sig_py: PY.sig_py, key: PY.key,
                         now: Math.floor(Date.now() / 1000) }),
});
const W = await res.json();

console.log('\n[1] Подпись билета совместима с Python-клиентом');
check('canonical JSON совпадает байт-в-байт', W.canon === PY.canon_py,
      `\n    py: ${PY.canon_py}\n    js: ${W.canon}`);
check('Ed25519-подпись совпадает байт-в-байт', W.sig === PY.sig_py,
      `\n    py: ${PY.sig_py}\n    js: ${W.sig}`);
check('Worker проверил подпись, сделанную Python', W.verifies_python === true);
check('Worker отверг подмену plan', W.rejects_tampered_plan === true);
check('Worker отверг продление offline_until', W.rejects_extended_window === true);
check('Worker отверг испорченную подпись', W.rejects_bad_sig === true);
check('Worker отверг отсутствие подписи', W.rejects_no_sig === true);

console.log('\n[2] Формат ключа совпадает с app/license_fmt.py');
check('normalizeKey', W.normalize === PY.key, `${W.normalize} != ${PY.key}`);
check('извлечение из текста письма', W.extract === PY.extract, `${W.extract}`);
check('извлечение из нижнего регистра', W.extract_lower === PY.key);
check('извлечение с пробелами вместо дефисов', W.extract_spaces === PY.key);
check('мусор не принимается', W.extract_garbage === null, String(W.extract_garbage));
check('maskKey', W.mask.startsWith('FLX2-') && W.mask.includes('*****'), W.mask);
check('keyHash совпадает с Python', W.keyHash === PY.key_hash, W.keyHash);
check('keyId совпадает с Python', W.keyId === PY.key_id, `${W.keyId} != ${PY.key_id}`);

console.log('\n[3] Тексты причин совпадают с app/license_fmt.py');
check('deleted + причина', W.revoke_del === PY.revoke_del, `\n    ${W.revoke_del}\n    ${PY.revoke_del}`);
check('suspended без причины', W.revoke_sus === PY.revoke_sus, `\n    ${W.revoke_sus}\n    ${PY.revoke_sus}`);
check('suspended + причина', W.revoke_sus_r === PY.revoke_sus_r, `\n    ${W.revoke_sus_r}`);
check('normalizeKind', JSON.stringify(W.normalize_kind) === '["deleted","suspended","suspended","suspended"]',
      JSON.stringify(W.normalize_kind));
check('isPermanent', JSON.stringify(W.is_permanent) === '[true,false]', JSON.stringify(W.is_permanent));

console.log('\n[4] Билет Worker\'а принимает Python-клиент');
// проверяем той же функцией, что и app/licensing.py::_pub_standalone
fs.writeFileSync('/tmp/wticket.json', JSON.stringify(W.ticket));
const V = JSON.parse(execFileSync('python3', ['-c', `
import json, sys
sys.path.insert(0, ${JSON.stringify(ROOT)})
from license_server import crypto, keys
tk = json.load(open('/tmp/wticket.json', encoding='utf-8'))
pub = keys.load_public_key()
ok, why = crypto.verify_ticket(pub, tk, "ab"*32)
p = crypto.ticket_payload(tk)
print(json.dumps({"ok": ok, "why": why, "fields": sorted(p),
                  "plan": p.get("plan"), "expires": p.get("expires"),
                  "ttl_h": (p.get("offline_until",0) - p.get("issued",0))/3600,
                  "next_h": (p.get("next_check",0) - p.get("issued",0))/3600,
                  "nonce": bool(p.get("nonce")), "kid": p.get("kid")}, ensure_ascii=False))
`], { encoding: 'utf8', cwd: ROOT }).trim().split('\n').pop());

check('Python-клиент принял билет Worker\'a', V.ok === true, `${V.ok} / ${V.why}`);
check('в билете есть v', W.ticket_payload.v === 1);
check('в билете есть kid', W.ticket_payload.kid === PY.key_id, String(W.ticket_payload.kid));
check('в билете есть hwid', W.ticket_payload.hwid === 'ab'.repeat(32));
check('в билете есть plan', W.ticket_payload.plan === 'pro');
check('в билете есть nonce (защита от копирования)', V.nonce === true);
check('в билете есть extra.license', W.ticket_payload.extra?.license === 'ABC123DEF456');
check('набор полей совпадает с crypto.make_ticket',
      JSON.stringify(V.fields) === JSON.stringify(
        ['customer','expires','extra','hwid','issued','kid','next_check','nonce','offline_until','plan','v']),
      JSON.stringify(V.fields));
check('окно билета = 5 суток (120 ч)', V.ttl_h === 120, String(V.ttl_h));
check('next_check внутри подписи = 12 ч', V.next_h === 12, String(V.next_h));

console.log('\n[5] Планировщик нагрузки (рандом 5-72 ч по числу клиентов)');
check('TTL билета = 120 ч', W.ttl === 120, String(W.ttl));
check('границы интервала 5-72 ч', JSON.stringify(W.bounds) === '[5,72]', JSON.stringify(W.bounds));
check('TTL > максимального интервала (иначе честный клиент блокируется)',
      W.ttl > W.bounds[1], `${W.ttl} vs ${W.bounds[1]}`);
check('запас окна над макс. интервалом >= 24 ч', W.ttl - W.bounds[1] >= 24,
      String(W.ttl - W.bounds[1]));
check('интервал растёт с числом клиентов',
      W.target.every((v, i) => i === 0 || v >= W.target[i - 1]), JSON.stringify(W.target));
check('интервал не выходит за 5-72 ч',
      W.target.every(v => v >= 5 && v <= 72), JSON.stringify(W.target));
// target построен для [1, 50, 51, 100, 200, 500, 1000, 1500, 5000]
const TGT = { 1: 6, 50: 6, 51: 12, 100: 12, 200: 12, 500: 24, 1000: 48, 1500: 72, 5000: 72 };
const TGT_KEYS = Object.keys(TGT).map(Number);
check('интервалы по ступеням верны',
      JSON.stringify(W.target) === JSON.stringify(TGT_KEYS.map(k => TGT[k])),
      JSON.stringify(W.target));
check('1500 клиентов -> 72 ч', W.target[TGT_KEYS.indexOf(1500)] === 72,
      String(W.target[TGT_KEYS.indexOf(1500)]));
check('1 клиент -> 6 ч (отзыв быстрый, пока клиентов мало)',
      W.target[0] === 6, String(W.target[0]));
check('джиттер рассеивает стадо (много уникальных интервалов)',
      W.jitter_unique > 50, String(W.jitter_unique));
check('джиттер стабилен для одного клиента', W.jitter_stable === true);
check('джиттер держится в границах 5-72 ч',
      W.jitter_min >= 5 && W.jitter_max <= 72, `${W.jitter_min}-${W.jitter_max}`);

console.log('\n[6] Квоты D1 (free: 5 млн чтений, 100 тыс записей в день)');
const L = W.load.l1500;
check('1500 клиентов: чтения < 1% квоты', L.d1_read_pct_of_free < 1, String(L.d1_read_pct_of_free));
check('5000 клиентов: чтения всё ещё < 1% квоты',
      W.load.l5000.d1_read_pct_of_free < 1, String(W.load.l5000.d1_read_pct_of_free));
check('5000 клиентов: записи < 50% квоты',
      W.load.l5000.d1_write_pct_of_free < 50, String(W.load.l5000.d1_write_pct_of_free));
check('1500 клиентов: записи < 20% квоты', L.d1_write_pct_of_free < 20, String(L.d1_write_pct_of_free));
check('1500 клиентов: трафик < 50 МБ/мес', L.mb_per_month < 50, String(L.mb_per_month));
check('трафик на порядок меньше старого heartbeat (856 Б -> 325 Б)',
      L.bytes_per_poll < 400, String(L.bytes_per_poll));
console.log(`      (1500 клиентов: ${L.polls_per_day} опросов/день, ` +
            `${L.d1_reads_per_day} чтений, ${L.mb_per_month} МБ/мес)`);

console.log('\n[7] Обратный отсчёт для пользователя');
check('5 суток -> «5 дн»', W.human[0] === '5 дн', W.human[0]);
check('3 суток -> «3 дн»', W.human[1] === '3 дн', W.human[1]);
check('1 сутки -> «1 дн»', W.human[2] === '1 дн', W.human[2]);
check('15 ч -> «15 ч»', W.human[3] === '15 ч', W.human[3]);
check('10 ч -> «10 ч»', W.human[4] === '10 ч', W.human[4]);
check('1 мин -> «1 мин»', W.human[7] === '1 мин', W.human[7]);
check('0 -> «0 ч» (конец)', W.human[8] === '0 ч', W.human[8]);

await mf.dispose();
console.log(`\n${'='.repeat(64)}`);
console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
process.exit(FAIL.length ? 1 : 0);
