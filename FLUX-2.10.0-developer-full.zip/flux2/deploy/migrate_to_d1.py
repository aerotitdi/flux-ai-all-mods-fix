#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Перенос базы лицензий с локального SQLite на Cloudflare D1.

Зачем: сервер лицензий раньше слушал 127.0.0.1:8790, то есть работал на твоём ПК.
Выключенный ПК = покупатели не могут активировать ключ, а по истечении окна
билета FLUX у них блокируется. После переезда на Workers покупатели от твоего
компьютера не зависят вовсе.

Что делает:
  1. читает локальную базу (license_server/data/licenses.db);
  2. генерирует SQL-дамп, совместимый с D1;
  3. применяет его через `wrangler d1 execute --remote` (или --local для прогона).

Ключи и хеши переносятся КАК ЕСТЬ: в базе лежат только sha256-хеши, поэтому
существующие покупатели продолжают работать со своими ключами — перевыпускать
ничего не нужно.

Запуск:
  # сначала репетиция на локальной D1 (ничего не ломает)
  python deploy/migrate_to_d1.py --local

  # затем боевой перенос
  python deploy/migrate_to_d1.py --remote

  # только сгенерировать дамп, не применять
  python deploy/migrate_to_d1.py --dump-only --out /tmp/dump.sql

ВАЖНО: приватный ключ вендора НЕ переносится этим скриптом и не должен попадать
в дамп. Его задают отдельно секретом Worker'а:
  npx wrangler secret put VENDOR_PRIVATE_KEY_PEM
"""
from __future__ import annotations

import argparse
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEFAULT_DB = os.path.join(ROOT, "license_server", "data", "licenses.db")
SCHEMA = os.path.join(HERE, "schema.sql")
D1_NAME = "flux-licenses"

# Таблицы, которые переносятся. `rl` и `poll_buckets` — служебные окна Worker'а,
# в локальной базе их нет, и переносить их смысла нет.
TABLES = ("licenses", "activations", "audit")

# В D1 нет AUTOINCREMENT-семантики для уже вставленных id, поэтому id переносим
# явно — иначе журнал аудита потеряет порядок.
COLUMNS = {
    "licenses": ("key_hash", "key_id", "plan", "customer", "note", "issued_at",
                 "expires_at", "max_activations", "offline_days", "status",
                 "revoked_at", "revoke_reason", "revoke_kind", "last_seen"),
    "activations": ("id", "key_hash", "hwid", "hwid_label", "variants", "activated_at",
                    "last_seen", "ticket_exp", "released", "app_version"),
    "audit": ("id", "ts", "key_id", "action", "hwid", "ip", "detail"),
}


def log(msg: str = "") -> None:
    print(f"[migrate] {msg}" if msg else "", flush=True)


def die(msg: str, code: int = 1) -> None:
    print(f"\n[migrate] ОШИБКА: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


def sql_literal(v) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def read_local(path: str) -> dict:
    if not os.path.exists(path):
        die(f"локальная база не найдена: {path}\n"
            "       Если сервер лицензий ещё не запускался, переносить нечего — "
            "сразу применяй deploy/schema.sql.")
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    out = {}
    have = {r["name"] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    for t in TABLES:
        if t not in have:
            log(f"⚠ в локальной базе нет таблицы {t} — пропускаю")
            out[t] = []
            continue
        cols = [c["name"] for c in con.execute(f"PRAGMA table_info({t})")]
        want = [c for c in COLUMNS[t] if c in cols]
        rows = con.execute(f"SELECT {', '.join(want)} FROM {t}").fetchall()
        out[t] = [(want, [r[c] for c in want]) for r in rows]
    con.close()
    return out


def build_dump(data: dict) -> str:
    lines = ["-- Дамп базы лицензий FLUX для Cloudflare D1",
             f"-- создан: {time.strftime('%Y-%m-%d %H:%M:%S')}",
             f"-- источник: локальный SQLite, таблицы {', '.join(TABLES)}",
             ""]
    total = 0
    for t in TABLES:
        rows = data.get(t) or []
        if not rows:
            lines.append(f"-- {t}: пусто")
            continue
        cols = rows[0][0]
        lines.append(f"-- {t}: {len(rows)} строк")
        # батчами по 50 строк: D1 ограничивает размер одного запроса, а длинный
        # INSERT на 10 тысяч строк упрётся в лимит и уронит весь перенос
        for i in range(0, len(rows), 50):
            chunk = rows[i:i + 50]
            values = ", ".join("(" + ", ".join(sql_literal(v) for v in r[1]) + ")"
                               for r in chunk)
            lines.append(f"INSERT INTO {t}({', '.join(cols)}) VALUES {values};")
        total += len(rows)
    lines += ["", f"-- всего перенесено строк: {total}"]
    return "\n".join(lines) + "\n"


def sanity_check(dump: str, data: dict) -> None:
    """Проверяем, что в дамп НЕ попали секреты.

    Параноидально, но цена ошибки абсолютная: приватный ключ вендора в дампе,
    загруженном куда-либо, означает, что любой может напечатать себе лицензию.
    """
    bad = []
    if "BEGIN" in dump and "PRIVATE KEY" in dump:
        bad.append("в дампе есть PEM-блок приватного ключа")
    for token in ("VENDOR_PRIVATE", "passphrase", "admin_token", "ADMIN_TOKEN"):
        if token.lower() in dump.lower():
            bad.append(f"в дампе встречается {token}")
    if bad:
        die("\n".join(bad))
    n_lic = len(data.get("licenses") or [])
    if n_lic and "INSERT INTO licenses" not in dump:
        bad.append(f"в локальной базе {n_lic} лицензий, но в дампе нет ни одного INSERT")
    if bad:
        die("\n".join(bad))
    log(f"проверка на секреты: чисто (лицензий: {n_lic}, "
        f"активаций: {len(data.get('activations') or [])}, "
        f"записей журнала: {len(data.get('audit') or [])})")


def run_wrangler(args: list[str], cwd: str = HERE) -> subprocess.CompletedProcess:
    cmd = ["npx", "wrangler"] + args
    log("$ " + " ".join(cmd))
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0:
        tail = (r.stdout or "")[-2000:] + (r.stderr or "")[-2000:]
        die(f"wrangler завершился с кодом {r.returncode}:\n{tail}")
    return r


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=DEFAULT_DB, help="путь к локальной базе лицензий")
    ap.add_argument("--local", action="store_true", help="применить к локальной D1 (репетиция)")
    ap.add_argument("--remote", action="store_true", help="применить к боевой D1")
    ap.add_argument("--dump-only", action="store_true", help="только сгенерировать SQL")
    ap.add_argument("--out", default="", help="куда сохранить дамп (по умолчанию временный файл)")
    ap.add_argument("--skip-schema", action="store_true",
                    help="не применять schema.sql (таблицы уже созданы)")
    args = ap.parse_args(argv)

    if not args.dump_only and not (args.local or args.remote):
        die("укажи --local (репетиция), --remote (боевой перенос) или --dump-only")

    log(f"читаю локальную базу: {args.db}")
    data = read_local(args.db)
    dump = build_dump(data)
    sanity_check(dump, data)

    out = args.out
    keep = bool(out)
    if not out:
        fd, out = tempfile.mkstemp(suffix=".sql", prefix="flux-d1-dump-")
        os.close(fd)
    with open(out, "w", encoding="utf-8") as f:
        f.write(dump)
    log(f"дамп: {out} ({os.path.getsize(out) / 1024:.1f} КБ)")

    if args.dump_only:
        log("только дамп — ничего не применяю")
        return 0

    flag = "--local" if args.local else "--remote"
    if not args.skip_schema:
        log(f"применяю схему ({flag})")
        run_wrangler(["d1", "execute", D1_NAME, flag, "--file", SCHEMA])
    log(f"загружаю данные ({flag})")
    run_wrangler(["d1", "execute", D1_NAME, flag, "--file", out])

    log("")
    log("Готово. Проверь:")
    log(f"  npx wrangler d1 execute {D1_NAME} {flag} "
        "--command \"SELECT COUNT(*) AS n FROM licenses\"")
    log("")
    if args.remote:
        log("Что осталось сделать один раз (если ещё не сделано):")
        log("  npx wrangler secret put VENDOR_PRIVATE_KEY_PEM   <- из license_server/keys/")
        log("  npx wrangler secret put VENDOR_PUBLIC_KEY_PEM")
        log("  npx wrangler secret put ADMIN_TOKEN")
        log("  npx wrangler deploy")
        log("")
        log("⚠ Локальную базу НЕ удаляй, пока не убедишься, что Workers отвечает")
        log("  и существующие клиенты продлевают билеты.")
    if not keep:
        try:
            os.remove(out)
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
