"""Ключи вендора: генерация, хранение, встраивание публичного ключа в клиент.

РАСКЛАДКА (важно не перепутать):
  license_server/keys/vendor_private.pem  — приватный ключ. ТОЛЬКО на машине сборки
                                            или в HSM. В git НЕ попадает (см. .gitignore),
                                            в клиентскую поставку НЕ попадает НИКОГДА.
  license_server/keys/vendor_public.pem   — публичный ключ, копия.
  app/_vendor_key.py                      — публичный ключ как Python-константа.
                                            Генерируется автоматически командой
                                            `python -m license_server.keygen init`.
                                            Именно он встроен в клиент и проверяет
                                            подписи билетов офлайн.

Приватный ключ нужен только keygen'у и серверу лицензий. Утечка публичного ключа
не опасна по определению — им можно лишь проверять подписи.

Пароль на приватный ключ: `FLUX_VENDOR_KEY_PASS` (переменная окружения) или файл
`license_server/keys/passphrase.txt` с правами 0600. Без пароля ключ шифруется
BestAvailableEncryption, если пароль задан.
"""
from __future__ import annotations

import os
import stat
import sys
from typing import Optional

from . import crypto

HERE = os.path.dirname(os.path.abspath(__file__))
KEYS_DIR = os.path.join(HERE, "keys")
PRIV_PATH = os.path.join(KEYS_DIR, "vendor_private.pem")
PUB_PATH = os.path.join(KEYS_DIR, "vendor_public.pem")
PASS_PATH = os.path.join(KEYS_DIR, "passphrase.txt")

# куда встраивается публичный ключ для клиентской сборки
APP_DIR = os.path.normpath(os.path.join(HERE, os.pardir, "app"))
EMBED_PATH = os.path.join(APP_DIR, "_vendor_key.py")

EMBED_TEMPLATE = '''"""Публичный ключ вендора FLUX. СГЕНЕРИРОВАН АВТОМАТИЧЕСКИ — не правь руками.

Источник: license_server/keys.py (команда `python -m license_server.keygen init`).
Этим ключом клиент проверяет подписи билетов активации (app/licensing.py).
Подделать билет, не имея приватного ключа вендора, нельзя; замена этого файла
своим ключом потребует пересборки приложения, а не правки конфига.
"""
VENDOR_PUBLIC_KEY = """{pub}"""

VENDOR_KEY_FINGERPRINT = "{fp}"
GENERATED_AT = "{ts}"
'''


def _passphrase() -> Optional[bytes]:
    p = os.environ.get("FLUX_VENDOR_KEY_PASS")
    if p:
        return p.encode("utf-8")
    if os.path.exists(PASS_PATH):
        try:
            with open(PASS_PATH, "r", encoding="utf-8") as f:
                p = f.read().strip()
            return p.encode("utf-8") if p else None
        except OSError:
            return None
    return None


def exists() -> bool:
    return os.path.exists(PRIV_PATH) and os.path.exists(EMBED_PATH)


def _chmod_private() -> None:
    try:
        os.chmod(KEYS_DIR, 0o700)
        os.chmod(PRIV_PATH, stat.S_IRUSR | stat.S_IWUSR)      # 0600
        if os.path.exists(PASS_PATH):
            os.chmod(PASS_PATH, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def init(force: bool = False, embed: bool = True) -> dict:
    """Создать пару ключей вендора и встроить публичный в app/_vendor_key.py.

    force=True перезаписывает пару — ВСЕ выданные ранее лицензии перестанут
    проверяться. Используется только при компрометации ключа.
    """
    if exists() and not force:
        return {"created": False, "path": PRIV_PATH, "embed": EMBED_PATH,
                "note": "пара ключей уже есть; используй --force для пересоздания "
                        "(старые лицензии перестанут проверяться)"}
    crypto.secure_dir(KEYS_DIR)
    priv_pem, pub_pem = crypto.generate_vendor_keypair()

    passw = _passphrase()
    from cryptography.hazmat.primitives import serialization
    sk = crypto.load_private(priv_pem)
    if passw:
        priv_pem = sk.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.BestAvailableEncryption(passw)).decode()

    with open(PRIV_PATH, "w", encoding="utf-8") as f:
        f.write(priv_pem)
    with open(PUB_PATH, "w", encoding="utf-8") as f:
        f.write(pub_pem)
    _chmod_private()

    fp = crypto.key_id(pub_pem.strip())
    out = {"created": True, "path": PRIV_PATH, "pub": PUB_PATH,
           "fingerprint": fp, "encrypted": bool(passw)}
    if embed:
        out["embed"] = embed_public(pub_pem, fp)
    return out


def embed_public(pub_pem: str, fp: str = "") -> str:
    """Записать публичный ключ в app/_vendor_key.py (его и видит клиент)."""
    os.makedirs(APP_DIR, exist_ok=True)
    fp = fp or crypto.key_id(pub_pem.strip())
    with open(EMBED_PATH, "w", encoding="utf-8") as f:
        f.write(EMBED_TEMPLATE.format(pub=pub_pem.strip(), fp=fp, ts=crypto.now_iso()))
    return EMBED_PATH


def load_private_key():
    """Приватный ключ (нужен keygen'у и серверу лицензий)."""
    if not os.path.exists(PRIV_PATH):
        raise crypto.LicenseCryptoError(
            f"нет приватного ключа: {PRIV_PATH}\n"
            f"Создай его: python -m license_server.keygen init")
    with open(PRIV_PATH, "r", encoding="utf-8") as f:
        pem = f.read()
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    try:
        return load_pem_private_key(pem.encode(), password=_passphrase())
    except TypeError as e:
        raise crypto.LicenseCryptoError(
            "приватный ключ зашифрован, но пароль не найден. Задай FLUX_VENDOR_KEY_PASS "
            f"или создай {PASS_PATH}") from e


def load_public_key():
    """Публичный ключ вендора. Приоритет — встроенная константа (как в клиенте),
    иначе файл keys/vendor_public.pem."""
    pem = read_embedded_public()
    if not pem and os.path.exists(PUB_PATH):
        with open(PUB_PATH, "r", encoding="utf-8") as f:
            pem = f.read()
    if not pem:
        raise crypto.LicenseCryptoError(
            "публичный ключ не найден. Выполни: python -m license_server.keygen init")
    return crypto.load_public(pem)


def read_embedded_public() -> str:
    """Прочитать VENDOR_PUBLIC_KEY из app/_vendor_key.py без импорта модуля."""
    if not os.path.exists(EMBED_PATH):
        return ""
    with open(EMBED_PATH, "r", encoding="utf-8") as f:
        src = f.read()
    ns: dict = {}
    try:
        exec(compile(src, EMBED_PATH, "exec"), {"__name__": "vendor_key"}, ns)
    except Exception as e:                            # pragma: no cover
        print(f"[keys] не удалось прочитать {EMBED_PATH}: {e}", file=sys.stderr)
        return ""
    return (ns.get("VENDOR_PUBLIC_KEY") or "").strip()


def fingerprint() -> str:
    pem = read_embedded_public()
    if not pem and os.path.exists(PUB_PATH):
        with open(PUB_PATH, "r", encoding="utf-8") as f:
            pem = f.read()
    return crypto.key_id(pem.strip()) if pem else ""
