"""Сервер лицензирования FLUX: активация, heartbeat, отзыв + веб-админка.

API клиента (без авторизации, но с рейт-лимитом):
  POST /v1/activate     {key, hwid, hwid_variants, hwid_label, app_version}
  POST /v1/heartbeat    {key|kid, hwid, ticket}
  POST /v1/keystatus    {key}                — статус ключа БЕЗ активации
  POST /v1/deactivate   {key, hwid}          — освободить место для переноса лицензии
  GET  /health

Когда ключ заблокирован, activate/heartbeat/keystatus отдают объект `revoke`:
  {"kind": "deleted"|"suspended", "reason": "возврат средств",
   "title": "Этот ключ доступа был удалён", "message": "… . Причина: …",
   "permanent": true, "revoked_at": 1730000000, "key_id": "AB12CD34EF56"}
Клиент сохраняет его в data/license.json и показывает в окне активации, поэтому
причину видно и при следующем запуске — без обращения к серверу.

API админки (заголовок `Authorization: Bearer <токен>`):
  GET  /admin                      — веб-панель (admin.html)
  GET  /admin/api/stats
  GET  /admin/api/licenses?status=
  POST /admin/api/issue            {plan, days, devices, customer, note, offline}
  POST /admin/api/delete           {key_id, reason}  — УДАЛИТЬ ключ (навсегда)
  POST /admin/api/suspend          {key_id, reason}  — отозвать на неопределённое время
  POST /admin/api/revoke           {key_id, reason, kind?}
  POST /admin/api/unrevoke         {key_id}
  POST /admin/api/extend           {key_id, days}
  POST /admin/api/release          {key_id, hwid?}   — освободить устройство
  GET  /admin/api/audit?limit=

Запуск:  python -m license_server.keygen serve --host 0.0.0.0 --port 8790
Токен админки: FLUX_ADMIN_TOKEN или license_server/keys/admin_token.txt (0600).

Приватный ключ вендора читается из license_server/keys/ и наружу не отдаётся.
"""
from __future__ import annotations

import json
import os
import secrets
import time
from typing import Optional

from aiohttp import web

from . import crypto, keys
from .sched import (TICKET_TTL_H, estimate_load, humanize_left,
                    next_check_in_seconds, target_interval_hours)
from .store import (RK_DELETED, RK_SUSPENDED, LicenseStore,
                    ST_REVOKED)

DEFAULT_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "licenses.db")
ADMIN_HTML = os.path.join(os.path.dirname(os.path.abspath(__file__)), "admin.html")

# рейт-лимит активаций: защита от перебора и от «активировал 500 раз за минуту»
RL_WINDOW = 60.0
# Настраивается окружением: 8 активаций в минуту с одного IP достаточно человеку
# (опечатался пару раз) и мало для перебора. Нагрузочные тесты поднимают лимит.
RL_MAX_ACTIVATE = int(os.environ.get("FLUX_RL_ACTIVATE", 8))
RL_MAX_HEARTBEAT = int(os.environ.get("FLUX_RL_HEARTBEAT", 60))
# keystatus дёргается на каждое изменение поля ввода — лимит выше, чем у активации,
# но всё ещё недостаточный для перебора базы (ключ 19 случайных символов из 30).
RL_MAX_KEYSTATUS = int(os.environ.get("FLUX_RL_KEYSTATUS", 40))
# пинг дёргается чаще остальных (вотчдог просыпается каждые 10 минут), но на
# сервер он уходит только по предписанному сроку, поэтому 60/мин с запасом
RL_MAX_PING = int(os.environ.get("FLUX_RL_PING", 60))


class RateLimiter:
    def __init__(self):
        self._hits: dict[str, list[float]] = {}

    def allow(self, ip: str, limit: int, window: float = RL_WINDOW) -> bool:
        now = time.time()
        arr = [t for t in self._hits.get(ip, []) if now - t < window]
        if len(arr) >= limit:
            self._hits[ip] = arr
            return False
        arr.append(now)
        self._hits[ip] = arr
        if len(self._hits) > 4096:                      # не растить словарь вечно
            for k in [k for k, v in self._hits.items() if not v][:1024]:
                self._hits.pop(k, None)
        return True


RL = RateLimiter()


def _ip(request: web.Request) -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        return fwd.split(",")[0].strip()[:45]
    peer = request.transport.get_extra_info("peername") if request.transport else None
    return (peer[0] if peer else "?")[:45]


def _err(code: str, message: str, status: int = 400, **kw) -> web.Response:
    return web.json_response({"ok": False, "error": code, "message": message, **kw},
                             status=status)


# ============================================================ клиентское API
async def api_health(request: web.Request) -> web.Response:
    st: LicenseStore = request.app["store"]
    return web.json_response({"ok": True, "service": "flux-license", "version": 1,
                              "time": int(time.time()), "licenses": st.count(),
                              "key_fingerprint": keys.fingerprint()})


async def api_activate(request: web.Request) -> web.Response:
    st: LicenseStore = request.app["store"]
    priv = request.app["priv"]
    ip = _ip(request)
    if not RL.allow(ip, RL_MAX_ACTIVATE):
        st.audit("rate_limit", "", "", ip, "activate")
        return _err("rate_limited", "слишком много попыток активации. Подожди минуту.", 429)
    try:
        data = await request.json()
    except Exception:
        return _err("bad_request", "нужен JSON в теле запроса")

    raw_key = str(data.get("key") or "")
    key = crypto.normalize_key(raw_key)
    if not key:
        return _err("invalid_key", "ключ не прошёл проверку формата: " + crypto.key_hint(raw_key))

    hwid = str(data.get("hwid") or "").strip().lower()
    if len(hwid) < 16:
        return _err("bad_hwid", "не удалось снять отпечаток устройства (нет данных о железе)")
    variants = [str(v).strip().lower() for v in (data.get("hwid_variants") or []) if v]
    if hwid not in variants:
        variants.insert(0, hwid)

    rec = st.get_by_key(key)
    kid = crypto.key_id(key)
    if not rec:
        st.audit("activate_unknown", kid, hwid, ip, "ключ не найден в базе")
        return _err("invalid_key", "такого ключа не существует. Проверь, нет ли опечатки.", 404)

    rec = st.refresh_status(rec)
    if rec["status"] == ST_REVOKED:
        info = st.revoke_info(rec)
        st.audit("activate_denied", kid, hwid, ip, f"{info.get('kind')}: {info.get('reason')}")
        return _err("revoked", info.get("message") or "ключ заблокирован. Обратись к разработчику.",
                    403, revoke=info)
    if rec["expires_at"] and time.time() > rec["expires_at"]:
        st.audit("activate_denied", kid, hwid, ip, "истёк срок")
        return _err("expired", f"срок действия лицензии истёк "
                              f"{time.strftime('%d.%m.%Y', time.localtime(rec['expires_at']))}", 403)

    # --- привязка к устройству --------------------------------------------
    # Если это УЖЕ наше устройство (или замена одного компонента железа — вариант
    # HWID совпал), билет просто перевыпускается, место не тратится.
    # Иначе проверяем лимит: ключ активируется на max_activations устройствах,
    # и попытка активировать его на следующем получает 409 already_bound.
    existing = st.find_activation(rec["key_hash"], variants)
    migrated = False
    if existing and not existing.get("released") and existing["hwid"] != hwid:
        # та же машина, изменился один компонент железа -> переносим место,
        # а не занимаем второе (иначе одна машина съела бы весь лимит)
        migrated = st.move_activation(rec["key_hash"], existing["hwid"], hwid, variants,
                                      str(data.get("hwid_label") or "")[:120], 0,
                                      str(data.get("app_version") or "")[:32])
        st.audit("hwid_migrated", rec["key_id"], hwid, ip,
                 f"{existing['hwid'][:12]}… -> {hwid[:12]}…")
    if not existing or existing.get("released"):
        acts = st.activations(rec["key_hash"], active_only=True)
        if len(acts) >= int(rec["max_activations"]):
            others = ", ".join(a["hwid"][:12].upper() + "…" for a in acts[:3])
            st.audit("activate_denied", kid, hwid, ip,
                     f"лимит устройств ({rec['max_activations']}), занято: {others}")
            return _err("already_bound",
                        f"ключ уже активирован на другом устройстве ({others}). "
                        f"Лицензия привязывается к одному компьютеру при первом вводе. "
                        f"Чтобы перенести: на старом устройстве нажми «Деактивировать» "
                        f"или попроси разработчика освободить место.", 409,
                        bound=[{"hwid": a["hwid"], "label": a.get("hwid_label", ""),
                                "activated_at": a["activated_at"]} for a in acts])

    offline_days = max(1, int(rec["offline_days"]))
    expires = int(rec["expires_at"] or 0)
    clients = st.active_clients()
    next_in = next_check_in_seconds(clients, rec["key_id"])
    ticket = crypto.make_ticket(priv, key=key, hwid=hwid, plan=rec["plan"],
                                expires=expires, offline_days=offline_days,
                                customer=rec.get("customer") or "",
                                extra={"license": rec["key_id"]},
                                next_check=next_in)
    if not migrated:
        st.add_activation(rec["key_hash"], hwid, variants,
                          str(data.get("hwid_label") or "")[:120],
                          ticket_exp=int(time.time()) + offline_days * 86400,
                          app_version=str(data.get("app_version") or "")[:32])
    else:
        st.touch_activation(rec["key_hash"], hwid)
    st.refresh_status(rec)
    st.audit("activate", rec["key_id"], hwid, ip,
             f"plan={rec['plan']} offline={offline_days}d app={data.get('app_version', '')}")

    payload = crypto.ticket_payload(ticket)
    return web.json_response({
        "ok": True, "ticket": ticket, "plan": rec["plan"],
        "license_id": rec["key_id"], "expires": expires,
        "offline_until": payload.get("offline_until"),
        "heartbeat_hours": request.app["heartbeat_hours"],
        "hwid_migrated": migrated,
        # когда прийти снова и сколько живёт билет — клиент рисует по этому
        # обратный отсчёт и не дёргает сервер раньше срока
        "next_check_in": next_in,
        "next_check_in_hours": round(next_in / 3600, 1),
        "ticket_ttl_hours": TICKET_TTL_H,
        "seconds_left": offline_days * 86400,
        "left_human": humanize_left(offline_days * 86400),
        "active_clients": clients,
        "message": ("отпечаток устройства обновлён (изменился один компонент железа), "
                    "место в лицензии сохранено" if migrated else
                    "лицензия активирована и привязана к этому устройству"),
    })


async def api_heartbeat(request: web.Request) -> web.Response:
    st: LicenseStore = request.app["store"]
    priv = request.app["priv"]
    ip = _ip(request)
    if not RL.allow(ip, RL_MAX_HEARTBEAT):
        return _err("rate_limited", "слишком частые проверки", 429)
    try:
        data = await request.json()
    except Exception:
        return _err("bad_request", "нужен JSON")

    hwid = str(data.get("hwid") or "").strip().lower()
    ticket = data.get("ticket") or {}
    rec = None
    raw = str(data.get("key") or "")
    if raw:
        key = crypto.normalize_key(raw)
        if key:
            rec = st.get_by_key(key)
    if rec is None and isinstance(ticket, dict):
        kid = crypto.ticket_payload(ticket).get("kid")
        if kid:
            rec = st.get_by_id(kid)
    if rec is None:
        return _err("unknown", "не удалось определить лицензию", 404)

    rec = st.refresh_status(rec)
    if rec["status"] == ST_REVOKED:
        info = st.revoke_info(rec)
        st.audit("heartbeat_revoked", rec["key_id"], hwid, ip,
                 f"{info.get('kind')}: {info.get('reason')}")
        return web.json_response({"ok": False, "revoked": True,
                                  # `reason` — для обратной совместимости со старыми клиентами
                                  "reason": info.get("reason_text") or "",
                                  "revoke": info,
                                  "message": info.get("message")
                                             or "лицензия отозвана — приложение заблокировано"})
    if rec["expires_at"] and time.time() > rec["expires_at"]:
        return web.json_response({"ok": False, "expired": True,
                                  "message": "срок действия лицензии истёк"})

    pub = request.app["pub"]
    valid, why = crypto.verify_ticket(pub, ticket, hwid) if isinstance(ticket, dict) else (False, "нет билета")
    if valid:
        st.touch_activation(rec["key_hash"], hwid)
        if st.should_touch(rec):
            st.touch_license(rec["key_hash"])
        st.audit("heartbeat", rec["key_id"], hwid, ip, "билет действителен")
        clients = st.active_clients()
        next_in = next_check_in_seconds(clients, rec["key_id"])
        off = int(crypto.ticket_payload(ticket).get("offline_until") or 0)
        left = max(0, off - int(time.time())) if off else None
        return web.json_response({"ok": True, "revoked": False, "plan": rec["plan"],
                                  "expires": rec["expires_at"],
                                  "seconds_left": left,
                                  "left_human": humanize_left(left) if left is not None else None,
                                  "next_check_in": next_in,
                                  "next_check_in_hours": round(next_in / 3600, 1),
                                  "ticket_ttl_hours": TICKET_TTL_H,
                                  "active_clients": clients,
                                  "heartbeat_hours": round(next_in / 3600, 1)})

    # билет недействителен (истекло офлайн-окно, сменилось железо) -> перевыпуск,
    # но только если устройство уже зарегистрировано за этим ключом
    variants = [str(v).strip().lower() for v in (data.get("hwid_variants") or []) if v]
    if hwid and hwid not in variants:
        variants.insert(0, hwid)
    act = st.find_activation(rec["key_hash"], variants)
    if not act:
        st.audit("heartbeat_denied", rec["key_id"], hwid, ip, why)
        return _err("not_activated", f"это устройство не активировано данным ключом ({why}). "
                                     f"Выполни активацию заново.", 403)
    offline_days = max(1, int(rec["offline_days"]))
    clients = st.active_clients()
    next_in = next_check_in_seconds(clients, rec["key_id"])
    new_ticket = crypto.make_ticket(priv, key="", hwid=act["hwid"], plan=rec["plan"],
                                    expires=int(rec["expires_at"] or 0),
                                    offline_days=offline_days,
                                    customer=rec.get("customer") or "",
                                    extra={"license": rec["key_id"]},
                                    next_check=next_in)
    st.add_activation(rec["key_hash"], act["hwid"], variants, act.get("hwid_label") or "",
                      int(time.time()) + offline_days * 86400,
                      str(data.get("app_version") or "")[:32])
    st.audit("heartbeat_renew", rec["key_id"], act["hwid"], ip, f"причина перевыпуска: {why}")
    return web.json_response({"ok": True, "revoked": False, "renewed": True,
                              "ticket": new_ticket, "plan": rec["plan"],
                              "expires": rec["expires_at"],
                              "offline_until": crypto.ticket_payload(new_ticket).get("offline_until"),
                              "seconds_left": offline_days * 86400,
                              "left_human": humanize_left(offline_days * 86400),
                              "next_check_in": next_in,
                              "next_check_in_hours": round(next_in / 3600, 1),
                              "ticket_ttl_hours": TICKET_TTL_H,
                              "active_clients": clients,
                              "heartbeat_hours": round(next_in / 3600, 1)})


async def api_ping(request: web.Request) -> web.Response:
    """Дешёвая проверка «жив ли ключ» БЕЗ передачи билета.

    Зачем: heartbeat() каждый раз тащит на сервер весь подписанный билет —
    626 байт из 856 байт обмена. Пинг шлёт только key_id (~25 байт) и получает
    состояние (~240 байт). При 1500 клиентах это разница между гигабайтами и
    мегабайтами в месяц.

    Эквивалентен /v1/ping в deploy/worker/src/client.mjs: тот же контракт,
    чтобы клиент работал одинаково против обоих бэкендов.
    """
    st: LicenseStore = request.app["store"]
    ip = _ip(request)
    if not RL.allow(ip, RL_MAX_PING):
        return _err("rate_limited", "слишком частые проверки", 429)
    try:
        data = await request.json()
    except Exception:
        return _err("bad_request", "нужен JSON в теле запроса")

    kid = str(data.get("key_id") or data.get("kid") or "").upper()
    raw = str(data.get("key") or "")
    rec = st.get_by_id(kid) if kid else None
    if rec is None and raw:
        key = crypto.extract_key(raw) or crypto.normalize_key(raw)
        if key:
            rec = st.get_by_key(key)
    if rec is None:
        return _err("invalid_key", "лицензия не найдена", 404)

    rec = st.refresh_status(rec)
    clients = st.active_clients()
    next_in = next_check_in_seconds(clients, rec["key_id"])

    if rec["status"] == ST_REVOKED:
        info = st.revoke_info(rec)
        st.audit("ping_revoked", rec["key_id"], "", ip, f"{info.get('kind')}: {info.get('reason')}")
        return web.json_response({"ok": False, "revoked": True, "blocked": True,
                                  "revoke": info, "reason": info.get("reason_text") or "",
                                  "message": info.get("message") or "",
                                  "next_check_in": next_in}, status=403)

    exp = int(rec["expires_at"] or 0)
    if exp and time.time() > exp:
        return web.json_response({"ok": False, "expired": True, "blocked": True,
                                  "next_check_in": next_in,
                                  "message": "срок действия лицензии истёк"}, status=403)

    # сколько осталось жить билету — из подписанного offline_until, а не «на глаз»
    left = None
    ticket = data.get("ticket")
    if isinstance(ticket, dict):
        off = int(crypto.ticket_payload(ticket).get("offline_until") or 0)
        if off:
            left = max(0, off - int(time.time()))

    # last_seen пишем не чаще раза в час: экономим записи в базу
    if st.should_touch(rec):
        st.touch_license(rec["key_hash"])

    return web.json_response({
        "ok": True, "revoked": False, "blocked": False, "plan": rec["plan"],
        "key_id": rec["key_id"], "expires": exp,
        "next_check_in": next_in,
        "next_check_in_hours": round(next_in / 3600, 1),
        "ticket_ttl_hours": TICKET_TTL_H,
        "seconds_left": left,
        "left_human": humanize_left(left) if left is not None else None,
        "active_clients": clients,
        "heartbeat_hours": round(next_in / 3600, 1),
    })


async def api_keystatus(request: web.Request) -> web.Response:
    """Статус ключа БЕЗ активации.

    Нужен окну активации: пользователь вставляет ключ — и сразу видит, что с ним
    («удалён, причина: …», «отозван на неопределённое время», «истёк», «жив»),
    не занимая место в лицензии и не привязывая устройство. Это же позволяет
    показать причину после переустановки, когда локального состояния уже нет.

    Отдаём ТОЛЬКО факт существования и статус: ни план, ни срок, ни клиент,
    ни устройства наружу не уходят, чтобы эндпоинт нельзя было использовать
    для разведки по чужим лицензиям.
    """
    st: LicenseStore = request.app["store"]
    ip = _ip(request)
    if not RL.allow(ip, RL_MAX_KEYSTATUS):
        return _err("rate_limited", "слишком много запросов — подожди минуту", 429)
    try:
        data = await request.json()
    except Exception:
        return _err("bad_request", "нужен JSON в теле запроса")

    raw = str(data.get("key") or "")
    key = crypto.extract_key(raw)          # терпим вставку куском письма
    if not key:
        return _err("invalid_key", crypto.paste_hint(raw), 400,
                    hint=crypto.paste_hint(raw), format_ok=False)

    rec = st.get_by_key(key)
    kid = crypto.key_id(key)
    if not rec:
        st.audit("keystatus_unknown", kid, "", ip, "ключ не найден в базе")
        return _err("invalid_key", "такого ключа не существует. Проверь, нет ли опечатки.",
                    404, exists=False, format_ok=True, key_id=kid)

    rec = st.refresh_status(rec)
    out = {"ok": True, "exists": True, "format_ok": True, "key_id": rec["key_id"],
           "status": rec["status"], "blocked": False, "message": ""}
    if rec["status"] == ST_REVOKED:
        info = st.revoke_info(rec)
        out.update({"blocked": True, "revoked": True, "revoke": info,
                    "message": info.get("message") or ""})
        st.audit("keystatus_blocked", kid, "", ip,
                 f"{info.get('kind')}: {info.get('reason')}")
    elif rec["expires_at"] and time.time() > rec["expires_at"]:
        out.update({"blocked": True, "expired": True,
                    "message": "срок действия лицензии истёк "
                               + time.strftime("%d.%m.%Y", time.localtime(rec["expires_at"]))})
        st.audit("keystatus_expired", kid, "", ip, "истёк срок")
    else:
        out["message"] = "ключ действителен — можно активировать"
        st.audit("keystatus_ok", kid, "", ip, rec["status"])
    return web.json_response(out)


async def api_deactivate(request: web.Request) -> web.Response:
    st: LicenseStore = request.app["store"]
    ip = _ip(request)
    try:
        data = await request.json()
    except Exception:
        return _err("bad_request", "нужен JSON")
    key = crypto.normalize_key(str(data.get("key") or ""))
    hwid = str(data.get("hwid") or "").strip().lower()
    if not key or not hwid:
        return _err("bad_request", "нужны key и hwid")
    rec = st.get_by_key(key)
    if not rec:
        return _err("invalid_key", "ключ не найден", 404)
    ok = st.release_activation(rec["key_hash"], hwid)
    st.audit("deactivate", rec["key_id"], hwid, ip, "освобождено" if ok else "не найдено")
    st.refresh_status(rec)
    return web.json_response({"ok": True, "released": ok,
                              "message": "устройство освобождено, лицензию можно активировать "
                                         "на другом компьютере" if ok else
                                         "это устройство и так не было активировано"})


# ============================================================ админка
def _admin_token(app) -> str:
    tok = os.environ.get("FLUX_ADMIN_TOKEN") or app.get("admin_token") or ""
    if tok:
        return tok
    p = os.path.join(keys.KEYS_DIR, "admin_token.txt")
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return f.read().strip()
        except OSError:
            return ""
    return ""


def _require_admin(request: web.Request) -> Optional[web.Response]:
    tok = _admin_token(request.app)
    if not tok:
        return _err("no_admin_token",
                    "токен админки не задан. Установи FLUX_ADMIN_TOKEN или создай "
                    "license_server/keys/admin_token.txt", 503)
    hdr = request.headers.get("Authorization", "")
    got = hdr[7:].strip() if hdr.lower().startswith("bearer ") else request.query.get("token", "")
    if not got or not crypto.constant_time_eq(got, tok):
        return _err("forbidden", "нет доступа", 403)
    return None


async def admin_page(request: web.Request) -> web.Response:
    if not os.path.exists(ADMIN_HTML):
        return web.Response(text="admin.html не найден", status=404)
    return web.FileResponse(ADMIN_HTML)


async def admin_stats(request: web.Request) -> web.Response:
    if (d := _require_admin(request)):
        return d
    st: LicenseStore = request.app["store"]
    stats = st.stats()
    clients = st.active_clients()
    return web.json_response({
        "ok": True, "stats": stats,
        "key_fingerprint": keys.fingerprint(),
        "heartbeat_hours": request.app["heartbeat_hours"],
        "active_clients": clients,
        "poll": {
            "next_check_in_seconds": next_check_in_seconds(clients, "ADMIN-PREVIEW"),
            "min_hours": 5, "max_hours": 72, "ticket_ttl_hours": TICKET_TTL_H,
            "forecast": [estimate_load(n) for n in (50, 100, 500, 1000, 1500, 3000)],
        },
    })


async def admin_licenses(request: web.Request) -> web.Response:
    if (d := _require_admin(request)):
        return d
    st: LicenseStore = request.app["store"]
    rows = st.list_all(status=request.query.get("status", ""),
                       limit=int(request.query.get("limit", 300)))
    for r in rows:
        r.pop("key_hash", None)                        # хеш наружу не отдаём
        for a in r.get("activations") or []:
            a.pop("key_hash", None)
    return web.json_response({"ok": True, "licenses": rows})


async def admin_issue(request: web.Request) -> web.Response:
    if (d := _require_admin(request)):
        return d
    st: LicenseStore = request.app["store"]
    try:
        data = await request.json()
    except Exception:
        return _err("bad_request", "нужен JSON")
    n = max(1, min(500, int(data.get("n") or 1)))
    days = int(data.get("days") or 0)
    expires = 0 if days <= 0 else int(time.time()) + days * 86400
    out = []
    for _ in range(n):
        rec = st.issue(plan=str(data.get("plan") or "standard"),
                       customer=str(data.get("customer") or ""),
                       note=str(data.get("note") or ""),
                       expires_at=expires,
                       max_activations=max(1, int(data.get("devices") or 1)),
                       offline_days=max(1, int(data.get("offline") or 14)))
        out.append({"key": rec["key"], "key_id": rec["key_id"], "plan": rec["plan"],
                    "expires_at": rec["expires_at"]})
    return web.json_response({"ok": True, "issued": out,
                              "note": "ключ показывается один раз — в базе только его хеш"})


async def admin_action(request: web.Request) -> web.Response:
    if (d := _require_admin(request)):
        return d
    st: LicenseStore = request.app["store"]
    act = request.match_info["action"]
    try:
        data = await request.json()
    except Exception:
        data = {}
    kid = str(data.get("key_id") or "")
    if not kid:
        return _err("bad_request", "нужен key_id")
    if act == "revoke":
        # kind по умолчанию — suspended: «просто отозвать» должно быть обратимым.
        # Неожиданно удалить ключ навсегда из-за неверного дефолта — хуже, чем
        # попросить админа выбрать действие явно.
        kind = crypto.normalize_kind(str(data.get("kind") or RK_SUSPENDED))
        reason = str(data.get("reason") or "")
        rec = (st.delete_key(kid, reason) if kind == RK_DELETED
               else st.revoke(kid, reason, kind))
    elif act == "delete":
        # кнопка «Удалить ключ»: блокировка навсегда + освобождение всех устройств
        rec = st.delete_key(kid, str(data.get("reason") or ""))
    elif act == "suspend":
        # кнопка «Отозвать на неопределённое время»
        rec = st.suspend(kid, str(data.get("reason") or ""))
    elif act == "unrevoke":
        rec = st.unrevoke(kid)
    elif act == "extend":
        rec = st.extend(kid, int(data.get("days") or 0))
    elif act == "release":
        r0 = st.get_by_id(kid)
        if not r0:
            return _err("not_found", f"лицензия {kid} не найдена", 404)
        hw = str(data.get("hwid") or "").strip().lower()
        n = st.release_activation(r0["key_hash"], hw) if hw else st.release_all(r0["key_hash"])
        st.audit("release", kid, hw, _ip(request), f"освобождено: {n}")
        rec = st.get_by_id(kid)
    elif act == "plan":
        rec = st.set_plan(kid, str(data.get("plan") or "standard"))
    else:
        return _err("unknown_action", f"неизвестное действие: {act}", 404)
    if rec is None:
        return _err("not_found", f"лицензия {kid} не найдена", 404)
    kh = rec["key_hash"]
    rec = st.refresh_status(rec)
    out = {k: v for k, v in rec.items() if k != "key_hash"}
    out["activations"] = st.activations(kh, active_only=False)
    return web.json_response({"ok": True, "license": out})


async def admin_audit(request: web.Request) -> web.Response:
    if (d := _require_admin(request)):
        return d
    st: LicenseStore = request.app["store"]
    return web.json_response({"ok": True,
                              "records": st.audit_log(int(request.query.get("limit", 100)),
                                                      request.query.get("key_id", ""))})


# ============================================================ сборка
def build_app(db_path: str = DEFAULT_DB, admin_token: str = "",
              heartbeat_hours: int = 72) -> web.Application:
    if not keys.exists():
        raise RuntimeError("нет ключей вендора. Выполни: python -m license_server.keygen init")
    app = web.Application(client_max_size=2 * 1024 * 1024)
    app["store"] = LicenseStore(db_path)
    app["priv"] = keys.load_private_key()
    app["pub"] = keys.load_public_key()
    app["admin_token"] = admin_token
    app["heartbeat_hours"] = int(heartbeat_hours)

    app.router.add_get("/health", api_health)
    app.router.add_post("/v1/activate", api_activate)
    app.router.add_post("/v1/heartbeat", api_heartbeat)
    app.router.add_post("/v1/ping", api_ping)
    app.router.add_post("/v1/keystatus", api_keystatus)
    app.router.add_post("/v1/deactivate", api_deactivate)
    app.router.add_get("/admin", admin_page)
    app.router.add_get("/admin/api/stats", admin_stats)
    app.router.add_get("/admin/api/licenses", admin_licenses)
    app.router.add_post("/admin/api/issue", admin_issue)
    app.router.add_post("/admin/api/{action}", admin_action)
    app.router.add_get("/admin/api/audit", admin_audit)
    return app


def ensure_admin_token() -> str:
    """Если токен админки не задан — создаём случайный и печатаем один раз."""
    tok = os.environ.get("FLUX_ADMIN_TOKEN", "")
    if tok:
        return tok
    p = os.path.join(keys.KEYS_DIR, "admin_token.txt")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            t = f.read().strip()
        if t:
            return t
    crypto.secure_dir(keys.KEYS_DIR)
    tok = secrets.token_urlsafe(24)
    with open(p, "w", encoding="utf-8") as f:
        f.write(tok + "\n")
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    print(f"[license] создан токен админки: {tok}")
    print(f"[license] сохранён в {p} (права 0600). Держи его в секрете.")
    return tok


def run(host: str = "127.0.0.1", port: int = 8790, db_path: str = DEFAULT_DB,
        admin_token: str = "") -> int:
    tok = admin_token or ensure_admin_token()
    app = build_app(db_path, tok)
    print(f"[license] сервер лицензий FLUX на http://{host}:{port}")
    print(f"[license] база: {db_path}")
    print(f"[license] админка: http://{host}:{port}/admin  (токен: {tok[:6]}…)")
    print(f"[license] публичный ключ вендора: {keys.fingerprint()}")
    try:
        web.run_app(app, host=host, port=port, print=None)
    except KeyboardInterrupt:
        pass
    finally:
        app["store"].close()
    return 0
