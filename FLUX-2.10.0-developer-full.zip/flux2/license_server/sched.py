"""Дозирование нагрузки: когда клиенту прийти снова и сколько живёт билет.

ОДИН И ТОТ ЖЕ РАСЧЁТ на Python-сервере и на Cloudflare Worker
--------------------------------------------------------------
Здесь — эталон для license_server/server.py. Worker повторяет его в
deploy/worker/src/sched.mjs, потому что запускать Python внутри Workers нельзя.
Совпадение двух реализаций проверяется тестом deploy/worker/test/crypto_parity.test.mjs
(раздел [5]) и tests/test_ping_countdown.py.

ЗАДАЧА (слова заказчика): «рандомно от 5 часов до 72 часа, зависит от того,
сколько флюксов сейчас включено и работает, чтобы лишний раз не напрягать систему».

РЕШЕНИЕ
  1. Сервер считает, сколько клиентов активно (отметились за последние 6 часов).
  2. По этому числу выбирает ЦЕЛЕВОЙ интервал ступенями: чем больше клиентов, тем
     реже стучится каждый. Суммарная нагрузка растёт ступенчато, а не линейно.
  3. Конкретному клиенту интервал выдаётся с ДЖИТТЕРОМ ±25%. Без него все 1500
     клиентов, активированные одной рассылкой, пришли бы одновременно
     (thundering herd) и создали пик квоты.
  4. Интервал возвращается клиенту, а окно билета — ВНУТРЬ подписи
     (payload.next_check), поэтому клиент не может назначить себе более редкую
     проверку или продлить окно: подпись вендора он не воспроизведёт.

ПОЧЕМУ ОКНО БИЛЕТА = 5 СУТОК
  Оно ОБЯЗАНО превышать максимальный интервал опроса (72 ч). Иначе честный
  клиент заблокировался бы просто потому, что сервер велел ему «спать» трое
  суток, а окно было ровно трое суток.

      72 ч макс. интервал + 48 ч запас = 120 ч = 5 суток

  Запас покрывает недоступность сервера, выключенный ПК покупателя на выходных и
  обрыв сети. Пока окно не истекло, FLUX работает полностью офлайн — то есть
  покупатель не зависит ни от ПК разработчика, ни от доступности Cloudflare.
"""
from __future__ import annotations

import math
from typing import Optional

MIN_INTERVAL_H = 5
MAX_INTERVAL_H = 72
TICKET_TTL_H = MAX_INTERVAL_H + 48          # 120 ч = 5 суток

# Ступени подобраны так, чтобы суммарная нагрузка оставалась в free tier D1
# (5 млн чтений / 100 тыс записей в день) с запасом минимум в 10 раз.
_TIERS = (
    (50, 6),            # мало клиентов — отзыв быстрый
    (200, 12),
    (500, 24),
    (1000, 48),
    (None, MAX_INTERVAL_H),
)

# Размер обмена пинга В БАЙТАХ ТЕЛА: запрос ~25 Б (только key_id) + ответ ~240 Б.
# HTTP-заголовки сюда не входят: они одинаковы у любого ответа и в квоту D1 не
# попадают. Значение подтверждено замером в deploy/worker/test/api.test.mjs
# (раздел [5]: «пинг: запрос 25 Б», «пинг: ответ 242 Б») — для сравнения, старый
# heartbeat передавал один только билет на 626 Б.
PING_BYTES = 270


def target_interval_hours(clients: int) -> int:
    """Целевой интервал опроса в часах по числу активных клиентов."""
    n = max(0, int(clients or 0))
    for limit, hours in _TIERS:
        if limit is None or n <= limit:
            return hours
    return MAX_INTERVAL_H


def jitter_hours(seed: str, spread: float) -> float:
    """Детерминированный псевдорандом (FNV-1a) по key_id клиента.

    НАМЕРЕННО не random(): интервал должен быть СТАБИЛЬНЫМ для одного клиента
    между запросами. Иначе на каждой отметке клиент получал бы новое случайное
    число и в среднем опрашивал чаще, чем предусмотрено. При этом у разных
    клиентов джиттер разный — стадо рассеивается.
    """
    s = str(seed or "flux")
    h = 2166136261
    for ch in s:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    unit = (h % 100000) / 100000            # в [0, 1)
    return (unit - 0.5) * 2 * spread         # +/- spread часов


def next_check_in_seconds(clients: int, key_id: str) -> int:
    """Сколько секунд клиенту ждать до следующей отметки."""
    target = target_interval_hours(clients)
    hours = target + jitter_hours(key_id, target * 0.25)
    hours = min(MAX_INTERVAL_H, max(MIN_INTERVAL_H, hours))
    return int(round(hours * 3600))


def humanize_left(seconds: Optional[float]) -> str:
    """«5 дн 3 ч» / «15 ч» / «10 мин» / «0 ч» — отсчёт, который видит пользователь.

    Совпадает с sched.mjs::humanizeLeft и с app/licensing.py::humanize_left,
    чтобы сервер и клиент показывали одно и то же.
    """
    s = max(0, int(round(seconds or 0)))
    if s <= 0:
        return "0 ч"
    d, rem = divmod(s, 86400)
    h, rem2 = divmod(rem, 3600)
    m = rem2 // 60
    if d:
        return f"{d} дн {h} ч" if h else f"{d} дн"
    if h:
        return f"{h} ч {m} мин" if m else f"{h} ч"
    return f"{m} мин" if m else "меньше минуты"




def _r(x: float, nd: int = 0):
    """Округление ПОЛОВИНЫ ВВЕРХ — как JS Math.round.

    Встроенный round() в Python округляет половину к ЧЁТНОМУ (банковское):
    round(250.5) == 250, тогда как Math.round(250.5) == 251. Формула дозирования
    реализована дважды (здесь и в sched.mjs), и расхождение в одну единицу
    заставляло тест паритета падать. Приводим к одному поведению.

    При nd == 0 возвращает int (как Math.round), иначе float с nd знаками —
    иначе `0.77` превращалось бы в `1` и прогноз в админке врал.
    """
    scaled = math.floor(x * (10 ** nd) + 0.5) / (10 ** nd)
    return int(scaled) if nd == 0 else scaled


def estimate_load(clients: int) -> dict:
    """Прогноз нагрузки: сколько опросов, чтений/записей D1 и трафика.

    Показывается в веб-админке (карточка «Нагрузка»), чтобы не гадать, упрёмся ли
    в квоту, а видеть это заранее.
    """
    n = max(0, int(clients or 0))
    interval_h = target_interval_hours(n)
    polls = n * 24 / interval_h if interval_h else 0
    reads = polls * 1.2                       # пинг = 1 чтение + доля refresh_status
    writes = n * 24 * 0.35                    # last_seen не чаще раза в час
    return {
        "clients": n,
        "interval_hours": interval_h,
        "polls_per_day": int(_r(polls)),
        "d1_reads_per_day": int(_r(reads)),
        "d1_writes_per_day": int(_r(writes)),
        "d1_read_pct_of_free": _r(reads / 5_000_000 * 100, 3),
        "d1_write_pct_of_free": _r(writes / 100_000 * 100, 2),
        "bytes_per_poll": PING_BYTES,
        "mb_per_month": _r(polls * PING_BYTES * 30 / 1048576, 2),
    }
