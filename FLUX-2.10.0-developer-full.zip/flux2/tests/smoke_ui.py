"""Дымовой прогон: сервер поднимается, UI содержит клиентскую часть таймеров."""
from __future__ import annotations
import asyncio, os, sys, tempfile, threading, time
os.environ.setdefault("FLUX2_HOME", tempfile.mkdtemp(prefix="smoke-"))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import aiohttp
from aiohttp import web
from app.server import build_app
from app import timers as TM

PORT = 8799
FAIL = []

def srv():
    loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
    r = web.AppRunner(build_app()); loop.run_until_complete(r.setup())
    loop.run_until_complete(web.TCPSite(r, "127.0.0.1", PORT).start()); loop.run_forever()

def ck(name, cond, extra=""):
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if not cond else ""))
    if not cond: FAIL.append(name)

threading.Thread(target=srv, daemon=True).start(); time.sleep(1.2); TM.start()

async def main():
    async with aiohttp.ClientSession() as s:
        r = await s.get(f"http://127.0.0.1:{PORT}/")
        html = await r.text()
        print(f"\n[1] GET / -> {r.status}, {len(html)} байт")
        ck("статус 200", r.status == 200)
        for probe in ["connectEvents()", "EventSource('/api/events')", 'id="toasts"',
                      'id="timerChip"', "Snd.play", "timer_fired", "onTimerFired",
                      "/api/notify/stop"]:
            ck(f"в HTML есть {probe!r}", probe in html)
        print("\n[2] /api/state")
        d = await (await s.get(f"http://127.0.0.1:{PORT}/api/state")).json()
        ck("тулзов > 400", d["tools_count"] > 400, str(d["tools_count"]))
        ck("категория screen", d["tools_categories"].get("screen", 0) >= 12)
        ck("категория timers", d["tools_categories"].get("timers", 0) >= 10)
        print("\n[3] retrieval тулзов")
        for q, want in (("скриншот окна хром", "screen_capture_window"),
                        ("напомни через 5 минут", "timer_set"),
                        ("засеки таймер на 10 минут", "timer_set"),
                        ("сними вкладку браузера", "screen_capture_browser_tab")):
            d = await (await s.get(f"http://127.0.0.1:{PORT}/api/tools",
                                   params={"q": q, "k": 10})).json()
            names = [t["name"] for t in d["tools"]]
            ck(f"«{q}» находит {want}", want in names, str(names[:8]))

asyncio.run(main())
TM.stop()
print(f"\n{'='*60}\nДымовой прогон: {'ВСЁ ОК' if not FAIL else 'ПРОВАЛЕНО: ' + str(FAIL)}")
sys.exit(1 if FAIL else 0)
