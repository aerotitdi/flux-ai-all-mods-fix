"""Тесты дешёвого пинга, обратного отсчёта и дозирования нагрузки на клиенте.

Закрывают три вещи, которые просил заказчик:
  1. покупатель НЕ зависит от ПК разработчика — окно билета 5 суток, всё это
     время FLUX работает офлайн по локальной проверке подписи;
  2. обмен состоянием ключа стоит копейки, а не гигабайты — ping() не передаёт
     билет (626 Б из 856 Б старого обмена);
  3. интервал опроса назначает СЕРВЕР (рандом 5-72 ч по числу активных клиентов),
     и клиент его уважает, а не дёргает сеть каждые 10 минут.

Поднимается НАСТОЯЩИЙ сервер лицензий (Python, license_server/server.py).
Worker на Cloudflare тестируется отдельно: deploy/worker/test/*.mjs.

Запуск:  python tests/test_ping_countdown.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import threading
import time

TMP = tempfile.mkdtemp(prefix="flux2-ping-")
os.environ["FLUX2_HOME"] = os.path.join(TMP, "client")
os.environ["FLUX_LICENSE_DB"] = os.path.join(TMP, "licenses.db")
os.environ["FLUX_RL_ACTIVATE"] = "5000"
os.environ["FLUX_RL_HEARTBEAT"] = "5000"
os.environ["FLUX_RL_KEYSTATUS"] = "5000"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import aiohttp                                        # noqa: E402
from aiohttp import web                               # noqa: E402

from license_server import crypto, keys, server as LS, store as store_mod  # noqa: E402
from app import licensing                             # noqa: E402
from app.config import CONFIG                         # noqa: E402

PORT = 8794
BASE = f"http://127.0.0.1:{PORT}"
ADMIN_TOKEN = "ping-test-token"
PASS, FAIL = [], []


def check(name: str, cond: bool, extra: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if not cond else ""))


DB: store_mod.LicenseStore = None
REQUESTS: list = []          # (path, размер тела запроса) — чтобы мерить трафик


def start_license_server() -> None:
    global DB
    DB = store_mod.LicenseStore(os.environ["FLUX_LICENSE_DB"])
    app = LS.build_app(os.environ["FLUX_LICENSE_DB"], ADMIN_TOKEN)
    app["store"] = DB

    # считаем байты, реально уходящие на сервер: это и есть «сколько интернета
    # тратится на передачу состояния ключа»
    @web.middleware
    async def meter(request, handler):
        body = await request.read()
        resp = await handler(request)
        REQUESTS.append((request.path, len(body),
                         len(resp.body) if isinstance(resp.body, bytes) else 0))
        return resp

    app.middlewares.append(meter)

    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        r = web.AppRunner(app)
        loop.run_until_complete(r.setup())
        loop.run_until_complete(web.TCPSite(r, "127.0.0.1", PORT).start())
        loop.run_forever()

    threading.Thread(target=run, daemon=True).start()
    time.sleep(0.6)


async def measure(fn, *a, **kw):
    """Выполнить и вернуть (результат, список запросов, суммарные байты).

    Корутинная, а не синхронная: scenario() уже работает внутри event loop, и
    попытка завести вложенный loop падает с «Cannot run the event loop while
    another loop is running».
    """
    REQUESTS.clear()
    res = await fn(*a, **kw)
    total = sum(r[1] + r[2] for r in REQUESTS)
    return res, list(REQUESTS), total


async def scenario() -> None:
    CONFIG.settings["license_server_url"] = BASE
    CONFIG.settings["license_required"] = True
    CONFIG.save()

    print("\n[1] Активация: сервер присылает интервал и окно отсчёта")
    rec = DB.issue(plan="pro", customer="buyer@example.com", max_activations=1,
                   offline_days=5)
    key = rec["key"]
    st = await licensing.activate(key)
    check("активация прошла", bool(st.get("ticket")), str(st)[:160])
    check("в состоянии есть ticket_ttl_hours", "ticket_ttl_hours" in st, str(sorted(st)))
    check("next_check_at назначен", int(st.get("next_check_at") or 0) > 0,
          str(st.get("next_check_at")))
    payload = crypto.ticket_payload(st["ticket"])
    ttl_h = (int(payload["offline_until"]) - int(payload["issued"])) / 3600
    check("окно билета = 120 ч (5 суток)", ttl_h == 120.0, str(ttl_h))
    check("окно больше максимального интервала опроса (72 ч)", ttl_h > 72,
          f"{ttl_h} <= 72: честный клиент блокировался бы, пока «спит»")

    print("\n[2] Обратный отсчёт считается локально, без сети")
    cd = licensing.countdown()
    check("countdown() активен", cd["active"] is True, str(cd)[:160])
    check("осталось ~5 суток", 4 * 86400 < cd["seconds_left"] <= 5 * 86400,
          str(cd["seconds_left"]))
    check("человекочитаемый отсчёт", cd["human"] == "5 дн", str(cd["human"]))
    check("в countdown есть until", cd["until"] > 0)
    n_before = len(REQUESTS)
    for _ in range(5):
        licensing.countdown()
    check("countdown() НЕ обращается к сети", len(REQUESTS) == n_before,
          f"{len(REQUESTS) - n_before} запросов")
    check("countdown() есть в status()", isinstance(licensing.status().get("countdown"), dict))

    print("\n[3] Сценарий заказчика: 3 дн -> 1 дн -> 15 ч -> 10 ч -> 0 -> конец")
    until = cd["until"]
    for label, left_s, want in (("3 дня", 3 * 86400, "3 дн"),
                                ("1 день", 86400, "1 дн"),
                                ("15 часов", 15 * 3600, "15 ч"),
                                ("10 часов", 10 * 3600, "10 ч"),
                                ("1 час", 3600, "1 ч")):
        c = licensing.countdown(now=until - left_s)
        check(f"отсчёт «{label}» -> «{want}»", c["human"] == want, c["human"])
        check(f"«{label}»: ещё работает", c["expired"] is False)
    c0 = licensing.countdown(now=until + 1)
    check("на нуле отсчёт = «0 ч»", c0["human"] == "0 ч", c0["human"])
    check("на нуле expired=True", c0["expired"] is True)
    v = licensing.validate(now=until + 1)
    check("на нуле приложение требует подключения", v["ok"] is False, str(v.get("reason")))
    check("на нуле причина про офлайн-проверку",
          "офлайн" in v.get("reason", "").lower() or "подключиться" in v.get("reason", "").lower(),
          str(v.get("reason")))
    v2 = licensing.validate(now=until - 3600)
    check("за час до нуля всё ещё работает ОФЛАЙН", v2["ok"] is True, str(v2.get("reason")))

    print("\n[4] humanize_left совпадает с сервером")
    for sec, want in ((5 * 86400, "5 дн"), (3 * 86400 + 5 * 3600, "3 дн 5 ч"),
                      (86400, "1 дн"), (15 * 3600, "15 ч"), (10 * 3600, "10 ч"),
                      (3600, "1 ч"), (600, "10 мин"), (0, "0 ч")):
        got = licensing.humanize_left(sec)
        check(f"humanize_left({sec}) = «{want}»", got == want, got)

    print("\n[5] ping() дёргает сеть только когда наступил срок")
    st = licensing._load_state()
    st["next_check_at"] = int(time.time()) + 3600     # сервер велел прийти через час
    licensing._save_state(st)
    res, reqs, total = await measure(licensing.ping)
    check("до срока ping НЕ идёт на сервер", reqs == [], str(reqs))
    check("ping вернул skipped=True", res.get("skipped") is True, str(res))
    check("ping вернул, сколько ждать", res.get("in_seconds", 0) > 3000, str(res))

    st = licensing._load_state()
    st["next_check_at"] = int(time.time()) - 10       # срок наступил
    licensing._save_state(st)
    res, reqs, total = await measure(licensing.ping)
    check("по сроку ping идёт на сервер", len(reqs) == 1, str(reqs))
    check("ping дёрнул именно /v1/ping", reqs and reqs[0][0] == "/v1/ping", str(reqs))

    print("\n[6] Трафик: ping против heartbeat")
    st = licensing._load_state()
    st["next_check_at"] = 0
    licensing._save_state(st)
    _, ping_reqs, ping_bytes = await measure(licensing.ping)
    st = licensing._load_state()
    st["last_check"] = 0
    licensing._save_state(st)
    _, hb_reqs, hb_bytes = await measure(licensing.heartbeat, force=True)
    print(f"      ping:      {len(ping_reqs)} запрос(ов), {ping_bytes} Б")
    print(f"      heartbeat: {len(hb_reqs)} запрос(ов), {hb_bytes} Б")
    check("ping дешевле heartbeat", ping_bytes < hb_bytes, f"{ping_bytes} vs {hb_bytes}")
    check("ping не передаёт билет",
          ping_reqs and ping_reqs[0][1] < 200, str(ping_reqs))
    check("heartbeat передаёт билет (>500 Б)",
          hb_reqs and hb_reqs[0][1] > 500, str(hb_reqs))
    # прогноз на 1500 клиентов
    for n in (1500,):
        per_day_old = n * 24 / 72          # старый heartbeat раз в 72 ч
        old_mb = per_day_old * hb_bytes * 30 / 1048576
        per_day_new = n * 24 / 72
        new_mb = per_day_new * ping_bytes * 30 / 1048576
        print(f"      {n} клиентов, опрос раз в 72 ч: heartbeat {old_mb:.1f} МБ/мес"
              f" -> ping {new_mb:.1f} МБ/мес")
        check("экономия на 1500 клиентах ощутимая", new_mb < old_mb, f"{new_mb} vs {old_mb}")

    print("\n[7] ping сообщает об удалении ключа и запоминает причину")
    DB.delete_key(rec["key_id"], "возврат средств")
    st = licensing._load_state()
    st["next_check_at"] = 0
    licensing._save_state(st)
    try:
        await licensing.ping(force=True)
        check("ping выбросил исключение", False, "исключения не было")
    except licensing.LicenseError as e:
        check("код ошибки revoked", e.code == "revoked", e.code)
        check("в сообщении про УДАЛЁН", "УДАЛЁН" in str(e), str(e))
        check("в extra есть revoke", (e.extra.get("revoke") or {}).get("kind") == "deleted",
              str(e.extra.get("revoke")))
    stt = licensing.status()
    check("headline — «Этот ключ доступа был удалён»",
          stt.get("headline") == "Этот ключ доступа был удалён", str(stt.get("headline")))
    check("причина сохранена", stt.get("headline_reason") == "возврат средств",
          str(stt.get("headline_reason")))
    cd2 = licensing.countdown()
    check("после блокировки отсчёт неактивен", cd2["active"] is False, str(cd2)[:120])

    print("\n[8] ping без активации не падает")
    try:
        os.remove(licensing.state_path())
    except OSError:
        pass
    res = await licensing.ping()
    check("ping без билета вернул not_activated", res.get("reason") == "not_activated", str(res))

    print("\n[9] Клиент совместим со старым сервером (без /v1/ping)")
    # старый сервер лицензий не знает /v1/ping и ответит 404/405. Клиент обязан
    # выжить и продолжить работать по heartbeat — иначе обновление сервера
    # сломало бы всех, кто ещё на старой сборке клиента.
    rec2 = DB.issue(plan="standard", max_activations=1, offline_days=5)
    await licensing.activate(rec2["key"])
    st = licensing._load_state()
    st["next_check_at"] = 0
    licensing._save_state(st)

    async def fake_old():
        # эмулируем ответ старого сервера на неизвестный маршрут
        return await licensing._post("/v1/ping", {"key_id": st.get("license_id")})

    res = await fake_old()
    if res.get("error"):
        check("на неизвестный маршрут клиент не падает", True)
    else:
        check("сервер знает /v1/ping (новый протокол)", res.get("ok") is True, str(res)[:160])
    check("после пинга лицензия всё ещё активна", licensing.validate()["ok"] is True,
          str(licensing.validate().get("reason")))


def main() -> int:
    print(f"FLUX 2.0 — пинг, отсчёт и дозирование нагрузки   ({TMP})")
    if not keys.exists():
        keys.init()
    start_license_server()
    t0 = time.time()
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(scenario())
    finally:
        loop.close()
        try:
            DB.close()
        except Exception:
            pass
    print(f"\n{'=' * 64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time() - t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
