"""Точный пересчёт числа проверок по всем тест-файлам.

Сводка в CHANGES-round2.md обязана содержать фактические числа, а не округлённые
на глаз: раньше там стояло «1225 проверок», тогда как реальный прогон даёт другое
число. Скрипт просто гоняет все тесты и суммирует «N OK, M FAIL».
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

PY_TESTS = [
    "tests/test_licensing.py", "tests/test_licensing_client.py",
    "tests/test_key_removal.py", "tests/test_ping_countdown.py",
    "tests/test_build_release.py", "tests/test_make_dist.py",
    "tests/e2e_key_flow.py", "tests/test_events_sse.py",
    "tests/test_timers_screen.py", "tests/test_guardian_browser.py",
]
JS_TESTS_DEPLOY = [
    "worker/test/api.test.mjs", "worker/test/crypto_parity.test.mjs",
    "worker/test/sched_parity.test.mjs", "worker/test/sqlsplit.test.mjs",
]
JS_TESTS_UI = [
    "tests/jsdom/admin_actions.test.cjs", "tests/jsdom/license_gate.test.cjs",
    "tests/jsdom/page_snapshot.test.cjs",
]
# без счётчика «N OK», но падение всё равно должно быть видно
BOOL_TESTS = [("tests/smoke_ui.py", "python3", "ВСЁ ОК"),
              ("tests/e2e_mock.py", "python3", "E2E OK"),
              ("tests/check_js.py", "python3", "Ошибок: 0")]


def run(cmd, cwd, timeout=600):
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd, timeout=timeout)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def main() -> int:
    rows = []
    total_ok = total_fail = 0
    for rel in PY_TESTS:
        rc, out = run([sys.executable, rel], ROOT)
        m = re.search(r"(\d+) OK, (\d+) FAIL", out)
        ok, fail = (int(m.group(1)), int(m.group(2))) if m else (0, 1)
        rows.append((rel, ok, fail, rc))
        total_ok += ok
        total_fail += fail
    for rel in JS_TESTS_DEPLOY:
        rc, out = run(["node", rel], os.path.join(ROOT, "deploy"))
        m = re.search(r"(\d+) OK, (\d+) FAIL", out)
        ok, fail = (int(m.group(1)), int(m.group(2))) if m else (0, 1)
        rows.append(("deploy/" + rel, ok, fail, rc))
        total_ok += ok
        total_fail += fail
    for rel in JS_TESTS_UI:
        rc, out = run(["node", rel], ROOT)
        m = re.search(r"(\d+) OK, (\d+) FAIL", out)
        ok, fail = (int(m.group(1)), int(m.group(2))) if m else (0, 1)
        rows.append((rel, ok, fail, rc))
        total_ok += ok
        total_fail += fail
    for rel, exe, marker in BOOL_TESTS:
        rc, out = run([sys.executable if exe == "python3" else exe, rel], ROOT)
        good = (rc == 0 and marker in out)
        rows.append((rel, 0, 0 if good else 1, 0 if good else 1))
        total_fail += 0 if good else 1

    for name, ok, fail, rc in rows:
        flag = "" if (fail == 0 and rc == 0) else "   <-- ПРОВАЛ"
        print(f"  {name:<46} {ok:>4} OK  {fail} FAIL{flag}")
    print()
    print(f"  ВСЕГО: {total_ok} проверок со счётчиком, {total_fail} провалов, "
          f"файлов: {len(rows)}")
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main())
