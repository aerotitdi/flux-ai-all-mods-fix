"""Тесты упаковки архива packaging/make_dist.py.

Закрывают два реальных дефекта, найденных при сборке:

  1. MANIFEST.txt в репозитории — артефакт прошлой сборки. Он попадал в список
     файлов, а затем рядом записывался свежий через writestr(). В zip оказывалось
     ДВА элемента с одним именем: zipfile ругался «Duplicate name», а распаковщик
     брал непредсказуемый из двух (то есть покупатель мог получить устаревший
     манифест).

  2. УСТАНОВКА.txt перезаписывался встроенным шаблоном README_DIST и УДАЛЯЛСЯ
     после упаковки. То есть запуск сборщика портил исходник в репозитории:
     ручные правки инструкции терялись безвозвратно (нет git — не восстановить).

Запуск:  python tests/test_make_dist.py
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

_spec = importlib.util.spec_from_file_location(
    "make_dist", os.path.join(ROOT, "packaging", "make_dist.py"))
MD = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(MD)

PASS, FAIL = [], []


def check(name: str, cond: bool, extra: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if not cond else ""))


def sha(path: str) -> str:
    import hashlib
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def test_manifest_not_duplicated() -> None:
    print("\n[1] MANIFEST.txt не дублируется в архиве")
    outdir = tempfile.mkdtemp(prefix="mkdist-")
    # в репозитории лежит УСТАРЕВШИЙ манифест — именно он и провоцировал дубль
    stale = os.path.join(ROOT, "MANIFEST.txt")
    had_stale = os.path.exists(stale)
    backup = stale + ".testbak"
    if had_stale:
        shutil.copy2(stale, backup)
    try:
        with open(stale, "w", encoding="utf-8") as f:
            f.write("ЭТО УСТАРЕВШИЙ МАНИФЕСТ ИЗ ПРОШЛОЙ СБОРКИ\nфайлов: 1\n")
        r = subprocess.run([sys.executable, os.path.join(ROOT, "packaging", "make_dist.py"),
                            "--outdir", outdir, "--name", "probe.zip", "--i-am-developer"],
                           cwd=ROOT, capture_output=True, text=True)
        check("make_dist.py завершился успешно", r.returncode == 0,
              (r.stdout or "")[-400:] + (r.stderr or "")[-400:])
        check("нет предупреждения Duplicate name", "Duplicate name" not in r.stderr,
              r.stderr[-300:])
        zp = os.path.join(outdir, "probe.zip")
        check("архив создан", os.path.exists(zp))
        with zipfile.ZipFile(zp) as z:
            names = z.namelist()
            dups = sorted({n for n in names if names.count(n) > 1})
            check("в архиве НЕТ дублирующихся имён", dups == [], str(dups))
            mans = [n for n in names if n.endswith("MANIFEST.txt")]
            check("ровно один MANIFEST.txt", len(mans) == 1, str(mans))
            body = z.read(mans[0]).decode("utf-8")
            check("манифест — СВЕЖИЙ, а не устаревший",
                  "УСТАРЕВШИЙ" not in body, body[:200])
            check("в манифесте есть число файлов", "файлов:" in body, body[:200])
            check("в манифесте есть итоговый объём", "ВСЕГО" in body, body[-200:])
            bad = [n for n in names if n.endswith((".pyc", ".pem", ".pfx", ".p12", ".key"))]
            check("в архиве нет .pyc и сертификатов", bad == [], str(bad))
            check("в архиве нет license_server/keys/",
                  not [n for n in names if "/keys/" in n], str(names[:5]))
    finally:
        if had_stale:
            shutil.move(backup, stale)
        shutil.rmtree(outdir, ignore_errors=True)


def test_install_txt_preserved() -> None:
    print("\n[2] УСТАНОВКА.txt не перезаписывается и не удаляется")
    readme = os.path.join(ROOT, "УСТАНОВКА.txt")
    if not os.path.exists(readme):
        check("УСТАНОВКА.txt существует в репозитории", False, "файла нет — тест невозможен")
        return
    before = sha(readme)
    marker = "ВАЖНО: есть два разных архива"
    check("исходник содержит ручную разметку (маркер)", marker in
          open(readme, encoding="utf-8").read(), "маркер не найден")

    outdir = tempfile.mkdtemp(prefix="mkdist-")
    try:
        r = subprocess.run([sys.executable, os.path.join(ROOT, "packaging", "make_dist.py"),
                            "--outdir", outdir, "--name", "probe2.zip", "--i-am-developer"],
                           cwd=ROOT, capture_output=True, text=True)
        check("сборка прошла", r.returncode == 0, (r.stderr or "")[-300:])
        check("файл НЕ удалён после сборки", os.path.exists(readme),
              "make_dist.py снова удаляет УСТАНОВКА.txt")
        check("содержимое НЕ изменилось", sha(readme) == before,
              "make_dist.py перезаписал УСТАНОВКА.txt шаблоном README_DIST")
        check("ручная разметка на месте",
              marker in open(readme, encoding="utf-8").read())

        with zipfile.ZipFile(os.path.join(outdir, "probe2.zip")) as z:
            names = z.namelist()
            inst = [n for n in names if n.endswith("УСТАНОВКА.txt")]
            check("УСТАНОВКА.txt в архиве есть", len(inst) == 1, str(inst))
            body = z.read(inst[0]).decode("utf-8")
            check("в архиве — РУЧНАЯ версия, а не шаблон", marker in body, body[:200])
            check("в архиве описан сценарий готовой сборки",
                  "ГОТОВАЯ СБОРКА" in body, body[:300])
            check("в архиве упомянут build_release.py", "build_release.py" in body)
    finally:
        shutil.rmtree(outdir, ignore_errors=True)


def test_fallback_readme() -> None:
    print("\n[3] Запасной шаблон работает, если УСТАНОВКА.txt пропал")
    readme = os.path.join(ROOT, "УСТАНОВКА.txt")
    backup = tempfile.mktemp(suffix=".bak", dir=TMP)
    shutil.copy2(readme, backup)
    outdir = tempfile.mkdtemp(prefix="mkdist-", dir=TMP)
    try:
        os.remove(readme)
        r = subprocess.run([sys.executable, os.path.join(ROOT, "packaging", "make_dist.py"),
                            "--outdir", outdir, "--name", "probe3.zip", "--i-am-developer"],
                           cwd=ROOT, capture_output=True, text=True)
        check("сборка без УСТАНОВКА.txt проходит", r.returncode == 0, (r.stderr or "")[-300:])
        with zipfile.ZipFile(os.path.join(outdir, "probe3.zip")) as z:
            inst = [n for n in z.namelist() if n.endswith("УСТАНОВКА.txt")]
            check("запасной README создан в архиве", len(inst) == 1, str(inst))
            body = z.read(inst[0]).decode("utf-8")
            check("запасной README — шаблонный", "Установка.bat" in body or "инсталлер" in body.lower(),
                  body[:200])
        check("временный README удалён из репозитория", not os.path.exists(readme),
              "в репозитории остался сгенерированный файл")
    finally:
        shutil.move(backup, readme)
        shutil.rmtree(outdir, ignore_errors=True)
    check("УСТАНОВКА.txt восстановлен", os.path.exists(readme))


def test_filters() -> None:
    print("\n[4] Фильтры упаковки")
    for p, why in (("build_nuitka/main.dist/Flux.exe", "артефакт Nuitka"),
                   ("build_pyi/dist/Flux/Flux.exe", "артефакт PyInstaller"),
                   ("release/FLUX-2.10.0.zip", "готовый релиз"),
                   ("main.build/x.exe", "промежуточная сборка Nuitka"),
                   ("license_server/keys/vendor_private.pem", "приватный ключ вендора"),
                   ("license_server/data/licenses.db", "база лицензий"),
                   ("app/_build_profile.py.source-backup", "бэкап профиля сборки"),
                   ("data/license.json", "состояние лицензии"),
                   ("config.json", "конфиг пользователя"),
                   ("app/__pycache__/x.pyc", "байткод")):
        check(f"исключено: {why}", MD.is_excluded(p, dev=False), p)
    # секреты Cloudflare Workers: .dev.vars содержит VENDOR_PRIVATE_KEY_PEM,
    # а .wrangler/state — локальную копию базы D1 с хешами ключей и HWID.
    # Упаковать их в архив = отдать приватный ключ вендора.
    for p in ("deploy/.dev.vars", "deploy/.dev.vars.production", "deploy/.env",
              "deploy/.wrangler/state/v3/d1/miniflare-D1SessionObject/x.sqlite",
              "license_server/data/licenses.db", "license_server/keys/vendor_private.pem"):
        check(f"секрет исключён: {p}", MD.is_excluded(p, dev=False), p)
        check(f"секрет исключён и в dev-режиме: {p}", MD.is_excluded(p, dev=True), p)
    # сам deploy/ при этом упаковывать НУЖНО: там инструкция по деплою и код воркера
    for p in ("deploy/README.md", "deploy/schema.sql", "deploy/wrangler.toml",
              "deploy/migrate_to_d1.py", "deploy/worker/src/index.mjs"):
        check(f"файл деплоя включён: {p}", not MD.is_excluded(p, dev=False), p)

    for p in ("app/licensing.py", "app/_build_profile.py", "ui/index.html",
              "main.py", "packaging/build_release.py", "УСТАНОВКА.txt",
              "skills_bundled/fact-check.md", "requirements.txt"):
        check(f"включено: {p}", not MD.is_excluded(p, dev=False), p)
    # .gitignore — метаданные git, в клиентской поставке бесполезен. Но в
    # dev-архиве он ОБЯЗАН быть: без него легко закоммитить deploy/.dev.vars,
    # внутри которого VENDOR_PRIVATE_KEY_PEM.
    check(".gitignore исключён из пользовательского архива",
          MD.is_excluded(".gitignore", dev=False))
    dev_files = MD.collect(True, True)
    usr_files = MD.collect(False, False)
    check(".gitignore включён в dev-архив", ".gitignore" in dev_files)
    check(".gitignore НЕ включён в user-архив", ".gitignore" not in usr_files)
    check("deploy/README.md в dev-архиве", "deploy/README.md" in dev_files)
    check("секретов в dev-архиве нет",
          not [f for f in dev_files if f.endswith((".pem", ".db", ".pfx")) or "/keys/" in f],
          str([f for f in dev_files if f.endswith((".pem", ".db"))]))
    check("deploy/.dev.vars в dev-архив не попал",
          "deploy/.dev.vars" not in dev_files)
    check("node_modules в dev-архив не попал",
          not [f for f in dev_files if "node_modules" in f])
    check("tests/ исключены из пользовательского архива", MD.is_excluded("tests/x.py", dev=False))
    check("tests/ включены при dev=True", not MD.is_excluded("tests/x.py", dev=True))
    check("docs/ исключены из пользовательского архива", MD.is_excluded("docs/p.md", dev=False))


def test_source_guard() -> None:
    """make_dist.py собирает архив с ИСХОДНИКАМИ.

    Отдать его покупателю — значит отдать app/licensing.py, а с ним возможность
    вырезать проверку ключа. Поэтому скрипт обязан ОТКАЗАТЬСЯ работать без
    явного подтверждения намерения.
    """
    print("\n[5] Защита от случайной публикации исходников")
    outdir = tempfile.mkdtemp(prefix="mkdist-", dir=TMP)
    env = {k: v for k, v in os.environ.items()
           if k != "FLUX_I_UNDERSTAND_SOURCE_ARCHIVE"}
    try:
        r = subprocess.run([sys.executable, os.path.join(ROOT, "packaging", "make_dist.py"),
                            "--outdir", outdir, "--name", "leak.zip"],
                           cwd=ROOT, capture_output=True, text=True, env=env)
        out = (r.stdout or "") + (r.stderr or "")
        check("без подтверждения — ненулевой код возврата", r.returncode != 0,
              f"rc={r.returncode}")
        check("архив НЕ создан", not os.path.exists(os.path.join(outdir, "leak.zip")),
              "скрипт всё-таки собрал архив с исходниками")
        check("объяснено, почему нельзя", "ИСХОДН" in out, out[:200])
        check("указан правильный путь для покупателя", "build_release.py" in out, out[:300])
        check("сказано про вырезание проверки ключа", "вырезать" in out or "проверку ключа" in out,
              out[:400])
        check("показан способ подтвердить намерение", "--i-am-developer" in out, out[:400])

        # переменная окружения — второй способ подтверждения
        env2 = dict(env, FLUX_I_UNDERSTAND_SOURCE_ARCHIVE="1")
        r2 = subprocess.run([sys.executable, os.path.join(ROOT, "packaging", "make_dist.py"),
                             "--outdir", outdir, "--name", "env.zip"],
                            cwd=ROOT, capture_output=True, text=True, env=env2)
        check("с FLUX_I_UNDERSTAND_SOURCE_ARCHIVE=1 сборка идёт",
              r2.returncode == 0 and os.path.exists(os.path.join(outdir, "env.zip")),
              f"rc={r2.returncode}")

        # и главный смысл гарда: в архиве разработчика ДЕЙСТВИТЕЛЬНО есть исходники,
        # то есть отдавать его покупателю правда нельзя
        import zipfile
        with zipfile.ZipFile(os.path.join(outdir, "env.zip")) as z:
            names = z.namelist()
        check("в архиве есть app/licensing.py (вот почему он опасен)",
              any(n.endswith("app/licensing.py") for n in names), str(names[:5]))
        check("в архиве есть main.py", any(n.endswith("main.py") for n in names))
        py = [n for n in names if n.endswith(".py")]
        check("в архиве десятки .py файлов", len(py) > 30, str(len(py)))
    finally:
        shutil.rmtree(outdir, ignore_errors=True)


TMP = tempfile.mkdtemp(prefix="flux2-mkdist-")


def main() -> int:
    print(f"FLUX 2.0 — тесты упаковки архива   ({TMP})")
    test_source_guard()
    test_filters()
    test_manifest_not_duplicated()
    test_install_txt_preserved()
    test_fallback_readme()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f"\n{'=' * 64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
