/* Проверка окна активации лицензии на настоящем DOM (jsdom).

   Зачем: тексты блокировки («Этот ключ доступа был удалён. Причина: …») — это то,
   что увидит покупатель вместо работы приложения. Проверять их глазами каждый раз
   ненадёжно, поэтому гоняем render() на готовых состояниях и сверяем заголовки.

   Запуск:  node tests/jsdom/license_gate.test.cjs
   Нужен jsdom:  npm install jsdom  (в каталоге tests/jsdom)
*/
'use strict';
const fs = require('fs');
const path = require('path');
// jsdom ищется сначала в локальном node_modules (cd tests/jsdom && npm install),
// затем обычным require — чтобы тест можно было запустить из распакованного
// архива, где node_modules не поставляется.
let JSDOM;
try {
  ({ JSDOM } = require(path.join(__dirname, 'node_modules', 'jsdom')));
} catch (e) {
  try {
    ({ JSDOM } = require('jsdom'));
  } catch (e2) {
    console.error('Нужен jsdom:  cd tests/jsdom && npm install');
    console.error('  (или глобально: npm install -g jsdom)');
    process.exit(77);
  }
}

const ROOT = path.resolve(__dirname, '..', '..');
const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

const html = fs.readFileSync(path.join(ROOT, 'ui', 'index.html'), 'utf8');

// --- извлекаем JS и HTML-каркас окна активации ------------------------------
// Целиком ui/index.html в jsdom грузить нельзя: он сразу начинает дёргать /api/*
// и поднимать EventSource. Поэтому берём только разметку модалки и объект Lic,
// а внешние зависимости ($, show, hide, Snd, setStatus, addChip, fetch) подводим сами.
const scriptSrc = html.match(/<script[^>]*>([\s\S]*?)<\/script>/)[1];
// берём с хелпера fmtLeft: renderCountdown() его использует, и если вырезать
// только блок Lic, тест упадёт с ReferenceError вместо проверки поведения
const licStart = scriptSrc.indexOf('// «5 дн 3 ч»');
if (licStart < 0) { console.error('не найден хелпер fmtLeft в ui/index.html'); process.exit(1); }
const licEnd = scriptSrc.indexOf('/* ==================== СТРАЖ ПК');
if (licStart < 0 || licEnd < 0) {
  console.error('не удалось вырезать блок Lic из ui/index.html');
  process.exit(1);
}
const licSrc = scriptSrc.slice(licStart, licEnd);

const licOvHtml = html.match(/<!-- активация лицензии -->([\s\S]*?)<\/div><\/div>/)[1];

const dom = new JSDOM(`<!DOCTYPE html><html><body>
  <span id="cdpDot"></span><div id="status"></div>
  ${licOvHtml}
</body></html>`, { runScripts: 'outside-only' });

const { window } = dom;
const calls = { status: [], chips: [], sounds: [] };
let LICENSE_RESPONSE = { ok: true };
let KEYSTATUS_RESPONSE = null;

window.$ = id => window.document.getElementById(id);
window.show = id => window.$(id).classList.add('show');
window.hide = id => window.$(id).classList.remove('show');
window.setStatus = t => calls.status.push(t);
window.addChip = (k, t) => calls.chips.push([k, t]);
window.Snd = { play: (n, v) => calls.sounds.push(n) };
window.confirm = () => true;
window.fetch = async (url, opt) => {
  const body = opt && opt.body ? JSON.parse(opt.body) : {};
  if (url === '/api/license') return { json: async () => LICENSE_RESPONSE, status: 200 };
  if (url === '/api/license/keystatus') {
    if (KEYSTATUS_RESPONSE === null) throw new Error('offline');
    return { json: async () => KEYSTATUS_RESPONSE, status: 200 };
  }
  if (url === '/api/license/activate') {
    return { json: async () => LICENSE_RESPONSE._activate || { ok: false, message: 'нет' },
             status: 200 };
  }
  if (url === '/api/license/check') return { json: async () => ({ ok: true }), status: 200 };
  if (url === '/api/license/deactivate') return { json: async () => ({ ok: true, released: true }), status: 200 };
  return { json: async () => ({}), status: 404 };
};

// `const Lic` при window.eval не попадает в global — выводим его явно
window.eval(licSrc + '\n;window.Lic = Lic;');
const Lic = window.Lic;

const $ = id => window.document.getElementById(id);
const txt = id => ($(id) ? $(id).textContent.trim() : '<нет элемента>');

(async () => {
  console.log('\n[1] Первый запуск: просто «вставь ключ»');
  LICENSE_RESPONSE = {
    ok: false, activated: false, first_run: true, required: true, need_key: true,
    reason: 'Введи лицензионный ключ, чтобы продолжить.',
    headline: 'Введи ключ доступа', server: 'http://127.0.0.1:8790',
    server_baked: '', server_locked: false, revoke: null, hwid_info: {},
  };
  await Lic.load();
  check('заголовок — «Введи ключ доступа»', txt('licTitle') === '🔑 Введи ключ доступа', txt('licTitle'));
  check('плашка блокировки НЕ показана', !$('licOv').classList.contains('blocked'));
  check('подсказка про письмо о покупке',
        /Скопируй ключ из письма/.test(txt('licWhy')), txt('licWhy'));
  check('значок в шапке — «не активировано»', /не активировано/.test(txt('licBadge')), txt('licBadge'));
  check('одно поле вставки присутствует', !!$('licPaste'));
  check('главная кнопка — «Активировать»', txt('licGo') === 'Активировать', txt('licGo'));

  console.log('\n[2] Вставка ключа куском письма');
  // ключ с настоящим контрольным символом: берём его из python-формата
  const { execFileSync } = require('child_process');
  const KEY = execFileSync('python3', ['-c',
    'import sys;sys.path.insert(0,".");from app.license_fmt import make_key;print(make_key())'],
    { cwd: ROOT, encoding: 'utf8' }).trim();
  $('licPaste').value = `Спасибо за покупку!\nВаш ключ: ${KEY}\nСохраните его.`;
  const found = Lic.onPasteInput();
  check('ключ извлечён из текста письма', found === KEY, found + ' != ' + KEY);
  check('подсказка «ключ распознан»', /ключ распознан/.test(txt('licFound')), txt('licFound'));
  check('упомянут отброшенный лишний текст', /лишний текст/.test(txt('licFound')), txt('licFound'));
  check('поле подсвечено как корректное', $('licPaste').className === 'ok', $('licPaste').className);
  check('скрытое поле licKey заполнено', $('licKey').value === KEY, $('licKey').value);

  console.log('\n[3] Опечатка в ключе');
  const bad = KEY.slice(0, -1) + (KEY.slice(-1) === 'A' ? 'B' : 'A');
  $('licPaste').value = bad;
  const r2 = Lic.onPasteInput();
  check('битый ключ НЕ принят', r2 === null, String(r2));
  check('сказано про контрольный символ', /контрольный символ/.test(txt('licFound')), txt('licFound'));
  check('поле подсвечено как ошибка', $('licPaste').className === 'err', $('licPaste').className);

  console.log('\n[4] Мусор вместо ключа');
  $('licPaste').value = 'привет, это не ключ';
  Lic.onPasteInput();
  check('не распознан', $('licKey').value === '', $('licKey').value);
  check('объяснено, чего не хватает', /4 группы по 5/.test(txt('licFound')), txt('licFound'));

  console.log('\n[5] Ключ УДАЛЁН — текст, который просил заказчик');
  LICENSE_RESPONSE = {
    ok: false, activated: false, first_run: false, required: true, need_key: true, revoked: true,
    reason: 'Этот ключ доступа был удалён. Причина: возврат средств. Требуется новый ключ.',
    headline: 'Этот ключ доступа был удалён',
    revoke: { kind: 'deleted', reason: 'возврат средств', reason_text: 'возврат средств',
              title: 'Этот ключ доступа был удалён', permanent: true,
              message: 'Этот ключ доступа был удалён. Причина: возврат средств',
              at: 1760000000, key_id: 'AB12CD34EF56', key_masked: 'FLX2-M6BB6-*****-*****-HYSED' },
    server: 'https://lic.example.com', server_baked: 'https://lic.example.com',
    server_locked: true, hwid_info: {},
  };
  await Lic.load();
  check('плашка блокировки показана', $('licOv').classList.contains('blocked'));
  check('заголовок — «Этот ключ доступа был удалён»',
        txt('licBlockTitle') === 'Этот ключ доступа был удалён', txt('licBlockTitle'));
  check('заголовок окна совпадает', /Этот ключ доступа был удалён/.test(txt('licTitle')), txt('licTitle'));
  check('причина видна', /^Причина: возврат средств$/.test(txt('licBlockReason')), txt('licBlockReason'));
  check('сказано, что нужен новый ключ', /нужен новый/.test(txt('licBlockMeta')), txt('licBlockMeta'));
  check('показана маска ключа', /FLX2-M6BB6/.test(txt('licBlockMeta')), txt('licBlockMeta'));
  check('значок в шапке — «ключ заблокирован»', /ключ заблокирован/.test(txt('licBadge')), txt('licBadge'));
  check('поле сервера заблокировано (зашито в сборку)', $('licSrv').disabled === true);
  check('адрес сервера подставлен из сборки', $('licSrv').value === 'https://lic.example.com', $('licSrv').value);
  check('НЕ написано «Введи ключ доступа»', !/Введи ключ доступа/.test(txt('licTitle')), txt('licTitle'));

  console.log('\n[6] Ключ ОТОЗВАН на неопределённое время (без причины)');
  LICENSE_RESPONSE = {
    ok: false, activated: false, first_run: false, required: true, need_key: true, revoked: true,
    reason: 'Этот ключ доступа отозван на неопределённое время.',
    headline: 'Этот ключ доступа отозван на неопределённое время',
    revoke: { kind: 'suspended', reason: '', reason_text: 'ключ приостановлен до решения разработчика',
              title: 'Этот ключ доступа отозван на неопределённое время', permanent: false,
              message: 'Этот ключ доступа отозван на неопределённое время',
              at: 1760000000, key_id: 'ZZ99YY88XX77', key_masked: 'FLX2-AAAAA-*****-*****-BBBBB' },
    server: 'http://127.0.0.1:8790', server_baked: '', server_locked: false, hwid_info: {},
  };
  await Lic.load();
  check('заголовок — «отозван на неопределённое время»',
        txt('licBlockTitle') === 'Этот ключ доступа отозван на неопределённое время',
        txt('licBlockTitle'));
  check('без пустой «Причины:»', !/^Причина:\s*$/.test(txt('licBlockReason')), txt('licBlockReason'));
  check('сказано, что блокировку можно снять', /может снять блокировку/.test(txt('licBlockMeta')), txt('licBlockMeta'));
  check('поле сервера НЕ заблокировано (сборка из исходников)', $('licSrv').disabled === false);

  console.log('\n[7] Активная лицензия');
  LICENSE_RESPONSE = {
    ok: true, activated: true, required: true, plan: 'pro', license_id: 'AB12CD34EF56',
    key_masked: 'FLX2-M6BB6-*****-*****-HYSED', expires: 0, days_left: null,
    offline_days_left: 12.5, hwid: 'a'.repeat(32), hwid_reliable: true, hwid_label: 'DESKTOP-TEST',
    server: 'https://lic.example.com', server_baked: '', server_locked: false,
    revoke: null, first_run: false, hwid_info: {},
  };
  await Lic.load();
  check('плашка блокировки скрыта', !$('licOv').classList.contains('blocked'));
  check('в сводке статус АКТИВНО', /Статус: АКТИВНО/.test(txt('licInfo')), txt('licInfo').slice(0, 60));
  check('план показан', /План: pro/.test(txt('licInfo')));
  check('бессрочность показана', /бессрочно/.test(txt('licInfo')));
  check('значок в шапке зелёный', $('licBadge').className.indexOf('on') >= 0, $('licBadge').className);
  check('blocked() = false при активной лицензии', Lic.blocked() === false);

  console.log('\n[8] Обратный отсчёт в шапке');
  // сценарий заказчика: 3 дня -> 1 день -> 15 часов -> 10 часов -> 0 -> конец
  // Пороги цвета в UI: <=6ч -> low (красный), <=48ч -> warn (жёлтый), иначе нейтральный.
  // 86400с = ровно 1 сутки, то есть попадает в warn — это ожидаемо и правильно:
  // предупреждать надо заранее, а не в момент блокировки.
  const cdCases = [
    [5*86400,          '⏳ 5 дн',     ''],      // только что отметились
    [3*86400 + 5*3600, '⏳ 3 дн 5 ч', ''],      // ещё далеко до порога
    [2*86400 + 1*3600, '⏳ 2 дн 1 ч', ''],      // 49ч — последний нейтральный час
    [48*3600,          '⏳ 2 дн',     'warn'],  // ровно на границе warn
    [86400,            '⏳ 1 дн',     'warn'],
    [15*3600,          '⏳ 15 ч',     'warn'],
    [10*3600,          '⏳ 10 ч',     'warn'],
    [6*3600,           '⏳ 6 ч',      'low'],   // ровно на границе low
    [5*3600,           '⏳ 5 ч',      'low'],
    [600,              '⏳ 10 мин',   'low'],
  ];
  for (const [sec, wantText, wantCls] of cdCases) {
    LICENSE_RESPONSE = {
      ok: true, activated: true, required: true, plan: 'pro', license_id: 'AB12CD34EF56',
      expires: 0, offline_days_left: null, hwid: 'a'.repeat(32), hwid_reliable: true,
      server: 'https://lic.example.com', server_baked: '', server_locked: false,
      revoke: null, first_run: false, hwid_info: {},
      countdown: { active: true, seconds_left: sec, human: '', until: 0,
                   next_check_in: 43200, next_check_human: '12 ч',
                   ticket_ttl_hours: 120, active_clients: 1500, expired: false },
    };
    await Lic.load();
    const el = $('licCd');
    check(`отсчёт ${sec}с показан в шапке`, !!el && el.textContent === wantText,
          el ? el.textContent : 'нет элемента');
    check(`отсчёт ${sec}с: класс «${wantCls || '(без)'}»`,
          el && (wantCls ? el.className.includes(wantCls) : !/low|warn/.test(el.className)),
          el ? el.className : 'нет элемента');
  }
  check('в сводке есть строка «Работает без связи с сервером»',
        /Работает без связи с сервером/.test(txt('licInfo')), txt('licInfo').slice(0, 200));
  check('в сводке показана следующая проверка',
        /Следующая проверка ключа/.test(txt('licInfo')), txt('licInfo').slice(0, 300));
  check('в сводке видно число активных клиентов',
        /активно клиентов: 1500/.test(txt('licInfo')), txt('licInfo').slice(0, 400));

  console.log('\n[8b] Отсчёт скрыт, когда лицензии нет');
  LICENSE_RESPONSE = { ok: false, activated: false, first_run: true, required: true,
    reason: 'Введи лицензионный ключ, чтобы продолжить.', headline: 'Введи ключ доступа',
    server: '', server_baked: '', server_locked: false, revoke: null, hwid_info: {},
    countdown: { active: false, seconds_left: null, human: '' } };
  await Lic.load();
  check('без лицензии элемента отсчёта нет', !$('licCd'));

  console.log('\n[9] Дополнительно свёрнуто по умолчанию');
  check('панель «Дополнительно» закрыта', !$('licAdv').classList.contains('open'));
  $('licAdvToggle').click();
  check('по клику открывается', $('licAdv').classList.contains('open'));
  check('стрелка переключилась', /^▾/.test(txt('licAdvToggle')), txt('licAdvToggle'));
  check('кнопка «Деактивировать» внутри панели', !!$('licDeact'));

  console.log(`\n${'='.repeat(60)}`);
  console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
  if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
  process.exit(FAIL.length ? 1 : 0);
})().catch(e => { console.error('ОШИБКА ТЕСТА:', e); process.exit(2); });
