/* Проверка админки лицензий на настоящем DOM (jsdom): кнопки «Удалить ключ» /
   «Отозвать», предпросмотр причины, восстановление.

   Зачем: формулировка причины — это ровно тот текст, который увидит покупатель
   в окне активации. Если админка и app/license_fmt.revoke_message разойдутся,
   пользователь получит не то, что ему обещали в предпросмотре.

   Запуск:  node tests/jsdom/admin_actions.test.cjs
*/
'use strict';
const fs = require('fs');
const path = require('path');
// jsdom ищется сначала в локальном node_modules (cd tests/jsdom && npm install),
// затем обычным require — чтобы тест можно было запустить из распакованного
// архива, где node_modules не поставляется.
let JSDOM;
try {
  ({ JSDOM } = require(path.join(__dirname, 'node_modules', 'jsdom')));
} catch (e) {
  try {
    ({ JSDOM } = require('jsdom'));
  } catch (e2) {
    console.error('Нужен jsdom:  cd tests/jsdom && npm install');
    console.error('  (или глобально: npm install -g jsdom)');
    process.exit(77);
  }
}

const ROOT = path.resolve(__dirname, '..', '..');
const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

const html = fs.readFileSync(path.join(ROOT, 'license_server', 'admin.html'), 'utf8');
const scriptSrc = html.match(/<script[^>]*>([\s\S]*?)<\/script>/)[1];

// --- эталонные формулировки из app/license_fmt.py ----------------------------
// Берём их ИЗ PYTHON, а не хардкодим: тест должен падать, если тексты разъедутся.
const { execFileSync } = require('child_process');
const py = execFileSync('python3', ['-c', `
import json, sys
sys.path.insert(0, ".")
from app.license_fmt import revoke_message
print(json.dumps({
  "del_r":   revoke_message("deleted", "возврат средств"),
  "del_nor": revoke_message("deleted", ""),
  "sus_nor": revoke_message("suspended", ""),
  "sus_r":   revoke_message("suspended", "подозрение на перепродажу ключа"),
}, ensure_ascii=False))
`], { cwd: ROOT, encoding: 'utf8' });
const EXPECT = JSON.parse(py.trim().split('\n').pop());

const dom = new JSDOM(`<!DOCTYPE html><html><body>${html.replace(/<script[\s\S]*?<\/script>/, '')}</body></html>`,
                      { runScripts: 'outside-only', url: 'http://localhost/admin' });
const { window } = dom;
const $ = id => window.document.getElementById(id);
const txt = id => ($(id) ? $(id).textContent.trim() : '<нет>');

// --- заглушки сети -----------------------------------------------------------
const POSTED = [];
let STATS = { total: 3, active: 1, inactive: 1, revoked: 1, expired: 0,
              deleted: 1, suspended: 0, devices: 2 };
let LICENSES = [
  { key_id: 'AAAA1111BBBB', status: 'active', plan: 'pro', customer: 'ivan@mail.ru',
    note: 'заказ 1', issued_at: 1750000000, expires_at: 0, max_activations: 1,
    revoke_kind: '', revoke_reason: '', activations: [{ hwid: 'a'.repeat(32), released: 0, last_seen: 1760000000 }] },
  { key_id: 'DELE1234TED9', status: 'revoked', plan: 'standard', customer: '',
    note: '', issued_at: 1750000000, expires_at: 0, max_activations: 1,
    revoke_kind: 'deleted', revoke_reason: 'возврат средств', activations: [] },
];
window.fetch = async (url, opt) => {
  if (opt && opt.method === 'POST') POSTED.push([url, JSON.parse(opt.body || '{}')]);
  let payload = { ok: true };
  if (url.includes('/admin/api/stats')) payload = { ok: true, stats: STATS, key_fingerprint: 'FP123', heartbeat_hours: 72 };
  else if (url.includes('/admin/api/licenses')) payload = { ok: true, licenses: LICENSES };
  else if (url.includes('/admin/api/delete') || url.includes('/admin/api/suspend') ||
           url.includes('/admin/api/unrevoke'))
    payload = { ok: true, license: { key_id: 'X', status: 'revoked' } };
  return { ok: true, status: 200, json: async () => payload };
};
window.localStorage.setItem('flux_admin_token', 'tok');
window.alert = m => POSTED.push(['alert', m]);
const CONFIRMS = [];
window.confirm = m => { CONFIRMS.push(m); return true; };
const PROMPTS = [];
window.prompt = (m, d) => { PROMPTS.push(m); return d; };

window.eval(scriptSrc + '\n;window.__api = {openBlockModal, closeBlockModal, updatePreview, currentReason, action, render, refresh};');
const A = window.__api;

(async () => {
  console.log('\n[1] Кнопки в таблице лицензий');
  await A.refresh();
  const rowHtml = $('rows').innerHTML;
  check('у активного ключа есть «Удалить ключ»', /data-a="delete"[^>]*>\s*Удалить ключ/.test(rowHtml) ||
        rowHtml.includes('Удалить ключ'), '');
  check('у активного ключа есть «Отозвать»', /data-a="suspend"/.test(rowHtml));
  check('у удалённого ключа — «Восстановить»', /data-a="restore"/.test(rowHtml));
  check('у удалённого ключа НЕТ кнопки «Удалить»',
        !/data-a="delete" data-id="DELE1234TED9"/.test(rowHtml));
  check('причина видна в таблице', rowHtml.includes('возврат средств'), '');
  check('помечено как «удалён»', rowHtml.includes('✕ удалён'));

  console.log('\n[2] Карточки статистики');
  check('есть счётчик удалённых', $('cards').innerHTML.includes('из них удалено'));
  check('число удалённых = 1', /из них удалено/.test($('cards').innerHTML) &&
        $('cards').innerHTML.includes('>1<'));

  console.log('\n[3] Модалка «Удалить ключ»');
  A.openBlockModal('AAAA1111BBBB', 'delete');
  check('модалка открыта', !$('bmOv').classList.contains('hide'));
  check('заголовок «Удалить ключ»', txt('bmTitle') === 'Удалить ключ', txt('bmTitle'));
  check('показан id ключа', txt('bmId') === 'AAAA1111BBBB', txt('bmId'));
  check('предупреждение про «навсегда»', /удалён навсегда/i.test($('bmWarn').innerHTML),
        $('bmWarn').textContent.slice(0, 80));
  check('предупреждение красное (hard)', $('bmWarn').className.includes('hard'));
  check('в списке есть причина «возврат средств»',
        [...$('bmReason').options].some(o => o.value === 'возврат средств'));
  check('есть вариант «своя причина»',
        [...$('bmReason').options].some(o => o.value === '__custom__'));

  console.log('\n[4] Предпросмотр совпадает с app/license_fmt (deleted)');
  $('bmReason').value = ''; $('bmReason').dispatchEvent(new window.Event('change'));
  check('без причины — текст из Python', txt('bmPrevText') === EXPECT.del_nor,
        txt('bmPrevText') + ' != ' + EXPECT.del_nor);
  $('bmReason').value = 'возврат средств';
  $('bmReason').dispatchEvent(new window.Event('change'));
  check('с причиной — текст из Python', txt('bmPrevText') === EXPECT.del_r,
        txt('bmPrevText') + ' != ' + EXPECT.del_r);
  check('текст начинается с «Этот ключ доступа был удалён»',
        txt('bmPrevText').startsWith('Этот ключ доступа был удалён'), txt('bmPrevText'));

  console.log('\n[5] Своя причина');
  $('bmReason').value = '__custom__'; $('bmReason').dispatchEvent(new window.Event('change'));
  check('поле своей причины открылось', !$('bmCustomRow').classList.contains('hide'));
  $('bmCustom').value = 'ключ передан третьим лицам'; A.updatePreview();
  check('своя причина в предпросмотре',
        txt('bmPrevText') === 'Этот ключ доступа был удалён. Причина: ключ передан третьим лицам',
        txt('bmPrevText'));
  check('currentReason() отдаёт свою причину', A.currentReason() === 'ключ передан третьим лицам');

  console.log('\n[6] Модалка «Отозвать» (на неопределённое время)');
  A.openBlockModal('AAAA1111BBBB', 'suspend');
  check('заголовок «Отозвать ключ»', txt('bmTitle') === 'Отозвать ключ', txt('bmTitle'));
  check('предупреждение НЕ красное', !$('bmWarn').className.includes('hard'));
  check('сказано, что можно вернуть', /можно снять кнопкой «Вернуть»/.test($('bmWarn').innerHTML),
        $('bmWarn').textContent.slice(0, 90));
  $('bmReason').value = ''; $('bmReason').dispatchEvent(new window.Event('change'));
  check('без причины — ровно «отозван на неопределённое время»',
        txt('bmPrevText') === EXPECT.sus_nor, txt('bmPrevText') + ' != ' + EXPECT.sus_nor);
  check('без причины НЕТ хвоста «Причина:»', !/Причина:/.test(txt('bmPrevText')), txt('bmPrevText'));
  $('bmReason').value = "подозрение на перепродажу ключа";
  $('bmReason').dispatchEvent(new window.Event('change'));
  check('с причиной — текст из Python', txt('bmPrevText') === EXPECT.sus_r,
        txt('bmPrevText') + ' != ' + EXPECT.sus_r);

  console.log('\n[7] Отправка на сервер');
  POSTED.length = 0;
  A.openBlockModal('AAAA1111BBBB', 'delete');
  $('bmReason').value = 'возврат средств'; A.updatePreview();
  await window.__api.submitBlock ? null : null;
  // submitBlock не экспортирован — жмём кнопку, как это сделал бы админ
  $('bmOk').click();
  await new Promise(r => setTimeout(r, 30));
  const del = POSTED.find(p => p[0].includes('/admin/api/delete'));
  check('ушёл POST /admin/api/delete', !!del, JSON.stringify(POSTED));
  check('передан key_id', del && del[1].key_id === 'AAAA1111BBBB', del && JSON.stringify(del[1]));
  check('передана причина', del && del[1].reason === 'возврат средств', del && JSON.stringify(del[1]));
  check('модалка закрылась', $('bmOv').classList.contains('hide'));

  POSTED.length = 0;
  A.openBlockModal('BBBB2222CCCC', 'suspend');
  $('bmReason').value = ''; $('bmReason').dispatchEvent(new window.Event('change'));
  $('bmOk').click();
  await new Promise(r => setTimeout(r, 30));
  const sus = POSTED.find(p => p[0].includes('/admin/api/suspend'));
  check('ушёл POST /admin/api/suspend', !!sus, JSON.stringify(POSTED));

  console.log('\n[8] Отмена и Escape');
  A.openBlockModal('AAAA1111BBBB', 'delete');
  POSTED.length = 0;
  $('bmCancel').click();
  check('по отмене модалка закрыта', $('bmOv').classList.contains('hide'));
  check('по отмене запрос НЕ ушёл', POSTED.filter(p => p[0].includes('/admin/api/')).length === 0,
        JSON.stringify(POSTED));
  A.openBlockModal('AAAA1111BBBB', 'delete');
  window.document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape' }));
  check('Escape закрывает модалку', $('bmOv').classList.contains('hide'));

  console.log('\n[9] Восстановление удалённого ключа');
  POSTED.length = 0; CONFIRMS.length = 0;
  await A.action('restore', 'DELE1234TED9');
  await new Promise(r => setTimeout(r, 20));
  check('спрошено подтверждение (ключ был удалён)', CONFIRMS.length === 1, JSON.stringify(CONFIRMS));
  check('в подтверждении сказано про «УДАЛЁН навсегда»',
        /УДАЛЁН навсегда/.test(CONFIRMS[0] || ''), CONFIRMS[0]);
  check('ушёл POST /admin/api/unrevoke',
        POSTED.some(p => p[0].includes('/admin/api/unrevoke')), JSON.stringify(POSTED));

  console.log(`\n${'='.repeat(60)}`);
  console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
  if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
  process.exit(FAIL.length ? 1 : 0);
})().catch(e => { console.error('ОШИБКА ТЕСТА:', e); process.exit(2); });
