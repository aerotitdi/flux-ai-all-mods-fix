"""ПОЛНЫЙ стенд: сервер лицензий + клиентский сервер FLUX + реальный HTTP.

В отличие от tests/test_key_removal.py (который гоняет клиент и сервер лицензий
напрямую), здесь поднимается ещё и app/server.py — то есть проверяется путь,
которым реально идёт покупатель: UI -> /api/* -> licensing -> license_server.

Сценарий — ровно тот, что описан в задаче:
  1. первый запуск: нет лицензии, окно просит «Введи ключ доступа»;
  2. покупатель вставляет ключ КУСКОМ ПИСЬМА -> активация проходит;
  3. разработчик жмёт «Удалить ключ» с причиной;
  4. клиент блокируется, и /api/license отдаёт «Этот ключ доступа был удалён.
     Причина: …» — то, что увидит окно активации;
  5. перезапуск: причина на месте (хранится локально, без сети);
  6. вариант «отозван на неопределённое время» и его снятие.

Запуск:  python tests/e2e_key_flow.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import threading
import time

TMP = tempfile.mkdtemp(prefix="flux2-e2e-")
os.environ["FLUX2_HOME"] = os.path.join(TMP, "client")
os.environ["FLUX_LICENSE_DB"] = os.path.join(TMP, "licenses.db")
os.environ["FLUX_RL_ACTIVATE"] = "5000"
os.environ["FLUX_RL_HEARTBEAT"] = "5000"
os.environ["FLUX_RL_KEYSTATUS"] = "5000"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import aiohttp                                        # noqa: E402
from aiohttp import web                               # noqa: E402

from license_server import keys, server as LS, store as store_mod   # noqa: E402
from app import licensing                             # noqa: E402
from app.config import CONFIG                         # noqa: E402
from app.server import build_app                      # noqa: E402

LIC_PORT, APP_PORT = 8793, 8656
LIC = f"http://127.0.0.1:{LIC_PORT}"
APP = f"http://127.0.0.1:{APP_PORT}"
ADMIN_TOKEN = "e2e-admin-token"
PASS, FAIL = [], []


def check(name: str, cond: bool, extra: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if not cond else ""))


DB: store_mod.LicenseStore = None


def start_servers() -> None:
    global DB
    DB = store_mod.LicenseStore(os.environ["FLUX_LICENSE_DB"])
    lic_app = LS.build_app(os.environ["FLUX_LICENSE_DB"], ADMIN_TOKEN)
    lic_app["store"] = DB

    def run_lic():
        loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
        r = web.AppRunner(lic_app)
        loop.run_until_complete(r.setup())
        loop.run_until_complete(web.TCPSite(r, "127.0.0.1", LIC_PORT).start())
        loop.run_forever()

    def run_app():
        loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
        r = web.AppRunner(build_app())
        loop.run_until_complete(r.setup())
        loop.run_until_complete(web.TCPSite(r, "127.0.0.1", APP_PORT).start())
        loop.run_forever()

    threading.Thread(target=run_lic, daemon=True).start()
    threading.Thread(target=run_app, daemon=True).start()
    time.sleep(1.4)


async def scenario() -> None:
    CONFIG.settings["license_server_url"] = LIC
    CONFIG.settings["license_required"] = True
    CONFIG.save()

    print("\n[1] Первый запуск: окна активации просит ключ")
    async with aiohttp.ClientSession() as s:
        d = await (await s.get(APP + "/api/license")).json()
    check("first_run=True", d.get("first_run") is True, str(d.get("first_run")))
    check("headline — «Введи ключ доступа»", d.get("headline") == "Введи ключ доступа",
          str(d.get("headline")))
    check("нет заголовка про удаление",
          "удалён" not in (d.get("headline") or "").lower(), str(d.get("headline")))
    check("revoke пуст", not d.get("revoke"), str(d.get("revoke")))
    check("лицензия не активна", d.get("activated") is False)
    check("отпечаток устройства отдан", bool((d.get("hwid_info") or {}).get("effective_hwid")))

    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/chat", json={"text": "привет", "sid": "e2e"})
    check("чат заблокирован (403)", r.status == 403, str(r.status))
    body = await r.json()
    check("в 403 есть need_key", body.get("need_key") is True, str(body))

    print("\n[2] Покупатель вставляет ключ куском письма")
    rec = DB.issue(plan="pro", customer="buyer@example.com", max_activations=1)
    key = rec["key"]
    email = (f"Спасибо за покупку FLUX!\n\nВаш ключ доступа: {key}\n\n"
             f"Сохраните его — он показывается один раз.\nЗаказ №4471")
    async with aiohttp.ClientSession() as s:
        # сначала UI спросит статус ключа (подсказка до активации)
        r = await s.post(APP + "/api/license/keystatus", json={"key": email})
        ks = await r.json()
        check("keystatus принял ключ из текста письма", ks.get("ok") is True, str(ks)[:160])
        check("keystatus: ключ жив", ks.get("blocked") is False, str(ks)[:160])
        check("keystatus отдал key_id", ks.get("key_id") == rec["key_id"], str(ks.get("key_id")))
        check("keystatus НЕ отдал план", "plan" not in ks, str(sorted(ks)))

        r = await s.post(APP + "/api/license/activate", json={"key": email, "server": ""})
        act = await r.json()
    check("активация по тексту письма прошла", act.get("ok") is True, str(act)[:200])
    check("план определился", act.get("plan") == "pro", str(act.get("plan")))

    async with aiohttp.ClientSession() as s:
        d = await (await s.get(APP + "/api/license")).json()
    check("лицензия активна", d.get("activated") is True, str(d.get("reason")))
    check("first_run сбросился", d.get("first_run") is False)
    check("revoke пуст после активации", not d.get("revoke"))
    check("маска ключа показана", "*****" in (d.get("key_masked") or ""), str(d.get("key_masked")))
    check("полный ключ наружу НЕ отдаётся", key not in json.dumps(d), "ключ протёк в /api/license")

    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/chat", json={"text": "привет", "sid": "e2e2"})
    check("чат разблокирован", r.status != 403, str(r.status))

    print("\n[3] Разработчик жмёт «Удалить ключ»")
    async with aiohttp.ClientSession() as s:
        r = await s.post(LIC + "/admin/api/delete",
                         json={"key_id": rec["key_id"], "reason": "возврат средств"},
                         headers={"Authorization": f"Bearer {ADMIN_TOKEN}"})
        ad = await r.json()
    check("delete через админ-API прошёл", r.status == 200 and ad.get("ok"), str(ad)[:160])
    check("в базе revoke_kind=deleted", ad["license"].get("revoke_kind") == "deleted",
          str(ad["license"].get("revoke_kind")))
    check("в базе причина", ad["license"].get("revoke_reason") == "возврат средств")

    print("\n[4] Клиент блокируется и узнаёт причину")
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/check")
        cd = await r.json()
    check("проверка вернула 403", r.status == 403, str(r.status))
    check("в 403 сказано про удаление", "УДАЛЁН" in cd.get("message", ""), str(cd)[:200])
    check("в 403 есть объект revoke", isinstance(cd.get("revoke"), dict), str(cd)[:200])

    async with aiohttp.ClientSession() as s:
        d = await (await s.get(APP + "/api/license")).json()
    check("headline — «Этот ключ доступа был удалён»",
          d.get("headline") == "Этот ключ доступа был удалён", str(d.get("headline")))
    check("headline_kind=deleted", d.get("headline_kind") == "deleted", str(d.get("headline_kind")))
    check("headline_permanent=True", d.get("headline_permanent") is True)
    check("headline_reason — «возврат средств»",
          d.get("headline_reason") == "возврат средств", str(d.get("headline_reason")))
    check("в reason полная формулировка",
          "Этот ключ доступа был удалён. Причина: возврат средств" in d.get("reason", ""),
          str(d.get("reason")))
    check("need_key=True", d.get("need_key") is True)
    check("activated=False", d.get("activated") is False)
    check("полный ключ всё ещё не отдаётся", key not in json.dumps(d))

    print("\n[5] Перезапуск: причина переживает его без сети")
    CONFIG.load()
    st = licensing.status()
    check("после перезапуска headline тот же",
          st.get("headline") == "Этот ключ доступа был удалён", str(st.get("headline")))
    check("после перезапуска причина на месте",
          st.get("headline_reason") == "возврат средств", str(st.get("headline_reason")))
    raw = json.load(open(licensing.state_path(), encoding="utf-8"))
    check("в license.json есть revoke", isinstance(raw.get("revoke"), dict), str(raw.get("revoke")))
    check("билет удалён", not raw.get("ticket"))
    check("полного ключа в license.json нет", key not in json.dumps(raw), "ключ на диске!")

    print("\n[6] Повторная активация удалённым ключом отклонена с причиной")
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/activate", json={"key": key, "server": ""})
        ad = await r.json()
    check("активация отклонена", ad.get("ok") is not True, str(ad)[:160])
    check("error=revoked", ad.get("error") == "revoked", str(ad.get("error")))
    check("в message причина", "возврат средств" in ad.get("message", ""), str(ad.get("message")))
    check("в ответе revoke.kind=deleted",
          (ad.get("revoke") or {}).get("kind") == "deleted", str(ad.get("revoke")))

    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/keystatus", json={"key": key})
        ks = await r.json()
    check("keystatus: blocked=True", ks.get("blocked") is True, str(ks)[:160])
    check("keystatus: message про удаление",
          "Этот ключ доступа был удалён" in ks.get("message", ""), str(ks.get("message")))

    print("\n[7] Отзыв на неопределённое время и его снятие")
    rec2 = DB.issue(plan="standard", customer="second@example.com", max_activations=1)
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/activate", json={"key": rec2["key"], "server": ""})
        check("второй ключ активирован", (await r.json()).get("ok") is True)
        r = await s.post(LIC + "/admin/api/suspend",
                         json={"key_id": rec2["key_id"], "reason": ""},
                         headers={"Authorization": f"Bearer {ADMIN_TOKEN}"})
        sd = await r.json()
    check("suspend через админ-API прошёл", sd.get("ok") is True, str(sd)[:160])
    check("kind=suspended", sd["license"].get("revoke_kind") == "suspended",
          str(sd["license"].get("revoke_kind")))

    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/check")
        await r.json()
        d = await (await s.get(APP + "/api/license")).json()
    check("headline — «отозван на неопределённое время»",
          d.get("headline") == "Этот ключ доступа отозван на неопределённое время",
          str(d.get("headline")))
    check("permanent=False", d.get("headline_permanent") is False)
    check("в reason нет «Причина: .»", "Причина: ." not in d.get("reason", ""),
          str(d.get("reason")))

    async with aiohttp.ClientSession() as s:
        r = await s.post(LIC + "/admin/api/unrevoke", json={"key_id": rec2["key_id"]},
                         headers={"Authorization": f"Bearer {ADMIN_TOKEN}"})
        check("unrevoke прошёл", (await r.json()).get("ok") is True)
        r = await s.post(APP + "/api/license/activate", json={"key": rec2["key"], "server": ""})
        check("после возврата ключ снова активируется", (await r.json()).get("ok") is True)
        d = await (await s.get(APP + "/api/license")).json()
    check("лицензия снова активна", d.get("activated") is True, str(d.get("reason")))
    check("запись о блокировке стёрта", not d.get("revoke"), str(d.get("revoke")))

    print("\n[8] UI содержит всё нужное для обоих состояний")
    async with aiohttp.ClientSession() as s:
        html = await (await s.get(APP + "/")).text()
    for probe, why in (
        ('id="licPaste"', "поле вставки ключа"),
        ('id="licBlock"', "плашка причины блокировки"),
        ('id="licBlockTitle"', "заголовок причины"),
        ('id="licAdv"', "сворачиваемое «Дополнительно»"),
        ("onPasteInput", "обработчик вставки"),
        ("/api/license/keystatus", "вызов проверки ключа"),
        ("ключ распознан", "подсветка найденного ключа"),
        ("контрольный символ", "подсказка про опечатку"),
    ):
        check(f"UI: {why}", probe in html, probe)
    check("UI: нет устаревшего licKey как видимого поля",
          'id="licKey" type="hidden"' in html, "licKey должен быть hidden")


def main() -> int:
    print(f"FLUX 2.0 — сквозной сценарий ключа   ({TMP})")
    if not keys.exists():
        keys.init()
    start_servers()
    t0 = time.time()
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(scenario())
    finally:
        loop.close()
        try:
            DB.close()
        except Exception:
            pass
    print(f"\n{'=' * 64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time() - t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
