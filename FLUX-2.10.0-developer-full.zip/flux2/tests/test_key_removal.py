"""Сквозной тест удаления/отзыва ключа: админка -> сервер -> клиент -> окно активации.

Проверяет ровно то, что просил заказчик:
  * в админке есть действия delete и suspend, они доходят до базы;
  * после УДАЛЕНИЯ ключа клиент показывает «Этот ключ доступа был удалён. Причина: …»;
  * после ОТЗЫВА — «Этот ключ доступа отозван на неопределённое время»;
  * причина ПЕРЕЖИВАЕТ перезапуск приложения (хранится в data/license.json, а не
    теряется вместе с билетом — это и был исходный баг);
  * удалённый ключ нельзя активировать заново, а приостановленный — можно вернуть.

Запуск:  python tests/test_key_removal.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import threading
import time

TMP = tempfile.mkdtemp(prefix="flux2-revoke-")
os.environ["FLUX2_HOME"] = os.path.join(TMP, "client")
os.environ["FLUX_LICENSE_DB"] = os.path.join(TMP, "licenses.db")
os.environ["FLUX_RL_ACTIVATE"] = "5000"
os.environ["FLUX_RL_HEARTBEAT"] = "5000"
os.environ["FLUX_RL_KEYSTATUS"] = "5000"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import aiohttp                                        # noqa: E402
from aiohttp import web                               # noqa: E402

from license_server import crypto, keys, server as LS, store as store_mod  # noqa: E402
from app import licensing                             # noqa: E402
from app.config import CONFIG                         # noqa: E402
from app.license_fmt import (RK_DELETED, RK_SUSPENDED, extract_key,  # noqa: E402
                             paste_hint, revoke_message)

PORT = 8796
BASE = f"http://127.0.0.1:{PORT}"
ADMIN_TOKEN = "test-admin-token-456"
DEVICE = "ab" * 32
PASS, FAIL = [], []


def check(name: str, cond: bool, extra: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if not cond else ""))


DB: store_mod.LicenseStore = None


def start_license_server() -> None:
    global DB
    DB = store_mod.LicenseStore(os.environ["FLUX_LICENSE_DB"])
    app = LS.build_app(os.environ["FLUX_LICENSE_DB"], ADMIN_TOKEN)
    app["store"] = DB                     # общая база: тест смотрит в неё напрямую

    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        r = web.AppRunner(app)
        loop.run_until_complete(r.setup())
        loop.run_until_complete(web.TCPSite(r, "127.0.0.1", PORT).start())
        loop.run_forever()

    threading.Thread(target=run, daemon=True).start()
    time.sleep(0.6)


async def post(s, path, body, admin=False):
    hdr = {"Authorization": f"Bearer {ADMIN_TOKEN}"} if admin else {}
    async with s.post(BASE + path, json=body, headers=hdr) as r:
        return r.status, await r.json()


def reload_client():
    """«Перезапуск приложения»: перечитываем config и состояние лицензии с диска."""
    CONFIG.load()
    return licensing.status()


async def scenario() -> None:
    CONFIG.settings["license_server_url"] = BASE
    CONFIG.settings["license_required"] = True
    CONFIG.save()

    print("\n[1] Админка: delete и suspend доходят до базы")
    rec = DB.issue(plan="pro", customer="buyer@example.com", max_activations=1)
    key = rec["key"]
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/admin/api/delete", {"key_id": "НЕТ-ТАКОГО", "reason": "x"}, admin=True)
        check("delete несуществующего ключа -> 404", stt == 404, str(stt))

        rec2 = DB.issue(plan="standard", max_activations=1)
        stt, d = await post(s, "/admin/api/suspend",
                            {"key_id": rec2["key_id"], "reason": "оплата не подтверждена"}, admin=True)
        check("suspend через API работает", stt == 200 and d.get("ok"), str(d)[:160])
        check("suspend ставит status=revoked", d["license"]["status"] == "revoked", str(d["license"]["status"]))
        check("suspend ставит kind=suspended", d["license"].get("revoke_kind") == RK_SUSPENDED,
              str(d["license"].get("revoke_kind")))
        check("suspend сохраняет причину", d["license"].get("revoke_reason") == "оплата не подтверждена",
              str(d["license"].get("revoke_reason")))
        DB.unrevoke(rec2["key_id"])

    print("\n[2] Активация, затем УДАЛЕНИЕ ключа")
    await licensing.activate(key)
    v = licensing.validate()
    check("до удаления лицензия активна", v["ok"], str(v.get("reason")))
    check("first_run больше не true", reload_client().get("first_run") is False)

    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/admin/api/delete",
                            {"key_id": rec["key_id"], "reason": "возврат средств"}, admin=True)
    check("delete через API работает", stt == 200 and d.get("ok"), str(d)[:160])
    row = DB.get_by_id(rec["key_id"])
    check("в базе status=revoked", row["status"] == "revoked", row["status"])
    check("в базе revoke_kind=deleted", row.get("revoke_kind") == RK_DELETED,
          str(row.get("revoke_kind")))
    check("в базе причина", row.get("revoke_reason") == "возврат средств",
          str(row.get("revoke_reason")))
    check("запись о ключе СОХРАНЕНА (чтобы объяснить причину)", row is not None)
    check("все устройства освобождены",
          DB.activations(row["key_hash"], active_only=True) == [],
          str(DB.activations(row["key_hash"], active_only=True)))
    check("в аудите есть delete",
          any(a["action"] == "delete" for a in DB.audit_log(50, rec["key_id"])),
          str([a["action"] for a in DB.audit_log(50, rec["key_id"])]))

    print("\n[3] Клиент узнаёт об удалении через heartbeat")
    try:
        await licensing.heartbeat(force=True)
        check("heartbeat выбросил исключение", False, "исключения не было")
    except licensing.LicenseError as e:
        check("код ошибки — revoked", e.code == "revoked", e.code)
        check("в сообщении сказано про УДАЛЁН", "УДАЛЁН" in str(e), str(e))
        check("сообщение содержит «новый ключ»", "новый ключ" in str(e), str(e))
        check("в extra есть структурированный revoke",
              (e.extra.get("revoke") or {}).get("kind") == RK_DELETED,
              str(e.extra.get("revoke")))

    print("\n[4] Окно активации показывает причину удаления")
    st = licensing.status()
    check("статус не активен", st["activated"] is False)
    check("revoked=True", st.get("revoked") is True)
    check("headline — «Этот ключ доступа был удалён»",
          st.get("headline") == "Этот ключ доступа был удалён", str(st.get("headline")))
    check("в reason есть причина «возврат средств»",
          "возврат средств" in st.get("reason", ""), str(st.get("reason")))
    check("need_key=True (требуется новый ключ)", st.get("need_key") is True)
    rv = st.get("revoke") or {}
    check("revoke.kind == deleted", rv.get("kind") == RK_DELETED, str(rv.get("kind")))
    check("revoke.permanent == True", rv.get("permanent") is True, str(rv.get("permanent")))
    check("revoke.message совпадает с license_fmt",
          rv.get("message") == revoke_message(RK_DELETED, "возврат средств"),
          str(rv.get("message")))
    check("в revoke есть маска ключа", bool(rv.get("key_masked")), str(rv.get("key_masked")))
    check("в revoke есть key_id", rv.get("key_id") == rec["key_id"], str(rv.get("key_id")))
    check("полный ключ в состоянии НЕ хранится",
          json.dumps(st).find(key) < 0, "ключ протёк в status()")

    print("\n[5] Причина ПЕРЕЖИВАЕТ перезапуск (исходный баг)")
    st2 = reload_client()
    check("после перезапуска headline тот же",
          st2.get("headline") == "Этот ключ доступа был удалён", str(st2.get("headline")))
    check("после перезапуска причина на месте",
          "возврат средств" in st2.get("reason", ""), str(st2.get("reason")))
    check("после перезапуска permanent=True",
          (st2.get("revoke") or {}).get("permanent") is True)
    raw = json.load(open(licensing.state_path(), encoding="utf-8"))
    check("в license.json лежит запись revoke", isinstance(raw.get("revoke"), dict),
          str(raw.get("revoke")))
    check("билет при этом удалён", not raw.get("ticket"))

    print("\n[6] Удалённым ключом нельзя активироваться заново")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": DEVICE, "hwid_variants": [DEVICE]})
    check("активация отклонена (403)", stt == 403, str(stt))
    check("error == revoked", d.get("error") == "revoked", str(d.get("error")))
    check("в ответе есть объект revoke", isinstance(d.get("revoke"), dict), str(d.get("revoke")))
    check("revoke.kind == deleted", (d.get("revoke") or {}).get("kind") == RK_DELETED)
    check("в message видна причина", "возврат средств" in d.get("message", ""),
          str(d.get("message")))
    check("message начинается с «Этот ключ доступа был удалён»",
          d.get("message", "").startswith("Этот ключ доступа был удалён"),
          str(d.get("message")))

    print("\n[7] /v1/keystatus — проверка без активации")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/keystatus", {"key": key})
    check("keystatus отвечает 200", stt == 200, str(stt))
    check("keystatus: blocked=True", d.get("blocked") is True, str(d)[:160])
    check("keystatus: kind=deleted", (d.get("revoke") or {}).get("kind") == RK_DELETED)
    check("keystatus: message с причиной", "возврат средств" in d.get("message", ""),
          str(d.get("message")))
    check("keystatus НЕ отдаёт план", "plan" not in d, str(sorted(d)))
    check("keystatus НЕ отдаёт срок", "expires_at" not in d, str(sorted(d)))
    check("keystatus НЕ отдаёт клиента", "customer" not in d, str(sorted(d)))
    check("keystatus НЕ отдаёт устройства", "activations" not in d, str(sorted(d)))

    rec3 = DB.issue(plan="trial", max_activations=1)
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/keystatus", {"key": rec3["key"]})
    check("живой ключ: blocked=False", d.get("blocked") is False, str(d)[:160])
    check("живой ключ: можно активировать", "можно активировать" in d.get("message", ""),
          str(d.get("message")))
    check("живой ключ: место НЕ занято",
          DB.activations(DB.get_by_id(rec3["key_id"])["key_hash"], active_only=True) == [])

    stt, d = await post(aiohttp.ClientSession(), "/v1/keystatus", {"key": "мусор"})
    check("keystatus на мусор: format_ok=False", d.get("format_ok") is False, str(d)[:160])
    check("keystatus на мусор: есть подсказка", bool(d.get("hint")), str(d)[:200])

    print("\n[8] Отзыв на неопределённое время")
    rec4 = DB.issue(plan="pro", customer="second@example.com", max_activations=1)
    await licensing.activate(rec4["key"])
    check("второй ключ активирован", licensing.validate()["ok"])
    DB.suspend(rec4["key_id"], "")            # без причины
    try:
        await licensing.heartbeat(force=True)
        check("heartbeat сообщил об отзыве", False, "исключения не было")
    except licensing.LicenseError as e:
        check("сообщение про «неопределённое время»",
              "неопределённое время" in str(e), str(e))
    st = licensing.status()
    check("headline — «отозван на неопределённое время»",
          st.get("headline") == "Этот ключ доступа отозван на неопределённое время",
          str(st.get("headline")))
    check("permanent=False (можно вернуть)", (st.get("revoke") or {}).get("permanent") is False)
    check("в reason нет пустого «Причина:»", "Причина: ." not in st.get("reason", ""),
          str(st.get("reason")))
    check("устройства НЕ освобождены (это не удаление)",
          len(DB.activations(DB.get_by_id(rec4["key_id"])["key_hash"], active_only=False)) >= 0)

    print("\n[9] «Вернуть» снимает блокировку")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/admin/api/unrevoke", {"key_id": rec4["key_id"]}, admin=True)
    check("unrevoke работает", stt == 200 and d.get("ok"), str(d)[:160])
    check("revoke_kind очищен", not d["license"].get("revoke_kind"),
          str(d["license"].get("revoke_kind")))
    await licensing.activate(rec4["key"])
    st = licensing.status()
    check("после возврата лицензия активна", st["activated"] is True, str(st.get("reason")))
    check("запись о блокировке стёрта", not st.get("revoke"), str(st.get("revoke")))
    check("headline вернулся к активному состоянию",
          st.get("headline") == "Введи ключ доступа" or st.get("activated"),
          str(st.get("headline")))

    print("\n[10] Удалённый ключ вернуть нельзя как «живой»")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/admin/api/unrevoke", {"key_id": rec["key_id"]}, admin=True)
    check("unrevoke удалённого технически возможен (решает админ)", stt == 200, str(stt))
    row = DB.get_by_id(rec["key_id"])
    check("после unrevoke статус не revoked", row["status"] != "revoked", row["status"])
    check("место в лицензии свободно (устройства были освобождены при удалении)",
          DB.activations(row["key_hash"], active_only=True) == [])

    print("\n[11] Вставка ключа куском письма")
    k = crypto.make_key()
    check("извлечение из текста письма",
          extract_key(f"Спасибо за покупку!\nВаш ключ: {k}\nСохраните его.") == k)
    check("извлечение из нижнего регистра", extract_key(k.lower()) == k)
    check("извлечение с пробелами вместо дефисов",
          extract_key("ключ " + k.replace("-", " ")) == k)
    check("извлечение с длинным тире", extract_key(k.replace("-", "\u2013")) == k)
    check("мусор не принимается", extract_key("привет, это не ключ") is None)
    check("битый контрольный символ не принимается", extract_key(k[:-1] + "Z") in (None, k))
    check("подсказка на кириллицу", "русские буквы" in paste_hint("обычный текст"))
    check("подсказка на пустое поле", "Поле пустое" in paste_hint(""))
    check("подсказка на лишние символы", "лишнее" in paste_hint(k + "ZZZZZZZZ"))

    print("\n[12] activate() принимает ключ, вставленный куском письма")
    rec5 = DB.issue(plan="ultimate", max_activations=1)
    try:
        await licensing.activate(f"Заказ №4471. Ваш ключ доступа: {rec5['key']} — спасибо!")
        check("активация по тексту письма прошла", licensing.validate()["ok"])
    except licensing.LicenseError as e:
        check("активация по тексту письма прошла", False, f"{e.code}: {e}")

    print("\n[13] Миграция базы со старой схемы")
    old_db = os.path.join(TMP, "old.db")
    import sqlite3
    con = sqlite3.connect(old_db)
    con.executescript("""
    CREATE TABLE licenses (
        key_hash TEXT PRIMARY KEY, key_id TEXT NOT NULL, plan TEXT NOT NULL DEFAULT 'standard',
        customer TEXT DEFAULT '', note TEXT DEFAULT '', issued_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL DEFAULT 0, max_activations INTEGER NOT NULL DEFAULT 1,
        offline_days INTEGER NOT NULL DEFAULT 14,
        status TEXT NOT NULL DEFAULT 'inactive', revoked_at INTEGER, revoke_reason TEXT DEFAULT '',
        last_seen INTEGER);
    """)
    con.commit()
    con.close()
    try:
        mig = store_mod.LicenseStore(old_db)
        cols = {r[1] for r in mig._db.execute("PRAGMA table_info(licenses)")}
        check("колонка revoke_kind добавлена при миграции", "revoke_kind" in cols, str(sorted(cols)))
        r = mig.issue(plan="standard", max_activations=1)
        mig.revoke(r["key_id"], "старая база", RK_SUSPENDED)
        check("revoke работает на мигрированной базе",
              mig.get_by_id(r["key_id"])["status"] == "revoked")
        check("kind записался", mig.get_by_id(r["key_id"])["revoke_kind"] == RK_SUSPENDED)
        info = mig.revoke_info(mig.get_by_id(r["key_id"]))
        check("revoke_info отдаёт message", bool(info.get("message")), str(info))
        s2 = mig.stats()
        check("stats() считает suspended", s2.get("suspended") == 1, str(s2))
        check("stats() считает deleted", s2.get("deleted") == 0, str(s2))
        mig.close()
    except Exception as e:
        check("миграция старой базы не падает", False, f"{type(e).__name__}: {e}")

    print("\n[14] Тексты блокировки (license_fmt)")
    check("deleted + причина",
          revoke_message(RK_DELETED, "возврат средств") ==
          "Этот ключ доступа был удалён. Причина: возврат средств",
          revoke_message(RK_DELETED, "возврат средств"))
    check("suspended без причины — без хвоста «Причина:»",
          revoke_message(RK_SUSPENDED, "") ==
          "Этот ключ доступа отозван на неопределённое время",
          revoke_message(RK_SUSPENDED, ""))
    check("suspended + причина",
          revoke_message(RK_SUSPENDED, "оплата не подтверждена") ==
          "Этот ключ доступа отозван на неопределённое время. Причина: оплата не подтверждена",
          revoke_message(RK_SUSPENDED, "оплата не подтверждена"))
    # без причины текст не должен обрываться на голом заголовке — покупателю
    # важно видеть, что причина именно не указана, а не что сообщение недогрузилось
    _m = revoke_message(RK_DELETED, "")
    check("deleted без причины — внятный текст",
          _m.startswith("Этот ключ доступа был удалён") and "не указана" in _m, _m)
    check("нормализация «delete» -> deleted", crypto.normalize_kind("delete") == RK_DELETED)
    check("нормализация мусора -> suspended", crypto.normalize_kind("что-то") == RK_SUSPENDED)
    check("is_permanent(deleted)", crypto.is_permanent(RK_DELETED) is True)
    check("is_permanent(suspended)", crypto.is_permanent(RK_SUSPENDED) is False)


def main() -> int:
    print(f"FLUX 2.0 — тест удаления/отзыва ключа   ({TMP})")
    if not keys.exists():
        keys.init()
    start_license_server()
    t0 = time.time()
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(scenario())
    finally:
        loop.close()
        try:
            DB.close()
        except Exception:
            pass
    print(f"\n{'=' * 64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time() - t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
