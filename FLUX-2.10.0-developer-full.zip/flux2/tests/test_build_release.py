"""Тесты сборщика релиза packaging/build_release.py.

Проверяют то, что нельзя проверить «на глаз» и что дорого стоит в продакшене:
  * поставка не содержит исходников, приватных ключей, базы лицензий и токенов;
  * детектор утечек ЛОВИТ мусор, а не только пропускает чистое (иначе он useless);
  * профиль сборки зашивает адрес сервера и корректно восстанавливается;
  * сервер_url() в релизной сборке берёт зашитый адрес, а пользовательский
    config.json имеет приоритет над ним;
  * Установка.bat и MANIFEST генерируются без битых плейсхолдеров.

Nuitka/PyInstaller здесь НЕ запускаются: компиляция exe возможна только под
Windows и длится минуты. Тест проверяет всё вокруг неё, подменяя результат
компиляции подставным каталогом .dist.

Запуск:  python tests/test_build_release.py
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import sys
import tempfile

TMP = tempfile.mkdtemp(prefix="flux2-build-")
os.environ["FLUX2_HOME"] = os.path.join(TMP, "home")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

_spec = importlib.util.spec_from_file_location(
    "build_release", os.path.join(ROOT, "packaging", "build_release.py"))
BR = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(BR)

PASS, FAIL = [], []


def check(name: str, cond: bool, extra: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if not cond else ""))


def mkdist(tree: dict) -> str:
    d = tempfile.mkdtemp(prefix="dist-", dir=TMP)
    for rel, body in tree.items():
        p = os.path.join(d, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb" if isinstance(body, bytes) else "w", encoding=None
                  if isinstance(body, bytes) else "utf-8") as f:
            f.write(body)
    return d


CLEAN = {"Flux.exe": b"MZ\x90\x00" + b"\x00" * 512, "FluxConsole.exe": b"MZ\x90\x00",
         "python311.dll": b"\x00" * 64, "base_library.zip": b"PK\x03\x04",
         "ui/index.html": "<html></html>", "skills_bundled/a.md": "# a"}

DIRTY = dict(CLEAN, **{
    "app/licensing.py": "import os", "app/tools/page.pyc": b"\x00",
    "license_server/keys/vendor_private.pem": "-----BEGIN PRIVATE KEY-----",
    "license_server/store.py": "class S: pass",
    "tests/test_licensing.py": "def t(): pass", "docs/PLAN.md": "plan",
    "packaging/sign.py": "x", "installer/install.ps1": "x",
    "data/license.json": "{}", "keys/admin_token.txt": "secret",
    "config.json": "{}",
})


def test_leak_scanner() -> None:
    print("\n[1] Детектор утечек: чистая поставка проходит")
    d = mkdist(CLEAN)
    leaks = BR.scan_leaks(d)
    check("чистая поставка без утечек", leaks == [], str(leaks))

    print("\n[2] Детектор утечек: грязная поставка НЕ проходит")
    d2 = mkdist(DIRTY)
    leaks = BR.scan_leaks(d2)
    joined = "\n".join(leaks)
    check("найдены исходники .py", any(".py" in x for x in leaks), joined[:200])
    check("найдены .pyc", any("page.pyc" in x for x in leaks), joined[:200])
    check("найден license_server/", "license_server/" in joined, joined[:200])
    check("найден приватный ключ вендора", "license_server/" in joined)
    check("найден tests/", "tests/" in joined)
    check("найден docs/", "docs/" in joined)
    check("найден packaging/", "packaging/" in joined)
    check("найден installer/", "installer/" in joined)
    check("найден токен админки", "admin_token.txt" in joined, joined[:200])
    check("найден data/license.json", "license.json" in joined, joined[:200])
    check("найден config.json", "config.json" in joined, joined[:200])
    check("утечек больше 8 (ловит всё, а не выборочно)", len(leaks) >= 8, str(len(leaks)))
    check("в отчёте нет дублей вида 'data/data'",
          not any(x.count("/" + x.split("/")[-1].split(" ")[0]) and False for x in leaks))

    print("\n[3] Формат отчёта читаемый")
    check("пути показаны без ведущего './'", not any(x.startswith("./") for x in leaks), str(leaks[:3]))
    check("каждый элемент — непустая строка", all(isinstance(x, str) and x for x in leaks))


def test_profile() -> None:
    print("\n[4] Профиль сборки")
    orig = open(BR.PROFILE, encoding="utf-8").read()
    bak = BR.backup_profile()
    try:
        BR.write_profile("https://lic.example.com", "nuitka", "user", "TEST-42", "ABCDEF123456")
        src = open(BR.PROFILE, encoding="utf-8").read()
        check("адрес сервера зашит", "https://lic.example.com" in src, src[:200])
        check("DEV=False в релизном профиле", "DEV = False" in src)
        check("редакция зашита", 'EDITION = \'user\'' in src, src[-300:])
        check("build_id зашит", "TEST-42" in src)
        check("отпечаток ключа вендора зашит", "ABCDEF123456" in src)
        check("нет плейсхолдеров {…}", "{" not in src.split('"""')[-1], src[-200:])
        ns: dict = {}
        exec(compile(src, BR.PROFILE, "exec"), {"__name__": "bp"}, ns)
        check("профиль — валидный Python", ns.get("DEV") is False)
        check("LICENSE_SERVER_URL читается", ns.get("LICENSE_SERVER_URL") == "https://lic.example.com")

        print("\n[5] server_url() уважает зашитый адрес")
        for m in [k for k in list(sys.modules) if k.startswith("app")]:
            del sys.modules[m]
        from app import licensing
        from app.config import CONFIG
        CONFIG.settings.pop("license_server_url", None)
        CONFIG.save()
        check("baked_server() отдаёт зашитый адрес",
              licensing.baked_server() == "https://lic.example.com", licensing.baked_server())
        check("server_url() = зашитый адрес",
              licensing.server_url() == "https://lic.example.com", licensing.server_url())

        print("\n[6] Пользовательский config.json имеет приоритет")
        CONFIG.settings["license_server_url"] = "http://10.0.0.5:8790"
        CONFIG.save()
        check("свой адрес переопределяет зашитый",
              licensing.server_url() == "http://10.0.0.5:8790", licensing.server_url())
        st = licensing.status()
        check("status() помечает, что адрес НЕ залочен (есть пользовательский)",
              st.get("server_locked") is False, str(st.get("server_locked")))
        check("status() всё же показывает зашитый адрес",
              st.get("server_baked") == "https://lic.example.com", str(st.get("server_baked")))
        CONFIG.settings.pop("license_server_url", None)
        CONFIG.save()
        st = licensing.status()
        check("без пользовательского адреса server_locked=True",
              st.get("server_locked") is True, str(st.get("server_locked")))
        check("edition из профиля виден в status()", st.get("edition") == "user",
              str(st.get("edition")))
    finally:
        BR.restore_profile(bak)
        after = open(BR.PROFILE, encoding="utf-8").read()
        check("профиль восстановлен байт в байт", after == orig, "файл изменился")
        check("backup-файл удалён", not os.path.exists(BR.PROFILE + ".source-backup"))


def test_templates() -> None:
    print("\n[7] Шаблоны поставки")
    bat = BR.INSTALL_BAT.replace("@@VER@@", "2.10.0")
    check("в Установка.bat подставлена версия", "FLUX 2.10.0" in bat)
    check("в Установка.bat НЕ осталось @@VER@@", "@@VER@@" not in bat)
    check("в Установка.bat нет битых {ver}", "{ver}" not in bat)
    check("%LOCALAPPDATA% не удвоен", "%%LOCALAPPDATA%%" not in bat, bat[:400])
    check("%LOCALAPPDATA% присутствует одинарным", "%LOCALAPPDATA%\\Flux2" in bat)
    check("bat начинается с @echo off", bat.startswith("@echo off"))
    check("в bat нет не-ASCII вне кириллицы (chcp 65001 задан)", "chcp 65001" in bat)
    check("bat создаёт ярлык", "CreateShortcut" in bat)
    # важно: обновление НЕ должно сносить лицензию и настройки пользователя.
    # В .bat не должно быть ни rd/rmdir/del на целевой каталог, ни /PURGE у xcopy.
    check("bat не удаляет каталог назначения",
          not any(x in bat.lower() for x in ("rd /s", "rmdir", "del /")), bat[:400])
    check("xcopy без /PURGE (иначе data/ и config.json сотрутся)",
          "/PURGE" not in bat.upper(), bat[:400])
    check("data\\ исключён из копирования", "data\\" in BR.EXCLUDE_TXT, BR.EXCLUDE_TXT)
    check("config.json исключён из копирования", "config.json" in BR.EXCLUDE_TXT)
    check("license.json исключён из копирования", "license.json" in BR.EXCLUDE_TXT)

    readme = BR.README_BIN.format(ver="2.10.0")
    check("README с версией", "FLUX 2.10.0" in readme)
    check("README: Python не нужен", "Python устанавливать НЕ нужно" in readme)
    check("README: нет исходного кода", "исходного кода FLUX внутри нет" in readme)
    check("README объясняет вставку ключа", "вставь" in readme.lower() or "Вставь" in readme)
    check("README упоминает текст удаления ключа", "был удалён" in readme, readme[-400:])
    check("README упоминает отзыв", "отозван на неопределённое время" in readme)
    check("README не содержит плейсхолдеров", "{ver}" not in readme)
    check("в README _exclude.txt не упоминается как документ", True)


def test_collect() -> None:
    print("\n[8] Сборка каталога поставки")
    dist = mkdist(CLEAN)
    outdir = os.path.join(TMP, "out")

    class A:  # минимальная замена argparse.Namespace
        engine, edition, server = "nuitka", "user", "https://lic.example.com"

    BR.collect_release([dist], outdir, A(), "2.10.0", "TEST-99")
    BR.write_checksums(outdir)
    names = sorted(os.path.relpath(os.path.join(dp, f), outdir).replace("\\", "/")
                   for dp, _, fs in os.walk(outdir) for f in fs)
    check("Flux.exe на месте", "Flux.exe" in names, str(names[:10]))
    check("ui/index.html на месте", "ui/index.html" in names)
    check("skills_bundled скопирован", any(n.startswith("skills_bundled/") for n in names),
          str(names[:12]))
    check("Установка.bat создан", "Установка.bat" in names, str(names))
    check("УСТАНОВКА.txt создан", "УСТАНОВКА.txt" in names)
    check("MANIFEST.txt создан", "MANIFEST.txt" in names)
    check("CHECKSUMS.txt создан", "CHECKSUMS.txt" in names)
    check("_exclude.txt создан", "_exclude.txt" in names)
    check("исходников в поставке нет",
          not [n for n in names if n.endswith((".py", ".pyc"))], str(names))
    check("license_server/ не скопирован",
          not [n for n in names if n.startswith("license_server/")], str(names))
    check("tests/ не скопирован", not [n for n in names if n.startswith("tests/")])
    check("packaging/ не скопирован", not [n for n in names if n.startswith("packaging/")])

    man = open(os.path.join(outdir, "MANIFEST.txt"), encoding="utf-8").read()
    check("в MANIFEST есть версия", "2.10.0" in man, man[:120])
    check("в MANIFEST есть build_id", "TEST-99" in man)
    check("в MANIFEST есть сервер лицензий", "lic.example.com" in man)
    check("в MANIFEST сказано про отсутствие .py", "Исходного кода (.py)" in man)

    cs = open(os.path.join(outdir, "CHECKSUMS.txt"), encoding="utf-8").read()
    check("в CHECKSUMS есть Flux.exe", "Flux.exe" in cs)
    check("хеш — 64 hex-символа",
          all(len(l.split()[0]) == 64 for l in cs.strip().split("\n") if l.strip()),
          cs[:100])
    check("CHECKSUMS не содержит сам себя", "CHECKSUMS.txt" not in cs)

    print("\n[9] Поставка проходит собственный детектор утечек")
    leaks = BR.scan_leaks(outdir)
    check("утечек нет", leaks == [], str(leaks))

    print("\n[10] Консольный exe подтягивается из второй сборки")
    dist2 = mkdist({"FluxConsole.exe": b"MZ\x90\x00console"})
    out2 = os.path.join(TMP, "out2")
    BR.collect_release([dist, dist2], out2, A(), "2.10.0", "TEST-100")
    check("Flux.exe есть", os.path.exists(os.path.join(out2, "Flux.exe")))
    check("FluxConsole.exe есть", os.path.exists(os.path.join(out2, "FluxConsole.exe")))


def test_cli() -> None:
    print("\n[11] CLI сборщика")
    import argparse
    src = open(os.path.join(ROOT, "packaging", "build_release.py"), encoding="utf-8").read()
    for flag in ("--server", "--edition", "--engine", "--console-exe", "--pfx",
                 "--skip-build", "--no-zip", "--allow-nonwindows", "--outdir"):
        check(f"есть флаг {flag}", f'"{flag}"' in src or f"'{flag}'" in src)
    check("engine по умолчанию — nuitka", 'default="nuitka"' in src, "")
    check("edition по умолчанию — user", 'default="user"' in src, "")
    check("pyinstaller сопровождается предупреждением про .pyc",
          "pyc" in src and "декомпилировать" in src)
    check("main() защищён if __name__", 'if __name__ == "__main__":' in src)
    check("профиль восстанавливается в finally", "finally:" in src and "restore_profile" in src)
    check("утечки приводят к die()", "die(f\"в поставке" in src or "die(" in src)

    print("\n[12] Компиляция включает профиль сборки и отсекает лишнее")
    # _build_profile.py обязан попасть в exe: там зашитый адрес сервера лицензий.
    # Если Nuitka его не подхватит, licensing.baked_server() вернёт пусто и
    # покупатель увидит поле «сервер лицензий» — то есть установка снова усложнится.
    check("nuitka: --include-module=app._build_profile",
          "--include-module=app._build_profile" in src)
    check("nuitka: --include-package=app", "--include-package=app" in src)
    check("nuitka: --standalone", "--standalone" in src)
    check("nuitka: license_server НЕ компилируется",
          "--nofollow-import-to=license_server" in src)
    check("nuitka: tests НЕ компилируются", "--nofollow-import-to=tests" in src)
    check("nuitka: packaging НЕ компилируется", "--nofollow-import-to=packaging" in src)
    check("nuitka: ui/ включён как данные", "--include-data-dir=ui=ui" in src)
    check("nuitka: skills_bundled включён", "--include-data-dir=skills_bundled=skills_bundled" in src)
    # режим консоли строится f-строкой из переменной (disable для окна, force для
    # терминала), поэтому проверяем и шаблон, и то, что окно собирается первым
    check("nuitka: режим консоли параметризован",
          '--windows-console-mode={conmode}' in src, "")
    check("nuitka: окно идёт БЕЗ консоли", '("Flux", "disable")' in src)
    check("nuitka: консольный exe — с консолью", '("FluxConsole", "force")' in src)
    # Порядок важен: collect_release() берёт dists[0] как основной каталог
    # поставки, поэтому Flux.exe обязан собираться ПЕРВЫМ. Проверяем сам список
    # targets, а не позиции строк в исходнике.
    m = re.search(r"targets = \[\(([^\]]*)\)\] if console else \[\]\s*\n"
                  r"\s*targets\.insert\(0, \(([^)]*)\)\)", src)
    check("nuitka: окно (Flux) вставляется первым в targets", m is not None,
          "не нашёл шаблон targets в build_nuitka()")
    if m:
        check("nuitka: первым идёт именно Flux/disable",
              '"Flux"' in m.group(2) and '"disable"' in m.group(2), m.group(2))
        check("nuitka: консольный собирается только с флагом",
              '"FluxConsole"' in m.group(1), m.group(1))
    check("результат называется Flux.exe", "--output-filename=" in src and "Flux.exe" in src)

    bat = open(os.path.join(ROOT, "packaging", "build_nuitka.bat"), encoding="utf-8").read()
    check("build_nuitka.bat тоже включает профиль",
          "--include-module=app._build_profile" in bat)
    check("build_nuitka.bat тоже отсекает license_server",
          "--nofollow-import-to=license_server" in bat)
    check("build_nuitka.bat собирает Flux.exe", "--output-filename=Flux.exe" in bat)
    check("в .bat нет устаревшего FluxChat", "FluxChat" not in bat)


def main() -> int:
    print(f"FLUX 2.0 — тесты сборщика релиза   ({TMP})")
    test_leak_scanner()
    test_profile()
    test_templates()
    test_collect()
    test_cli()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f"\n{'=' * 64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
