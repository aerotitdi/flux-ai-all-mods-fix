@echo off
chcp 65001 >nul
title FLUX 2.0 - Installer
rem ============================================================================
rem  FLUX 2.0 Desktop installer (Windows 10/11 x64, Python 3.10+)
rem
rem  This .bat is a THIN WRAPPER on purpose:
rem   - ASCII only, so it parses identically under any OEM code page
rem     (the previous version carried cp866 comments and turned into mojibake);
rem   - all real work and all user-facing text live in install.ps1 (UTF-8 BOM);
rem   - no -EncodedCommand, no IEX, no temp .ps1: those are the top three
rem     triggers for antivirus heuristics on script installers.
rem
rem  Usage:
rem    Flux2-Installer.bat
rem    Flux2-Installer.bat -InstallDir D:\flux2 -Autostart
rem    Flux2-Installer.bat -SkipExe              (fast: run from venv, no build)
rem    Flux2-Installer.bat -Engine nuitka        (compile to native, best for IP)
rem    Flux2-Installer.bat -LicenseKey FLX2-XXXXX-XXXXX-XXXXX-XXXXX
rem    Flux2-Installer.bat -LicenseServer https://lic.example.com
rem    Flux2-Installer.bat -Quiet
rem ============================================================================
setlocal
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell"

"%PS%" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
set RC=%ERRORLEVEL%

if %RC% NEQ 0 (
  echo.
  echo [FLUX2] Installation FAILED with code %RC%. See the log above.
  echo [FLUX2] If Windows Defender SmartScreen blocked the script, click
  echo         "More info" - "Run anyway", or right-click install.ps1 -
  echo         Properties - Unblock, then retry.
  if "%1"=="" pause
  exit /b %RC%
)

echo.
echo [FLUX2] Done. Shortcuts "FLUX 2.0" and "FLUX 2.0 Console" are on the Desktop.
if "%1"=="" pause
endlocal
exit /b 0
