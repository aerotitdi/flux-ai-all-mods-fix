@echo off
chcp 65001 >nul
rem ===========================================================================
rem  FLUX 2.0 - PyInstaller build (Windows). Requires Python 3.10+ and pip.
rem
rem  NOTE: prefer packaging\build_nuitka.bat for release builds. Nuitka compiles
rem  Python to native code, so (a) there are no .py/.pyc files to decompile and
rem  (b) antivirus heuristics fire far less often than on a PyInstaller bundle.
rem  This script stays as the fast fallback.
rem
rem  The full installer is installer\Flux2-Installer.bat
rem
rem  FOR RELEASE BUILDS use packaging\build_release.py instead: it bakes the
rem  license server URL into app\_build_profile.py, verifies that no .py/.pyc or
rem  vendor private key leaked into the payload, and packs a ready-to-sell .zip.
rem ===========================================================================
cd /d "%~dp0.."
python -m pip install -r requirements.txt pyinstaller || goto :err

set VI=
if exist "packaging\version_info.py" set VI=--version-file packaging\version_info.py

rem 1) windowed exe (chat window, WebView2)
pyinstaller --noconfirm --clean --name Flux --windowed ^
  --distpath dist --workpath build --specpath build ^
  --icon "ui\flux.ico" %VI% ^
  --add-data "ui;ui" --add-data "skills_bundled;skills_bundled" ^
  --exclude-module license_server ^
  --hidden-import webview --hidden-import edge_tts --hidden-import websockets ^
  --hidden-import cryptography ^
  main.py || goto :err

rem 2) console exe (terminal chat)
pyinstaller --noconfirm --clean --name FluxConsole --console ^
  --distpath dist --workpath build --specpath build ^
  --icon "ui\flux.ico" %VI% ^
  --add-data "ui;ui" --add-data "skills_bundled;skills_bundled" ^
  --exclude-module license_server ^
  --hidden-import websockets --hidden-import edge_tts --hidden-import cryptography ^
  main.py || goto :err

echo.
echo [FLUX2] Done: dist\Flux\Flux.exe and dist\FluxConsole\FluxConsole.exe
echo [FLUX2] Next step: sign them  -^>  python packaging\sign.py -CertFile my.pfx ^
echo         -CertPass "..." -Targets dist\Flux\Flux.exe dist\FluxConsole\FluxConsole.exe
pause
exit /b 0
:err
echo [FLUX2] Build FAILED
pause
exit /b 1
