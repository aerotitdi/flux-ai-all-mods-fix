#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ОДНА команда, которая собирает готовый .exe FLUX для продажи.

Зачем этот скрипт существует
----------------------------
Раньше покупатель получал архив с ИСХОДНИКАМИ и должен был сам поставить Python,
завести venv и собрать exe инсталлером. Это долго, ломается на антивирусах и —
главное — отдаёт клиенту весь код FLUX.

Теперь сборка делается У ТЕБЯ, один раз:

    python packaging/build_release.py --server https://lic.example.com

На выходе — `release/FLUX-<версия>-win-x64/` и одноимённый .zip, внутри которых
ТОЛЬКО скомпилированное приложение:
    Flux.exe              — окно чата (двойной клик, ничего ставить не нужно)
    FluxConsole.exe       — терминальный режим
    ui/, skills_bundled/  — ресурсы интерфейса (HTML/MD, не код)
    Установка.bat         — ярлыки + автозапуск, без Python и без сборки
    УСТАНОВКА.txt, MANIFEST.txt, CHECKSUMS.txt

Исходников (.py) в поставке НЕТ — и это проверяется принудительно, а не «на глаз»:
после сборки скрипт сканирует результат и падает, если нашёл хоть один .py/.pyc,
приватный ключ вендора, базу лицензий или токен админки.

Про защиту кода
---------------
По умолчанию используется Nuitka: Python компилируется в C, а затем в машинный код.
Распаковать такой exe «pyinstxtractor'ом» и получить .pyc нельзя — байткода там нет.
Дополнительно помогает authenticode-подпись (--pfx): без неё SmartScreen и
антивирусы ругаются на любое малоизвестное exe, подписанное или нет.

Режим --engine pyinstaller оставлен как БЫСТРЫЙ запасной (собирается за минуты,
но внутри лежит .pyc-архив — его можно распаковать и декомпилировать). Для продажи
используй nuitka.

Запуск
------
    python packaging/build_release.py --server https://lic.example.com
    python packaging/build_release.py --server URL --pfx cert.pfx --pfx-pass "..."
    python packaging/build_release.py --engine pyinstaller        # быстро, менее защищено
    python packaging/build_release.py --edition user --console-exe
    python packaging/build_release.py --skip-build                # только упаковка готового dist/

Требования: Windows (для .exe), Python 3.10+, MSVC или MinGW-w64 для Nuitka
(Nuitka скачает MinGW сам при первом запуске).
"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

APP = os.path.join(ROOT, "app")
PROFILE = os.path.join(APP, "_build_profile.py")
RELEASE = os.path.join(ROOT, "release")

# Что кладём в поставку рядом с exe. Ресурсы, а не код: ui/index.html — это
# интерфейс (его всё равно отдаёт встроенный сервер), skills_bundled — подсказки.
ASSETS = {
    "ui": ("index.html", "flux.ico", "flux_icon.png"),
    "skills_bundled": None,          # None = каталог целиком
}

# Что в поставке оказаться НЕ ДОЛЖНО ни при каких условиях.
FORBIDDEN_EXTS = (".py", ".pyc", ".pyo", ".pyi", ".pyx")
FORBIDDEN_NAMES = (
    "vendor_private.pem", "vendor_public.pem", "passphrase.txt", "admin_token.txt",
    "licenses.db", "licenses.db-wal", "licenses.db-shm", "license.json", "config.json",
)
FORBIDDEN_DIRS = ("license_server", "tests", "docs", "packaging", "installer", "__pycache__",
                  ".git", ".venv", "keys", "data")

PROFILE_TEMPLATE = '''"""Профиль сборки FLUX. СГЕНЕРИРОВАН АВТОМАТИЧЕСКИ — не правь руками.

Собрано: {tool}
Команда: {cmd}

Этим файлом сборщик зашивает в exe то, что покупатель не должен вводить руками:
адрес сервера лицензий и редакцию поставки. Порядок приоритета адреса см. в
app/licensing.py::server_url().
"""
from __future__ import annotations

DEV = False                     # релизная сборка: лицензия обязательна
LICENSE_SERVER_URL = {server!r}
BUILD_FLAVOR = {flavor!r}
EDITION = {edition!r}
BUILT_AT = {built_at!r}
BUILD_ID = {build_id!r}
VENDOR_KEY_FINGERPRINT = {fp!r}
'''


def log(msg: str = "") -> None:
    print(f"[build] {msg}" if msg else "", flush=True)


def step(msg: str) -> None:
    log("")
    log("=" * 68)
    log(msg)
    log("=" * 68)


def die(msg: str, code: int = 1) -> None:
    print(f"\n[build] ОШИБКА: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


def run(cmd: list[str], cwd: str = ROOT, check: bool = True) -> subprocess.CompletedProcess:
    log("$ " + " ".join(str(c) for c in cmd[:6]) + (" …" if len(cmd) > 6 else ""))
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True)
    if check and r.returncode != 0:
        tail = (r.stdout or "")[-3000:] + (r.stderr or "")[-3000:]
        die(f"команда завершилась с кодом {r.returncode}:\n{tail}")
    return r


def version() -> str:
    try:
        from app import __version__
        return __version__
    except Exception:
        m = re.search(r'__version__\s*=\s*"([^"]+)"',
                      open(os.path.join(APP, "__init__.py"), encoding="utf-8").read())
        return m.group(1) if m else "0.0.0"


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ============================================================ проверки до сборки
def preflight(args) -> dict:
    step("Проверка окружения перед сборкой")
    info = {"py": sys.version.split()[0], "windows": os.name == "nt"}

    if not info["windows"] and not args.allow_nonwindows:
        die("Windows-.exe собирается только под Windows. Запусти этот скрипт на Windows\n"
            "       (или добавь --allow-nonwindows, если собираешь для проверки под Linux).")

    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519  # noqa: F401
    except ImportError:
        die("нет пакета cryptography: pip install -r requirements.txt")

    # приватный ключ вендора нужен, чтобы сервер мог подписывать билеты;
    # для САМОЙ сборки exe он не требуется, но без него нельзя выдать ключи.
    from license_server import crypto, keys as K
    if K.exists():
        fp = K.fingerprint()
        log(f"публичный ключ вендора: {fp}")
        if not os.path.exists(os.path.join(APP, "_vendor_key.py")):
            die("нет app/_vendor_key.py — клиент не сможет проверять билеты. "
                "Выполни: python -m license_server.keygen init")
        # сверяем встроенный ключ с тем, что лежит в license_server/keys
        emb = K.read_embedded_public()
        if emb and fp and crypto.key_id(emb.strip()) != fp:
            die("app/_vendor_key.py НЕ СООТВЕТСТВУЕТ license_server/keys/vendor_public.pem.\n"
                "       Клиент с таким exe не примет твои лицензии.\n"
                "       Выполни: python -m license_server.keygen init")
        info["fp"] = fp
    else:
        if args.require_vendor_key:
            die("нет ключей вендора: python -m license_server.keygen init")
        log("⚠ ключей вендора нет — сборка пойдёт, но лицензии проверяться не будут")
        info["fp"] = ""

    if not args.server and args.require_vendor_key:
        log("⚠ --server не задан: покупатель увидит поле «сервер лицензий» и будет "
            "вводить адрес руками. Для продажи укажи --server https://...")
    info["server"] = (args.server or "").rstrip("/")

    log(f"Python: {info['py']} | Windows: {info['windows']} | версия FLUX: {version()}")
    return info


# ============================================================ профиль сборки
def backup_profile() -> str:
    if not os.path.exists(PROFILE):
        return ""
    bak = PROFILE + ".source-backup"
    shutil.copy2(PROFILE, bak)
    return bak


def write_profile(server: str, flavor: str, edition: str, build_id: str, fp: str) -> None:
    """Зашить адрес сервера лицензий и редакцию в сборку."""
    with open(PROFILE, "w", encoding="utf-8") as f:
        f.write(PROFILE_TEMPLATE.format(
            tool=f"packaging/build_release.py ({flavor})",
            cmd=" ".join(sys.argv),
            server=server, flavor=flavor, edition=edition,
            built_at=time.strftime("%Y-%m-%d %H:%M:%S"),
            build_id=build_id, fp=fp))
    log(f"профиль сборки записан: server={server or '(не задан)'} edition={edition} id={build_id}")


def restore_profile(bak: str) -> None:
    if bak and os.path.exists(bak):
        shutil.move(bak, PROFILE)
        log("app/_build_profile.py восстановлен (исходный, DEV=True)")


# ============================================================ компиляция
def build_nuitka(console: bool) -> list[str]:
    """Nuitka: Python -> C -> машинный код. В результате нет ни .py, ни .pyc."""
    try:
        import nuitka  # noqa: F401
    except ImportError:
        log("Nuitka не установлен — ставлю (nuitka, ordered-set, zstandard)…")
        run([sys.executable, "-m", "pip", "install", "--quiet",
             "nuitka", "ordered-set", "zstandard"])
    ver = version()
    outs = []
    targets = [("FluxConsole", "force")] if console else []
    targets.insert(0, ("Flux", "disable"))
    for name, conmode in targets:
        cmd = [sys.executable, "-m", "nuitka",
               "--standalone", "--assume-yes-for-downloads", "--remove-output",
               f"--company-name={os.environ.get('FLUX_COMPANY', 'aerotitbit')}",
               f"--product-name=FLUX {ver} Desktop",
               f"--file-version={ver}", f"--product-version={ver}",
               "--file-description=FLUX - desktop AI assistant",
               f"--copyright=Copyright (C) {time.strftime('%Y')} aerotitbit",
               "--include-data-dir=ui=ui",
               "--include-data-dir=skills_bundled=skills_bundled",
               "--include-package=app", "--include-package=app.tools",
               # профиль сборки ОБЯЗАН попасть в exe: в нём зашитый адрес сервера
               # лицензий. Nuitka находит его через --include-package=app, но
               # указываем явно — молчаливый фолбэк на пустой адрес означает, что
               # покупатель увидит поле «сервер лицензий» и не сможет активироваться.
               "--include-module=app._build_profile",
               # сервер лицензий и тесты в клиентскую сборку не попадают НИКОГДА
               "--nofollow-import-to=license_server",
               "--nofollow-import-to=tests",
               "--nofollow-import-to=packaging",
               "--enable-plugin=multiprocessing",
               f"--windows-console-mode={conmode}",
               "--windows-uac-uiaccess=false",
               f"--output-filename={name}.exe",
               "--output-dir=build_nuitka",
               "--windows-icon-from-ico=ui/flux.ico",
               "main.py"]
        step(f"Nuitka: {name}.exe")
        run(cmd)
        dist = os.path.join(ROOT, "build_nuitka", "main.dist")
        if not os.path.isdir(dist):
            cands = [d for d in os.listdir(os.path.join(ROOT, "build_nuitka"))
                     if d.endswith(".dist")]
            if not cands:
                die(f"Nuitka не создал каталог .dist для {name}")
            dist = os.path.join(ROOT, "build_nuitka", cands[0])
        exe = os.path.join(dist, f"{name}.exe")
        if not os.path.exists(exe):
            die(f"не найден результат сборки: {exe}")
        outs.append(dist)
        log(f"готово: {exe} ({os.path.getsize(exe) / 1048576:.1f} МБ)")
    return outs


def build_pyinstaller(console: bool) -> list[str]:
    """PyInstaller: быстро, но внутри .pyc-архив — для продажи НЕ рекомендуется."""
    try:
        import PyInstaller  # noqa: F401
    except ImportError:
        log("PyInstaller не установлен — ставлю…")
        run([sys.executable, "-m", "pip", "install", "--quiet", "pyinstaller"])
    ver = version()
    vi = os.path.join(ROOT, "packaging", "version_info.py")
    outs = []
    targets = [("Flux", "--windowed")]
    if console:
        targets.append(("FluxConsole", "--console"))
    for name, mode in targets:
        cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
               "--name", name, mode, "--onedir",
               "--icon", "ui/flux.ico",
               "--add-data", "ui;ui" if os.name == "nt" else "ui:ui",
               "--add-data", "skills_bundled;skills_bundled" if os.name == "nt"
                            else "skills_bundled:skills_bundled",
               "--exclude-module", "license_server",
               "--exclude-module", "tests",
               "--exclude-module", "packaging",
               "--hidden-import", "cryptography",
               "--hidden-import", "websockets",
               "--hidden-import", "edge_tts",
               "--distpath", "build_pyi/dist", "--workpath", "build_pyi/work",
               "--specpath", "build_pyi"]
        if os.path.exists(vi):
            cmd += ["--version-file", vi]
        if mode == "--windowed":
            cmd += ["--hidden-import", "webview"]
        cmd.append("main.py")
        step(f"PyInstaller: {name}.exe")
        run(cmd)
        dist = os.path.join(ROOT, "build_pyi", "dist", name)
        if not os.path.exists(os.path.join(dist, f"{name}.exe")):
            die(f"не найден результат сборки: {dist}\\{name}.exe")
        outs.append(dist)
    return outs


# ============================================================ упаковка
INSTALL_BAT = r'''@echo off
chcp 65001 >nul
title FLUX @@VER@@ - установка
rem ============================================================================
rem  FLUX @@VER@@: установка готовой сборки. Python НЕ нужен, ничего не компилируется.
rem  Копирует приложение в %LOCALAPPDATA%\Flux2 и создаёт ярлыки.
rem ============================================================================
setlocal EnableDelayedExpansion
set "SRC=%~dp0"
set "DST=%LOCALAPPDATA%\Flux2"

echo.
echo  FLUX @@VER@@ - установка
echo  ---------------------------------------------
echo  Откуда: %SRC%
echo  Куда:   %DST%
echo.

if exist "%DST%" (
  echo  Каталог уже существует - обновляю файлы.
  echo  Настройки и лицензия в %%DST%%\data сохранятся.
)

rem data/ и config.json не трогаем: там лицензия, таймеры и настройки пользователя
xcopy "%SRC%*" "%DST%\" /E /Y /I /EXCLUDE:%~dp0_exclude.txt >nul 2>&1
if errorlevel 1 (
  rem без _exclude.txt пробуем просто скопировать всё, кроме самого батника
  xcopy "%SRC%*" "%DST%\" /E /Y /I >nul
)

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell"

echo  Создаю ярлыки...
"%PS%" -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "$d=[Environment]::GetFolderPath('Desktop');" ^
  "$s=$ws.CreateShortcut((Join-Path $d 'FLUX @@VER@@.lnk'));" ^
  "$s.TargetPath='%DST%\Flux.exe';$s.WorkingDirectory='%DST%';" ^
  "$s.IconLocation='%DST%\ui\flux.ico';$s.Description='FLUX @@VER@@';$s.Save();" ^
  "if(Test-Path '%DST%\FluxConsole.exe'){" ^
  " $c=$ws.CreateShortcut((Join-Path $d 'FLUX @@VER@@ Console.lnk'));" ^
  " $c.TargetPath='%DST%\FluxConsole.exe';$c.WorkingDirectory='%DST%';" ^
  " $c.IconLocation='%DST%\ui\flux.ico';$c.Save()}"

echo.
echo  Готово. Ярлык "FLUX @@VER@@" на рабочем столе.
echo.
echo  При первом запуске откроется окно активации: вставь лицензионный ключ.
echo  Ключ пришёл на почту после покупки. Больше вводить ничего не нужно.
echo.
if "%1"=="" pause
endlocal
exit /b 0
'''

EXCLUDE_TXT = "Установка.bat\r\n_exclude.txt\r\ndata\\\r\nconfig.json\r\nlicense.json\r\n"

README_BIN = """FLUX {ver} — установка (Windows 10/11 x64)
================================================================

Это ГОТОВАЯ сборка: Python устанавливать НЕ нужно, ничего не компилируется,
исходного кода FLUX внутри нет.

1) Запусти двойным щелчком:

       Установка.bat

   Приложение скопируется в %LOCALAPPDATA%\\Flux2, на рабочем столе появятся
   ярлыки «FLUX {ver}» и «FLUX {ver} Console».

   Хочешь без установки — просто запусти Flux.exe прямо из этой папки.

2) Первый запуск: откроется окно «Введи ключ доступа».
   Скопируй ключ из письма о покупке и вставь в поле (можно вставить письмо
   целиком — FLUX сам найдёт ключ). Нажми «Активировать».

   Сервер лицензий уже прописан в сборке, вводить адрес не нужно.

3) Дальше: шестерёнка -> Подключения -> «+ Добавить соединение» — сюда вводится
   API-ключ провайдера модели (это отдельный ключ, не лицензионный).

Обновление
----------------------------------------------------------------
Запусти Установка.bat из новой папки: файлы обновятся, а лицензия, настройки
и таймеры (каталог data\\ и config.json) сохранятся.

Если SmartScreen показывает «Windows защитила ваш ПК»
----------------------------------------------------------------
Это штатная реакция на приложение без подписи, а не признак вируса:
   «Подробнее» -> «Выполнить в любом случае».
Проверь контрольную сумму файла из CHECKSUMS.txt — она должна совпасть.

Удаление
----------------------------------------------------------------
Удали ярлыки и каталог %LOCALAPPDATA%\\Flux2.

Если ключ перестал работать
----------------------------------------------------------------
При запуске FLUX покажет причину дословно, например:
   «Этот ключ доступа был удалён. Причина: возврат средств»
   «Этот ключ доступа отозван на неопределённое время»
В обоих случаях нужен новый ключ или решение разработчика — напиши в поддержку.
"""


def scan_leaks(path: str) -> list[str]:
    """Принудительная проверка: в поставке не должно быть кода и секретов.

    Это не «для галочки»: Nuitka/PyInstaller при неверных флагах спокойно
    укладывают рядом с exe каталог с .py или подтягивают license_server/,
    а вместе с ним — приватный ключ вендора. Такая поставка позволяет любому
    покупателю напечатать себе лицензию, поэтому сборка на этом падает.
    """
    bad = []
    for dirpath, dirnames, filenames in os.walk(path):
        rel_dir = os.path.relpath(dirpath, path).replace("\\", "/")
        parts = [] if rel_dir == "." else rel_dir.split("/")
        for fd in FORBIDDEN_DIRS:
            if fd in parts:
                idx = parts.index(fd)
                shown = "/".join(parts[:idx + 1])
                bad.append(f"каталог {shown}/ в поставке")
                dirnames[:] = []
                break
        for fn in filenames:
            rel = (rel_dir + "/" + fn).lstrip("./")
            low = fn.lower()
            if low.endswith(FORBIDDEN_EXTS):
                bad.append(f"исходник {rel}")
            if low in FORBIDDEN_NAMES:
                bad.append(f"секрет/состояние {rel}")
            if low.endswith((".pem", ".p12", ".pfx", ".key", ".p8")):
                bad.append(f"ключ/сертификат {rel}")
    return sorted(set(bad))


def collect_release(dists: list[str], outdir: str, args, ver: str, build_id: str) -> str:
    step("Сборка каталога поставки")
    if os.path.exists(outdir):
        shutil.rmtree(outdir)
    os.makedirs(outdir, exist_ok=True)

    # основной exe берём из первой сборки (Flux), консольный — из второй, если есть
    main_dist = dists[0]
    for entry in os.listdir(main_dist):
        src = os.path.join(main_dist, entry)
        dst = os.path.join(outdir, entry)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)
    for extra in dists[1:]:
        name = os.path.basename(extra).replace(".dist", "")
        for entry in os.listdir(extra):
            if entry.lower().endswith(".exe"):
                shutil.copy2(os.path.join(extra, entry), os.path.join(outdir, entry))

    # ресурсы: ui/ и skills_bundled/ обязаны лежать рядом с exe
    for sub, only in ASSETS.items():
        s = os.path.join(ROOT, sub)
        d = os.path.join(outdir, sub)
        if not os.path.isdir(s):
            continue
        os.makedirs(d, exist_ok=True)
        for fn in os.listdir(s):
            if only and fn not in only:
                continue
            shutil.copy2(os.path.join(s, fn), os.path.join(d, fn))

    # документы и установщик
    with open(os.path.join(outdir, "Установка.bat"), "w", encoding="utf-8") as f:
        # НЕ .format(): внутри шаблона есть \%LOCALAPPDATA\% и фигурные скобки
        # PowerShell — str.format() на них падает. Замена токена безопаснее.
        f.write(INSTALL_BAT.replace('@@VER@@', ver))
    with open(os.path.join(outdir, "_exclude.txt"), "w", encoding="utf-8", newline="") as f:
        f.write(EXCLUDE_TXT)
    with open(os.path.join(outdir, "УСТАНОВКА.txt"), "w", encoding="utf-8") as f:
        f.write(README_BIN.format(ver=ver))

    files = []
    for dirpath, _, filenames in os.walk(outdir):
        for fn in filenames:
            p = os.path.join(dirpath, fn)
            files.append((os.path.relpath(p, outdir).replace("\\", "/"), os.path.getsize(p)))
    files.sort()
    total = sum(s for _, s in files)
    man = [f"FLUX {ver} — содержимое поставки", f"собрано: {time.strftime('%Y-%m-%d %H:%M:%S')}",
           f"сборка: {build_id} · движок: {args.engine} · редакция: {args.edition}",
           f"сервер лицензий: {args.server or '(не задан — поле введёт пользователь)'}",
           f"файлов: {len(files)}", "-" * 64]
    for rel, sz in files:
        man.append(f"{sz:>12,}  {rel}")
    man += ["-" * 64, f"{total:>12,}  ВСЕГО ({total / 1048576:.1f} МБ)", "",
            "Исходного кода (.py) в поставке нет: приложение скомпилировано."]
    with open(os.path.join(outdir, "MANIFEST.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(man) + "\n")
    log(f"файлов: {len(files)} · объём: {total / 1048576:.1f} МБ")
    return outdir


def write_checksums(outdir: str) -> None:
    lines = []
    for dirpath, _, filenames in os.walk(outdir):
        for fn in sorted(filenames):
            if fn == "CHECKSUMS.txt":
                continue
            p = os.path.join(dirpath, fn)
            rel = os.path.relpath(p, outdir).replace("\\", "/")
            lines.append(f"{sha256(p)}  {rel}")
    with open(os.path.join(outdir, "CHECKSUMS.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(sorted(lines)) + "\n")
    log(f"CHECKSUMS.txt: {len(lines)} файлов")


def sign_exes(outdir: str, args) -> None:
    if not args.pfx:
        log("подпись пропущена (не задан --pfx). Неподписанное exe чаще ловит "
            "SmartScreen и антивирусы.")
        return
    step("Подпись exe (authenticode)")
    targets = [os.path.join(outdir, f) for f in os.listdir(outdir) if f.lower().endswith(".exe")]
    cmd = [sys.executable, os.path.join(ROOT, "packaging", "sign.py"),
           "-CertFile", args.pfx, "-Targets", *targets]
    if args.pfx_pass:
        cmd[5:5] = ["-CertPass", args.pfx_pass]
    run(cmd)


def make_zip(outdir: str, ver: str, edition: str) -> str:
    name = f"FLUX-{ver}-{edition}-win-x64.zip"
    zpath = os.path.join(RELEASE, name)
    step(f"Упаковка {name}")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for dirpath, _, filenames in os.walk(outdir):
            for fn in sorted(filenames):
                p = os.path.join(dirpath, fn)
                z.write(p, os.path.relpath(p, os.path.dirname(outdir)))
    log(f"{zpath} ({os.path.getsize(zpath) / 1048576:.1f} МБ)")
    log(f"sha256: {sha256(zpath)}")
    return zpath


def main(argv=None) -> int:
    ver = version()
    ap = argparse.ArgumentParser(
        description="Собрать готовый .exe FLUX для продажи (без исходников).",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__.split("Запуск\n------")[-1])
    ap.add_argument("--server", default="", help="адрес сервера лицензий, зашиваемый в exe "
                                                 "(https://lic.example.com)")
    ap.add_argument("--edition", default="user", choices=["user", "developer"],
                    help="редакция поставки (пишется в профиль сборки)")
    ap.add_argument("--engine", default="nuitka", choices=["nuitka", "pyinstaller"],
                    help="nuitka = компиляция в машинный код (для продажи), "
                         "pyinstaller = быстро, но внутри .pyc")
    ap.add_argument("--console-exe", action="store_true",
                    help="собирать и FluxConsole.exe (терминальный режим)")
    ap.add_argument("--pfx", default="", help="сертификат кодовой подписи (.pfx)")
    ap.add_argument("--pfx-pass", default="", help="пароль к .pfx")
    ap.add_argument("--outdir", default="", help="каталог поставки (по умолчанию release/…)")
    ap.add_argument("--build-id", default="", help="идентификатор сборки (по умолчанию дата+время)")
    ap.add_argument("--skip-build", action="store_true",
                    help="не компилировать, упаковать уже готовый build_*/")
    ap.add_argument("--no-zip", action="store_true", help="не создавать .zip")
    ap.add_argument("--allow-nonwindows", action="store_true",
                    help="разрешить запуск не под Windows (проверка логики)")
    ap.add_argument("--require-vendor-key", action="store_true", default=True,
                    help="падать, если нет ключей вендора (по умолчанию включено)")
    args = ap.parse_args(argv)

    if args.engine == "pyinstaller":
        log("⚠ pyinstaller: внутри поставки остаётся .pyc-архив. Его можно распаковать\n"
            "  и декомпилировать, то есть покупатель получит читаемый код FLUX.\n"
            "  Для продажи используй --engine nuitka.")

    t0 = time.time()
    build_id = args.build_id or time.strftime("%Y%m%d-%H%M%S")
    info = preflight(args)

    outdir = args.outdir or os.path.join(RELEASE, f"FLUX-{ver}-{args.edition}-win-x64")
    os.makedirs(RELEASE, exist_ok=True)

    bak = backup_profile()
    try:
        write_profile(info["server"], args.engine, args.edition, build_id, info["fp"])

        if args.skip_build:
            step("Пропуск компиляции (--skip-build)")
            base = os.path.join(ROOT, "build_nuitka" if args.engine == "nuitka" else "build_pyi")
            dists = [os.path.join(base, d) for d in sorted(os.listdir(base))
                     if d.endswith(".dist")] if os.path.isdir(base) else []
            if args.engine == "pyinstaller":
                d2 = os.path.join(ROOT, "build_pyi", "dist")
                dists = [os.path.join(d2, x) for x in sorted(os.listdir(d2))] if os.path.isdir(d2) else []
            if not dists:
                die(f"нет готовых сборок в {base}")
        elif args.engine == "nuitka":
            dists = build_nuitka(args.console_exe)
        else:
            dists = build_pyinstaller(args.console_exe)

        collect_release(dists, outdir, args, ver, build_id)
        write_checksums(outdir)
        sign_exes(outdir, args)

        step("Проверка поставки на утечки")
        leaks = scan_leaks(outdir)
        if leaks:
            for x in leaks[:40]:
                log("  ! " + x)
            die(f"в поставке {len(leaks)} запрещённых файлов — такое отдавать покупателю НЕЛЬЗЯ.\n"
                "       Список выше. Чаще всего это значит, что Nuitka/PyInstaller подтянул\n"
                "       каталог исходников; пересобери с --engine nuitka.")
        log("✓ исходников (.py/.pyc) в поставке нет")
        log("✓ приватных ключей, базы лицензий и токенов админки нет")

        if not args.no_zip:
            make_zip(outdir, ver, args.edition)
    finally:
        restore_profile(bak)

    step("Готово")
    log(f"каталог: {outdir}")
    log(f"время:   {time.time() - t0:.0f} с")
    log("")
    log("Что отдать покупателю:")
    log(f"  {os.path.basename(outdir)}.zip  (или весь каталог)")
    log("Покупатель: Установка.bat -> вставил ключ -> работает. Python не нужен.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
