#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Подпись Authenticode для сборок FLUX 2.0.

ЧЕСТНО О ГЛАВНОМ. Я не могу выдать тебе цифровую подпись — сертификат кодевой
подписи покупается у удостоверяющего центра (DigiCert, Sectigo/SSL.com, GlobalSign,
Certum). С июня 2023 требования CA/B Forum обязывают хранить приватный ключ
Authenticode на аппаратном токене или в HSM, поэтому «просто сгенерировать .pfx»
больше нельзя даже для OV-сертификатов. Этот скрипт — пайплайн: сертификат
подключаешь свой, дальше всё автоматом.

Самоподписанный сертификат использовать НЕ стоит: SmartScreen ругается на него
сильнее, чем на неподписанный файл, а некоторые АВ добавляют самоподпись в
эвристики как отдельный подозрительный признак.

Что делает скрипт:
  * находит signtool (Windows SDK) или osslsigncode (кроссплатформенно);
  * подписывает SHA256 + ставит доверенную метку времени (timestamp) — без неё
    подпись перестанет проверяться после истечения срока сертификата;
  * при повторной подписи использует /as (append), чтобы не сломать существующую;
  * проверяет результат и печатает цепочку доверия;
  * считает и печатает sha256 файлов — их стоит опубликовать на странице продукта
    и приложить к заявке на разбор ложного срабатывания.

Использование:
  python packaging/sign.py -CertFile my.pfx -CertPass "..." -Targets dist/Flux/Flux.exe
  python packaging/sign.py -CertThumbprint 1A2B3C... -Targets dist/*.exe
  python packaging/sign.py -CertFile token.pfx -CertPass "..." -Targets a.exe b.exe ^
         -TimestampUrl http://timestamp.sectigo.com
  set FLUX_SIGN_DESCRIBE_URL=https://aerotitbit.com/flux   (страница продукта в подписи)
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
from typing import Optional

NT = sys.platform == "win32"
DEFAULT_TS = "http://timestamp.digicert.com"
PRODUCT_NAME = "FLUX 2.0 Desktop"
COMPANY = "aerotitbit"
PAGE_URL = os.environ.get("FLUX_SIGN_DESCRIBE_URL", "https://github.com/aerotitdi/flux-ai")


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def find_signtool() -> Optional[str]:
    """signtool из Windows SDK: берём самую свежую версию."""
    exe = shutil.which("signtool")
    if exe:
        return exe
    roots = [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
             os.environ.get("ProgramFiles", r"C:\Program Files")]
    best: tuple[str, str] = ("", "")
    for root in roots:
        base = os.path.join(root, "Windows Kits", "10", "bin")
        if not os.path.isdir(base):
            continue
        for ver in sorted(os.listdir(base), reverse=True):
            for arch in ("x64", "x86"):
                cand = os.path.join(base, ver, arch, "signtool.exe")
                if os.path.exists(cand) and ver > best[0]:
                    best = (ver, cand)
    return best[1] or None


def find_osslsigncode() -> Optional[str]:
    return shutil.which("osslsigncode")


def run(argv: list[str], timeout: int = 300) -> tuple[int, str]:
    kw: dict = {}
    if NT:
        # дочерние процессы скрыто: не мелькаем окном консоли при сборке
        kw["creationflags"] = 0x08000000
    p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, **kw)
    return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()


def sign_with_signtool(signtool: str, target: str, args: argparse.Namespace) -> bool:
    argv = [signtool, "sign", "/fd", "SHA256", "/tr", args.TimestampUrl, "/td", "SHA256",
            "/d", PRODUCT_NAME, "/du", PAGE_URL]
    if args.CertThumbprint:
        argv += ["/sha1", args.CertThumbprint]
    else:
        argv += ["/f", args.CertFile]
        if args.CertPass:
            argv += ["/p", args.CertPass]
    argv += ["/as"] if args.Append else []
    argv += [target]
    rc, out = run(argv)
    if rc != 0 and not args.Append:
        # /as падает, если файл ещё не подписан — пробуем без него
        argv2 = [a for a in argv if a != "/as"]
        rc, out = run(argv2)
    print(f"  {'OK ' if rc == 0 else 'FAIL'} signtool: {os.path.basename(target)}")
    if out:
        for line in out.splitlines()[-6:]:
            print("      " + line)
    return rc == 0


def sign_with_ossl(tool: str, target: str, args: argparse.Namespace) -> bool:
    signed = target + ".signed"
    argv = [tool, "sign", "-pkcs12", args.CertFile, "-pass", args.CertPass or "",
            "-h", "sha256", "-t", args.TimestampUrl,
            "-n", PRODUCT_NAME, "-i", PAGE_URL,
            "-in", target, "-out", signed]
    rc, out = run(argv)
    if rc == 0 and os.path.exists(signed):
        os.replace(signed, target)
    print(f"  {'OK ' if rc == 0 else 'FAIL'} osslsigncode: {os.path.basename(target)}")
    if out:
        for line in out.splitlines()[-6:]:
            print("      " + line)
    return rc == 0


def verify(target: str) -> None:
    """Показать, чем подписан файл (Get-AuthenticodeSignature / osslsigncode verify)."""
    if NT:
        ps = (f"(Get-AuthenticodeSignature -LiteralPath '{target}').Status; "
              f"(Get-AuthenticodeSignature -LiteralPath '{target}').SignerCertificate.Subject")
        rc, out = run([os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                                    "System32", "WindowsPowerShell", "v1.0", "powershell.exe"),
                       "-NoProfile", "-NonInteractive", "-Command", ps])
        if rc == 0 and out:
            print(f"      проверка: {' | '.join(out.splitlines()[:2])}")
    else:
        tool = find_osslsigncode()
        if tool:
            rc, out = run([tool, "verify", "-in", target])
            if out:
                print("      " + out.splitlines()[-1][:200])


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-CertFile", "--cert-file", dest="CertFile", default="",
                    help="файл .pfx/.p12 с сертификатом кодевой подписи")
    ap.add_argument("-CertPass", "--cert-pass", dest="CertPass", default="",
                    help="пароль к .pfx")
    ap.add_argument("-CertThumbprint", "--cert-thumbprint", dest="CertThumbprint", default="",
                    help="отпечаток сертификата в хранилище Windows (для токена/HSM)")
    ap.add_argument("-Targets", "--targets", dest="Targets", nargs="+", required=True,
                    help="файлы для подписи")
    ap.add_argument("-TimestampUrl", "--timestamp-url", dest="TimestampUrl", default=DEFAULT_TS,
                    help=f"сервер меток времени (по умолчанию {DEFAULT_TS})")
    ap.add_argument("-Append", "--append", dest="Append", action="store_true",
                    help="добавить подпись к уже имеющейся")
    ap.add_argument("-HashesOnly", "--hashes-only", dest="HashesOnly", action="store_true",
                    help="только посчитать sha256 (для публикации и заявок в АВ)")
    args = ap.parse_args(argv)

    targets = []
    for t in args.Targets:
        if any(ch in t for ch in "*?") and hasattr(os, "glob"):
            import glob
            targets.extend(sorted(glob.glob(t, recursive=True)))
        else:
            targets.append(t)
    targets = [t for t in targets if t and os.path.exists(t)]
    if not targets:
        print("нечего подписывать: файлы не найдены")
        return 1

    if args.HashesOnly:
        print("sha256 (публикуй на странице продукта и прикладывай к заявкам в АВ):")
        for t in targets:
            print(f"  {sha256(t)}  {os.path.basename(t)}")
        return 0

    if not args.CertFile and not args.CertThumbprint:
        print("ОШИБКА: нужен -CertFile <pfx> [-CertPass ...] или -CertThumbprint <отпечаток>")
        print()
        print("Где взять сертификат кодевой подписи:")
        print("  DigiCert / Sectigo (SSL.com) / GlobalSign — OV или EV Authenticode;")
        print("  Certum (Asseco) — самый доступный вариант для физлиц и ИП.")
        print("  С 2023 приватный ключ обязан быть на токене/HSM: после покупки")
        print("  подпись делается либо их утилитой, либо signtool с -CertThumbprint")
        print("  (сертификат импортируется в хранилище Windows вместе с ключом на токене).")
        return 2
    if args.CertFile and not os.path.exists(args.CertFile):
        print(f"ОШИБКА: нет файла сертификата {args.CertFile}")
        return 2

    tool = "signtool"
    signtool = find_signtool()
    ossl = find_osslsigncode()
    if not signtool:
        if ossl:
            tool = "osslsigncode"
        else:
            print("ОШИБКА: не найден ни signtool (Windows SDK), ни osslsigncode.")
            print("  Windows: поставь Windows SDK (компонент 'Windows SDK Signing Tools')")
            print("  Linux/macOS: brew install osslsigncode  |  apt install osslsigncode")
            return 3
    print(f"Инструмент подписи: {tool} · метка времени: {args.TimestampUrl}")
    print(f"Описание: «{PRODUCT_NAME}» · страница: {PAGE_URL}")
    print(f"Разработчик: {COMPANY}")
    print()

    failed = []
    for t in targets:
        ok = (sign_with_signtool(signtool, t, args) if tool == "signtool"
              else sign_with_ossl(ossl, t, args))
        if ok:
            verify(t)
            print(f"      sha256: {sha256(t)}")
        else:
            failed.append(t)

    print()
    if failed:
        print(f"НЕ подписано: {len(failed)} из {len(targets)}")
        for f in failed:
            print("  -", f)
        print()
        print("Что ещё снижает ложные срабатывания (помимо подписи):")
        print("  1. собирать через Nuitka, а не PyInstaller onefile (packaging/build_nuitka.bat);")
        print("  2. НЕ паковать UPX — это флаг пакера у всех эвристик;")
        print("  3. держать стабильные имена файлов и каталогов между версиями;")
        print("  4. опубликовать sha256 релиза и URL продукта;")
        print("  5. при срабатывании подать заявку вендору: Microsoft (wdcserv),")
        print("     Kaspersky, ESET, Dr.Web — с sha256 и ссылкой на продукт;")
        print("  6. EV-сертификат снимает предупреждение SmartScreen сразу,")
        print("     OV — только после накопления репутации (обычно дни-недели).")
        return 1
    print(f"Подписано файлов: {len(targets)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
