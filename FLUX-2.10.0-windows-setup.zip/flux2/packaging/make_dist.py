#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка релизного архива FLUX 2.0.

Делает zip, который можно отдать пользователю: внутри приложение, `.bat`-инсталлер
и всё нужное для установки — и НИЧЕГО из того, что давать нельзя.

ЧТО ВЫРЕЗАЕТСЯ (проверяется повторно после упаковки, не только фильтром):
  * license_server/keys/  — приватный ключ вендора и токен админки. Утечка = любой
    может напечатать себе лицензию. Прежний install.ps1 копировал каталог ЦЕЛИКОМ
    (robocopy /E) и утаскивал ключ вместе с приложением.
  * license_server/data/  — база лицензий (в ней хеши ключей и HWID клиентов);
  * всё остальное от license_server/ остаётся в репозитории, но в клиентский архив
    не кладётся: клиенту сервер лицензий не нужен, он ходит к нему по HTTP;
  * .git, тесты, node_modules, кэши, сборки, данные пользователя;
  * любые *.pem/*.p12/*.pfx/*.key, config.json, data/license.json.

Про ОБФУСКАЦИЮ (пункт 7 ТЗ). В архив кладётся читаемый исходник, и это сознательно:
обфускация байткода НЕ защищает от копирования (снимается за минуты теми же
pyinstxtractor + decompyle3), зато стабильно провоцирует ложные срабатывания АВ —
то есть решает задачу «защитить IP» плохо, а задачу «не ловить предупреждения»
ломает. Реальная защита от копирования — компиляция в нативный код:
    packaging/build_nuitka.bat
После неё в поставке нет ни .py, ни .pyc: есть скомпилированный exe. Если тебе
нужен именно архив с обфусцированным исходником (например, для внутреннего
распространения без сборки) — скажи, добавлю режим `--obfuscate` на pyarmor/pyminifier
с явным предупреждением о росте FP.

ВНИМАНИЕ: этот скрипт собирает архив с ИСХОДНЫМ КОДОМ и нужен только самому
разработчику (перенос кода, бэкап, ревью). Покупателю такой архив отдавать
НЕЛЬЗЯ: вместе с app/licensing.py он получает возможность вырезать проверку
ключа. Поставка покупателю собирается packaging/build_release.py (нативный exe).
Без явного подтверждения (--i-am-developer или FLUX_I_UNDERSTAND_SOURCE_ARCHIVE=1)
скрипт отказывается работать.

Запуск:
  python packaging/make_dist.py --i-am-developer                  # архив с исходниками
  python packaging/make_dist.py --i-am-developer --with-license-server
  python packaging/make_dist.py --i-am-developer --outdir /tmp/dist
  python packaging/build_release.py --server https://lic.example.com   # <- ДЛЯ ПРОДАЖИ
"""
from __future__ import annotations

import argparse
import fnmatch
import os
import re
import sys
import time
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

EXCLUDE_DIRS = {
    ".git", ".github", ".idea", ".vscode", "__pycache__", "node_modules",
    ".venv", "venv", "dist", "build", "release", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", "data", "logs",
    # артефакты packaging/build_release.py и локальных сборок exe
    "build_nuitka", "build_pyi", "main.build", "main.dist",
    # артефакты Cloudflare Workers: .wrangler хранит локальную копию базы D1
    # (в ней хеши ключей и HWID покупателей)
    ".wrangler",
    "license_server/keys", "license_server/data", "license_server/__pycache__",
    "tests/jsdom/node_modules", "tests/__pycache__", "tests/jsdom/__pycache__",
    "app/__pycache__", "app/tools/__pycache__",
}
EXCLUDE_FILES = {
    ".DS_Store", "Thumbs.db", "desktop.ini", ".gitignore", ".gitattributes",
    "package-lock.json", "make_dist.py.orig",
}
EXCLUDE_PATTERNS = (
    "*.pyc", "*.pyo", "*.pyd", "*.pem", "*.p12", "*.pfx", "*.key", "*.crt",
    "*.log", "*.tmp", "*.bak", "*.orig", "*.orig-encoding",
    "config.json", "license.json", "activation.key", "admin_token.txt",
    # резервная копия исходного профиля сборки, которую создаёт build_release.py
    "_build_profile.py.source-backup",
    # локальные секреты для `wrangler dev`: внутри VENDOR_PRIVATE_KEY_PEM.
    # Упаковать их в архив — значит отдать приватный ключ вендора, которым
    # подписываются лицензии: после этого любой может напечатать себе ключ.
    ".dev.vars", ".dev.vars.*", ".env", ".env.*",
    "*.sqlite", "*.sqlite3", "*.db", "*.db-wal", "*.db-shm",
    "timers.json", "memory.json", "guard_audit.jsonl", "guard_policy_backup.json",
    "guard_autostart_backup.json", "*.wav", "*.quarantined",
)
# каталоги, которые не нужны КОНЕЧНОМУ пользователю (но нужны разработчику)
DEV_ONLY_DIRS = {"tests", "docs"}

# Регулярка, а не просто подстрока: флаг ставим только на НАСТОЯЩЕМ PEM-блоке —
# заголовок, минимум две строки base64 по 40+ символов и закрывающий заголовок.
# Иначе сканер блокировал сборку на документации, где маркер упомянут текстом
# (что он успешно и сделал на первом прогоне — значит работает, но целиться надо точнее).
_PEM_BLOCK = re.compile(
    rb"-{5}\s*BEGIN [A-Z ]*PRIVATE KEY\s*-{5}\s*\n"
    rb"(?:[A-Za-z0-9+/=\s]{40,}?\n)+"
    rb"\s*-{5}\s*END [A-Z ]*PRIVATE KEY\s*-{5}"
)
_DANGER_EXT = (".pem", ".p12", ".pfx", ".key", ".p8")


def _norm(p: str) -> str:
    return p.replace("\\", "/")


def is_excluded(rel: str, dev: bool = True) -> bool:
    rel = _norm(rel)
    parts = rel.split("/")
    for i in range(len(parts)):
        sub = "/".join(parts[: i + 1])
        if parts[i] in EXCLUDE_DIRS or sub in EXCLUDE_DIRS:
            return True
    if not dev:
        for i in range(len(parts)):
            if parts[i] in DEV_ONLY_DIRS:
                return True
    base = parts[-1]
    if base in EXCLUDE_FILES:
        return True
    return any(fnmatch.fnmatch(base.lower(), pat.lower()) for pat in EXCLUDE_PATTERNS)


def collect(dev: bool, with_license_server: bool) -> list[str]:
    out = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames
                       if not is_excluded(os.path.relpath(os.path.join(dirpath, d), ROOT), dev)]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, ROOT)
            if is_excluded(rel, dev):
                # .gitignore в dev-архив кладём НАРОЧНО: он не даёт случайно
                # закоммитить deploy/.dev.vars (внутри VENDOR_PRIVATE_KEY_PEM) и
                # license_server/keys/. Для клиентской поставки он бесполезен.
                if dev and _norm(rel) == ".gitignore":
                    out.append(rel)
                continue
            if not with_license_server and _norm(rel).startswith("license_server/"):
                continue
            out.append(rel)
    return sorted(out)


def scan_secrets(files: list[str]) -> list[str]:
    """Проверка содержимого: приватных ключей в архиве быть не должно."""
    bad = []
    for rel in files:
        full = os.path.join(ROOT, rel)
        if not os.path.isfile(full):
            continue
        try:
            if os.path.getsize(full) > 8 * 1024 * 1024:
                continue
            with open(full, "rb") as f:
                blob = f.read()
        except OSError:
            continue
        self_ok = _norm(rel) in ("packaging/make_dist.py", "packaging/sign.py",
                                 "license_server/crypto.py", "license_server/keys.py",
                                 "tests/test_licensing.py")
        low = _norm(rel).lower()
        m = _PEM_BLOCK.search(blob)
        if m and not self_ok:
            head = m.group(0)[:60].decode(errors="replace").replace("\n", " ")
            if "PRIVATE KEY" in head.upper():
                bad.append(f"{rel}: най PEM-блок приватного ключа ({head}…)")
        if low.endswith(_DANGER_EXT):
            bad.append(f"{rel}: файл сертификата/ключа в списке на упаковку")
        if b"Proc-Type: 4,ENCRYPTED" in blob and not self_ok:
            bad.append(f"{rel}: зашифрованный ключ (Proc-Type: 4,ENCRYPTED)")
    return bad


def version() -> str:
    try:
        from app import __version__
        return __version__
    except Exception:
        m = re.search(r'__version__\s*=\s*"([^"]+)"',
                      open(os.path.join(ROOT, "app", "__init__.py"), encoding="utf-8").read())
        return m.group(1) if m else "0.0.0"


def manifest_text(files: list[str], ver: str) -> str:
    lines = [f"FLUX {ver} — содержимое архива", f"собрано: {time.strftime('%Y-%m-%d %H:%M:%S')}",
             f"файлов: {len(files)}", "-" * 60]
    total = 0
    for rel in files:
        p = os.path.join(ROOT, rel)
        try:
            sz = os.path.getsize(p)
        except OSError:
            sz = 0
        total += sz
        lines.append(f"{sz:>9,}  {rel}")
    lines.append("-" * 60)
    lines.append(f"{total:>9,}  ВСЕГО ({total / 1048576:.1f} МБ)")
    return "\n".join(lines) + "\n"


README_DIST = """FLUX {ver} — установка (Windows 10/11 x64)
================================================================

1) Установи Python 3.10+ с python.org (при установке отметь «Add python.exe to PATH»).

2) Запусти инсталлер двойным щелчком:

       installer\\Flux2-Installer.bat

   или с параметрами:

       installer\\Flux2-Installer.bat -InstallDir D:\\flux2 -Autostart
       installer\\Flux2-Installer.bat -Engine nuitka          (компиляция в нативный exe)
       installer\\Flux2-Installer.bat -SkipExe                (быстро, без сборки exe)
       installer\\Flux2-Installer.bat -LicenseKey FLX2-XXXXX-XXXXX-XXXXX-XXXXX ^
                                    -LicenseServer https://lic.example.com

3) Инсталлер:
   - копирует приложение в %LOCALAPPDATA%\\Flux2 (или в -InstallDir);
   - создаёт изолированный .venv и ставит зависимости;
   - собирает Flux.exe (окно) и FluxConsole.exe (терминал);
   - вешает ярлыки «FLUX 2.0» и «FLUX 2.0 Console» на рабочий стол;
   - прогоняет самотест.

4) Первый запуск: ярлык «FLUX 2.0» -> окно активации -> введи лицензионный ключ
   -> затем шестерёнка -> Подключения -> «+ Добавить соединение» (API-ключ провайдера).

Если Windows SmartScreen показывает «Windows защитила ваш ПК»
----------------------------------------------------------------
Это штатная реакция на неподписанное приложение, а не признак вируса:
   «Подробнее» -> «Выполнить в любом случае».
Чтобы предупреждения не было вовсе, сборку нужно подписать сертификатом
кодевой подписи (см. packaging/sign.py) и собирать через Nuitka
(packaging/build_nuitka.bat) — это два самых действенных способа.

Если антивирус всё же ругается
----------------------------------------------------------------
Сообщи разработчику и подай заявку на разбор вендору АВ, приложив sha256 файла:
   python packaging\\sign.py -HashesOnly -Targets dist\\Flux\\Flux.exe
Microsoft: https://www.microsoft.com/wdsi/filesubmission
Kaspersky: https://opentip.kaspersky.com
ESET:      https://phishing.eset.com/report

Быстрый запуск без установки (для разработчика)
----------------------------------------------------------------
   pip install -r requirements.txt
   python main.py            # окно чата
   python main.py --console  # терминальный чат
   python main.py --selftest # отчёт: инструменты, таймеры, звук, лицензия

Удаление
----------------------------------------------------------------
   powershell -ExecutionPolicy Bypass -File installer\\uninstall.ps1
"""


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--outdir", default=os.path.join(ROOT, "release"))
    ap.add_argument("--name", default="")
    ap.add_argument("--with-license-server", action="store_true",
                    help="включить сервер лицензий (БЕЗ каталога keys/) — для твоей машины, "
                         "не для конечного пользователя")
    ap.add_argument("--with-dev", action="store_true",
                    help="включить tests/ и docs/ (архив для разработки)")
    ap.add_argument("--no-readme", action="store_true")
    ap.add_argument("--i-am-developer", action="store_true",
                    help="подтвердить, что архив с ИСХОДНИКАМИ нужен тебе самому, "
                         "а не покупателю (иначе скрипт отказывается работать)")
    args = ap.parse_args(argv)

    # флаг из CLI эквивалентен переменной окружения — проверяем до основного guard'а
    if args.i_am_developer:
        os.environ["FLUX_I_UNDERSTAND_SOURCE_ARCHIVE"] = "1"

    ver = version()

    # ========================================================================
    # ЭТОТ СКРИПТ СОБИРАЕТ АРХИВ С ИСХОДНИКАМИ. Он существует только для
    # разработчика: перенести код на другую машину, отдать на ревью, сделать
    # бэкап. Покупателю такой архив отдавать НЕЛЬЗЯ — в нём лежит
    # app/licensing.py, а значит проверка лицензии вырезается за пять минут,
    # и вся схема ключей перестаёт что-либо защищать.
    #
    # Поставка покупателю собирается ДРУГИМ скриптом:
    #     python packaging/build_release.py --server https://lic.example.com
    # Он компилирует приложение в нативный exe (Nuitka), зашивает адрес сервера
    # лицензий и принудительно проверяет, что в результат не попал ни один .py.
    #
    # Подтверждение ниже намеренно неудобное: этот скрипт слишком легко запустить
    # «как раньше» и случайно опубликовать исходники в репозитории.
    # ========================================================================
    if not os.environ.get("FLUX_I_UNDERSTAND_SOURCE_ARCHIVE"):
        print(__doc__.split("\n")[0])
        print()
        print("СТОП. make_dist.py собирает архив с ИСХОДНЫМ КОДОМ (.py).")
        print()
        print("  Покупателю его отдавать нельзя: вместе с app/licensing.py он")
        print("  получает возможность вырезать проверку ключа и пользоваться")
        print("  FLUX бесплатно навсегда.")
        print()
        print("  Для поставки покупателю используй:")
        print("      python packaging/build_release.py --server https://lic.example.com")
        print()
        print("  Если тебе ДЕЙСТВИТЕЛЬНО нужен архив с исходниками (перенос кода,")
        print("  бэкап, ревью) — подтверди намерение одним из способов:")
        print("      python packaging/make_dist.py --i-am-developer ...")
        print("      set FLUX_I_UNDERSTAND_SOURCE_ARCHIVE=1   (Windows)")
        print("      FLUX_I_UNDERSTAND_SOURCE_ARCHIVE=1 python packaging/make_dist.py")
        if "--i-am-developer" not in (argv or sys.argv):
            return 3
        print()
        print("  подтверждено флагом --i-am-developer, собираю архив с исходниками…")

    if not args.with_license_server:
        print()
        print("  ⚠ license_server/ в архив НЕ включён — это клиентская поставка.")
        print("    Сервер лицензий теперь живёт на Cloudflare Workers (deploy/),")
        print("    а не в этом архиве. Для полной копии разработчика добавь")
        print("    --with-license-server.")
    dev = bool(args.with_dev)
    files = collect(dev, args.with_license_server)
    if not files:
        print("нечего упаковывать — каталог пуст?")
        return 1

    print(f"FLUX {ver}: готовлю архив ({len(files)} файлов)")
    secrets = scan_secrets(files)
    if secrets:
        print("\nСТОП. В список на упаковку попали секреты:")
        for s in secrets:
            print("  -", s)
        print("\nУбери их из репозитория и повтори. Архив НЕ создан.")
        return 2
    print("  проверка на утечку ключей/сертификатов: чисто")

    leak_dirs = [f for f in files if _norm(f).startswith("license_server/keys/")]
    if leak_dirs:
        print("\nСТОП. В архив попал каталог ключей вендора:", leak_dirs)
        return 2
    if not args.with_license_server:
        ls = [f for f in files if _norm(f).startswith("license_server/")]
        print(f"  license_server/ в клиентский архив не включён ({len(ls)} файлов пропущено)")
    else:
        print("  license_server/ включён (ключи и база исключены)")

    os.makedirs(args.outdir, exist_ok=True)
    name = args.name or f"FLUX-{ver}-windows-setup.zip"
    out = os.path.join(args.outdir, name)
    tmp = out + ".tmp"

    if not args.no_readme:
        # УСТАНОВКА.txt ведётся ВРУЧНУЮ в репозитории (там описание обоих сценариев:
        # готовая сборка и исходники). Прежний код перезаписывал его шаблоном
        # README_DIST и удалял после упаковки — то есть портил источник.
        # Теперь: файл из репозитория кладётся как есть, а README_DIST используется
        # только как запасной вариант, если файла вдруг нет.
        readme = os.path.join(ROOT, "УСТАНОВКА.txt")
        files = sorted(set(files) | {"УСТАНОВКА.txt"})
        readme_is_temp = False
        if not os.path.exists(readme):
            with open(readme, "w", encoding="utf-8") as f:
                f.write(README_DIST.format(ver=ver))
            readme_is_temp = True

    # MANIFEST.txt в репозитории — артефакт прошлой сборки. Если положить и его,
    # и свежий writestr(), в zip окажется два файла с одним именем (zipfile на это
    # ругается Duplicate name, а распаковщик возьмёт непредсказуемый из двух).
    files = [f for f in files if _norm(f) != "MANIFEST.txt"]

    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in files:
            full = os.path.join(ROOT, rel)
            if not os.path.isfile(full):
                continue
            z.write(full, arcname=f"flux2/{_norm(rel)}")
        z.writestr("flux2/MANIFEST.txt", manifest_text(files, ver))
    os.replace(tmp, out)

    # удаляем только тот УСТАНОВКА.txt, который создали сами как запасной
    if not args.no_readme and readme_is_temp:
        try:
            os.remove(os.path.join(ROOT, "УСТАНОВКА.txt"))
        except OSError:
            pass

    size = os.path.getsize(out)
    print(f"\nготово: {out}")
    print(f"размер: {size / 1048576:.2f} МБ · файлов: {len(files)}")
    import hashlib
    with open(out, "rb") as f:
        print("sha256: " + hashlib.sha256(f.read()).hexdigest())
    print("\nУстановка: распаковать и запустить flux2\\installer\\Flux2-Installer.bat")
    return 0


if __name__ == "__main__":
    sys.exit(main())
