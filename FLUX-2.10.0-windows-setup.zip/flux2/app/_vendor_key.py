"""Публичный ключ вендора FLUX. СГЕНЕРИРОВАН АВТОМАТИЧЕСКИ — не правь руками.

Источник: license_server/keys.py (команда `python -m license_server.keygen init`).
Этим ключом клиент проверяет подписи билетов активации (app/licensing.py).
Подделать билет, не имея приватного ключа вендора, нельзя; замена этого файла
своим ключом потребует пересборки приложения, а не правки конфига.
"""
VENDOR_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAEMjyB7zzZI6YqcG+7AUDESVxeP5aiuSMVXqH7ri/RRI=
-----END PUBLIC KEY-----"""

VENDOR_KEY_FINGERPRINT = "97AB364AB905"
GENERATED_AT = "2026-10-12 18:47:50"
