"""Клиент OpenAI-совместимых провайдеров (orcarouter, openrouter, openai, ollama...).

Фишки:
- streaming SSE + function calling;
- сквозные параметры (thinking / reasoning_effort / output_config);
- кастомные заголовки, передача cookie;
- АВТО-ПОДБОР ПУТИ API: если /chat/completions отдаёт 404 или HTML-страницу
  (веб-интерфейс роутера), пробуем /v1/chat/completions и наоборот;
  удачный путь запоминается в соединении (api_path).
"""
from __future__ import annotations

import json
from typing import Any, AsyncIterator, Optional

import aiohttp

from . import config

UA = "FluxDesktop/2.0"


class ProviderError(Exception):
    pass


def _headers(conn: dict, cookies: Optional[str] = None) -> dict:
    h = {"User-Agent": UA, "Content-Type": "application/json"}
    key = (conn.get("api_key") or "").strip()
    scheme = conn.get("auth") or "Bearer"
    if key and scheme == "Bearer":
        h["Authorization"] = f"Bearer {key}"
    elif key and scheme == "X-API-Key":
        h["X-API-Key"] = key
    elif key and scheme == "Basic":
        import base64
        h["Authorization"] = "Basic " + base64.b64encode(key.encode()).decode()
    extra = conn.get("headers") or {}
    if isinstance(extra, str):
        try:
            extra = json.loads(extra or "{}")
        except Exception:
            extra = {}
    for k, v in extra.items():
        h[str(k)] = str(v)
    if conn.get("forward_cookies") and cookies:
        h["Cookie"] = cookies
    return h


def _base(conn: dict) -> str:
    return (conn.get("base_url") or "").rstrip("/")


def _is_html(txt: str) -> bool:
    t = txt.lstrip()[:64].lower()
    return t.startswith("<!doctype") or t.startswith("<html")


def _path_candidates(base: str, saved: str, suffix: str) -> list[str]:
    cands = []
    if saved:
        cands.append(base + saved)
    cands.append(base + suffix)
    if base.endswith("/v1"):
        cands.append(base[:-3] + suffix)
    else:
        cands.append(base + "/v1" + suffix)
    out, seen = [], set()
    for c in cands:
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def think_extra(conn: dict, mode: str) -> dict:
    """Сквозные параметры раздумий: только то, что разрешено в соединении."""
    passthrough = [p.strip() for p in (conn.get("passthrough") or [])]
    extra: dict[str, Any] = {}
    if mode == "off":
        return extra
    budget = {"brief": 2048, "medium": 6144}.get(mode, 8192)
    effort = {"brief": "low", "medium": "medium"}.get(mode, "high")
    if "thinking" in passthrough:
        extra["thinking"] = {"type": "enabled", "budget_tokens": budget}
    if "reasoning_effort" in passthrough or not passthrough:
        extra["reasoning_effort"] = effort
    if "output_config" in passthrough:
        extra["output_config"] = {"effort": effort}
    return extra


def _remember_path(conn: dict, url: str) -> None:
    base = _base(conn)
    path = url[len(base):]
    if conn.get("api_path") != path:
        conn["api_path"] = path
        try:
            config.CONFIG.save()
        except Exception:
            pass


async def fetch_models(conn: dict, timeout: float = 20.0) -> list[str]:
    base = _base(conn)
    urls = _path_candidates(base, conn.get("api_path") or "", "/models")
    last = None
    async with aiohttp.ClientSession() as s:
        for url in urls:
            async with s.get(url, headers=_headers(conn), timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                txt = await r.text()
                if r.status != 200 or _is_html(txt):
                    last = ProviderError(f"GET {url} -> {r.status}" + (" (HTML веб-интерфейса)" if _is_html(txt) else ""))
                    continue
                data = json.loads(txt)
            _remember_path(conn, url.replace("/models", "/chat/completions"))
            items = data.get("data") if isinstance(data, dict) else data
            out = []
            for it in items or []:
                mid = it.get("id") if isinstance(it, dict) else str(it)
                if mid:
                    out.append((conn.get("id_prefix") or "") + mid)
            return sorted(out)
    raise last or ProviderError("нет доступного пути /models")


async def test_connection(conn: dict) -> dict:
    try:
        models = await fetch_models(conn)
        return {"ok": True, "models": models}
    except Exception as e:
        return {"ok": False, "error": str(e)}


class StreamEvent:
    """delta | tool_calls | done | error"""

    def __init__(self, kind: str, **kw):
        self.kind = kind
        self.__dict__.update(kw)


async def chat_stream(
    conn: dict,
    model: str,
    messages: list[dict],
    tools: Optional[list[dict]] = None,
    think_mode: str = "off",
    cookies: Optional[str] = None,
    temperature: float = 0.7,
) -> AsyncIterator[StreamEvent]:
    """Стримит события: delta(text), tool_calls(list), done(msg)."""
    body: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "stream": True,
        "temperature": temperature,
    }
    body.update(think_extra(conn, think_mode))
    if tools:
        body["tools"] = tools
        body["tool_choice"] = "auto"

    base = _base(conn)
    urls = _path_candidates(base, conn.get("api_path") or "", "/chat/completions")
    timeout = aiohttp.ClientTimeout(total=600, sock_read=180)
    last_err: Optional[ProviderError] = None

    async with aiohttp.ClientSession() as s:
        for url in urls:
            async with s.post(url, json=body, headers=_headers(conn, cookies), timeout=timeout) as r:
                if r.status != 200:
                    txt = (await r.text())[:600]
                    if r.status in (404, 405) or _is_html(txt):
                        hint = " (это HTML веб-интерфейса, а не API)" if _is_html(txt) else ""
                        last_err = ProviderError(f"HTTP {r.status} на {url}{hint} — пробую другой путь API")
                        continue
                    raise ProviderError(f"HTTP {r.status}: {txt}")
                _remember_path(conn, url)
                acc_text = ""
                tool_acc: dict[int, dict] = {}
                async for raw in r.content:
                    line = raw.decode("utf-8", "ignore").strip()
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if payload == "[DONE]":
                        break
                    try:
                        obj = json.loads(payload)
                    except Exception:
                        continue
                    ch = (obj.get("choices") or [{}])[0]
                    delta = ch.get("delta") or {}
                    if delta.get("content"):
                        acc_text += delta["content"]
                        yield StreamEvent("delta", text=delta["content"])
                    for tc in delta.get("tool_calls") or []:
                        idx = tc.get("index", 0)
                        slot = tool_acc.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                        if tc.get("id"):
                            slot["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name"):
                            slot["name"] += fn["name"]
                        if fn.get("arguments"):
                            slot["arguments"] += fn["arguments"]
                    if ch.get("finish_reason") in ("stop", "tool_calls", "length"):
                        break
            calls = []
            for idx in sorted(tool_acc):
                slot = tool_acc[idx]
                if not slot["name"]:
                    continue
                try:
                    args = json.loads(slot["arguments"] or "{}")
                except Exception:
                    args = {"_raw": slot["arguments"]}
                calls.append({"id": slot["id"] or f"call_{idx}", "name": slot["name"], "arguments": args})
            if calls:
                yield StreamEvent("tool_calls", calls=calls)
            yield StreamEvent("done", text=acc_text)
            return
    raise last_err or ProviderError(
        "API не найден ни по одному пути (/chat/completions, /v1/chat/completions). "
        "Проверь базовый адрес: для orcarouter обычно https://api.orcarouter.ai/v1")


async def chat_once(
    conn: dict,
    model: str,
    messages: list[dict],
    tools: Optional[list[dict]] = None,
    think_mode: str = "off",
    cookies: Optional[str] = None,
) -> dict:
    """Нестриминговый вызов: возвращает {text, tool_calls}."""
    text = ""
    calls = []
    async for ev in chat_stream(conn, model, messages, tools, think_mode, cookies):
        if ev.kind == "delta":
            text += ev.text
        elif ev.kind == "tool_calls":
            calls = ev.calls
    return {"text": text, "tool_calls": calls}
