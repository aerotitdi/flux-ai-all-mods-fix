"""Формат лицензионного ключа FLUX — ЕДИНСТВЕННЫЙ источник правды.

Живёт в `app/` (а не в `license_server/`) нарочно: этот пакет попадает в клиентскую
поставку, а `license_server` — нет. Клиент обязан уметь привести введённый ключ к
каноническому виду и объяснить опечатку, не имея доступа к серверному коду.
`license_server/crypto.py` импортирует функции отсюда, поэтому формат не может
«разъехаться» между клиентом и сервером.

Формат:  FLX2-XXXXX-XXXXX-XXXXX-XXXXX
  * алфавит — Crockford base32 без неоднозначных символов (0, 1, I, L, O, U);
  * 19 случайных символов + 1 контрольный (ловит опечатку при вводе);
  * ключ сам по себе ничего не доказывает клиенту — его проверяет сервер по
    sha256-хешу. Вытащить из exe «генератор ключей» нельзя: его там нет.
"""
from __future__ import annotations

import hashlib
import secrets
from typing import Optional

ALPHABET = "23456789ABCDEFGHJKMNPQRSTVWXYZ"      # 30 символов, без 0 1 I L O U
KEY_BODY_LEN = 20                                 # 19 случайных + 1 контрольный
KEY_PREFIX = "FLX2"
GROUP = 5

# символы, которые пользователь вводит по ошибке вместо допустимых
_LOOKALIKE = {"0": "O", "O": "O", "1": "I", "I": "I", "L": "L", "U": "V"}
# но O, I, L, U в алфавите нет — их мы не «чиним», а честно показываем как ошибку.
# Чиним только то, что однозначно отображается в допустимый символ:
_FIXABLE = {"0": "Q", "1": "I"}        # не используется: см. нормализацию ниже


def _check_char(body: str) -> str:
    """Контрольный символ: взвешенная сумма позиций по модулю размера алфавита."""
    total = 0
    for i, ch in enumerate(body):
        idx = ALPHABET.find(ch)
        if idx < 0:
            return "?"                  # мусор: контрольный символ заведомо не совпадёт
        total += (idx + 1) * (i + 3)
    return ALPHABET[total % len(ALPHABET)]


def make_key(prefix: str = KEY_PREFIX) -> str:
    """Сгенерировать новый ключ (используется только админ-утилитой)."""
    body = "".join(secrets.choice(ALPHABET) for _ in range(KEY_BODY_LEN - 1))
    body += _check_char(body)
    return prefix + "-" + "-".join(body[i:i + GROUP] for i in range(0, len(body), GROUP))


def strip_prefix(s: str) -> str:
    """Снять префикс и всё, что не является буквой/цифрой."""
    s = "".join(ch for ch in (s or "").strip().upper() if ch.isalnum())
    for pref in (KEY_PREFIX, "FLUX2", "FLUX", "FLX"):
        if s.startswith(pref):
            return s[len(pref):]
    return s


def normalize_key(raw: str) -> Optional[str]:
    """Привести введённое к каноническому виду или None, если это не наш ключ.

    Терпит: пробелы, дефисы, подчёркивания, строчные буквы, отсутствие/лишний
    префикс. Не пытается «угадывать» неоднозначные символы — их просто нет в
    алфавите, поэтому 0/1/I/L/O/U всегда ошибка, и мы о ней говорим.
    """
    if not raw:
        return None
    s = strip_prefix(raw)
    if len(s) != KEY_BODY_LEN:
        return None
    if any(ch not in ALPHABET for ch in s):
        return None
    if _check_char(s[:-1]) != s[-1]:
        return None
    return KEY_PREFIX + "-" + "-".join(s[i:i + GROUP] for i in range(0, len(s), GROUP))


def key_hint(raw: str) -> str:
    """Почему ключ не подошёл — чтобы пользователь не гадал.

    ВАЖНО: `str.isalnum()` в Python возвращает True и для кириллицы, поэтому
    фильтрация идёт по принадлежности алфавиту, а не по isalnum.
    """
    if not raw or not raw.strip():
        return "пусто"
    s = strip_prefix(raw)
    bad = sorted({ch for ch in s if ch not in ALPHABET})
    if bad:
        return ("недопустимые символы: " + " ".join(bad)
                + ". Алфавит ключа: " + ALPHABET + " (в нём нет 0 1 I L O U)")
    if len(s) != KEY_BODY_LEN:
        return (f"длина {len(s)}, нужно {KEY_BODY_LEN} символов. "
                f"Формат: FLX2-XXXXX-XXXXX-XXXXX-XXXXX")
    if _check_char(s[:-1]) != s[-1]:
        return ("опечатка: контрольный символ не сходится. Чаще всего путают "
                "8/B, Z/2, S/5, V/Y, Q/O — проверь группы заново")
    return "ключ выглядит корректно (проблема на стороне сервера или статуса лицензии)"


def key_hash(key: str) -> str:
    """Хеш ключа для хранения в БД: при утечке базы ключи не восстанавливаются."""
    return hashlib.sha256(("flux2::" + key).encode("utf-8")).hexdigest()


def key_id(key: str) -> str:
    """Короткий публичный идентификатор (логи, админка, тикеты)."""
    src = key.strip()
    if src.startswith("-----BEGIN"):          # передали PEM — считаем отпечаток от него
        return key_hash(src)[:12].upper()
    norm = normalize_key(src) or src
    return key_hash(norm)[:12].upper()


def mask_key(key: str) -> str:
    """FLX2-ABCDE-*****-*****-VWXYZ — для логов и интерфейса."""
    k = normalize_key(key) or (key or "")
    parts = k.split("-")
    if len(parts) != 5:
        return k[:4] + "…"
    return "-".join([parts[0], parts[1], "*****", "*****", parts[4]])


def looks_like_key(raw: str) -> bool:
    """Быстрая проверка «похоже ли на наш ключ» — для валидации форм."""
    return normalize_key(raw) is not None


# ============================================================ вставка из буфера
import re as _re

# Ключ в тексте письма/мессенджера: префикс (или без него) + 4 группы по 5 символов.
# Разделители между группами — любой не-буквенно-цифровой мусор (дефис, пробел,
# неразрывный пробел, «тире» из Word, перенос строки): покупатель копирует ключ
# целиком из письма, и требовать от него идеального форматирования — значит
# гарантировать лишние тикеты в поддержку.
_KEY_IN_TEXT = _re.compile(
    r"(?:FLX2|FLUX2|FLUX|FLX)?[\s\-_–—]*"
    r"([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})[\s\-_–—]*"
    r"([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})[\s\-_–—]*"
    r"([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})[\s\-_–—]*"
    r"([23456789ABCDEFGHJKMNPQRSTVWXYZ]{5})"
)


def extract_key(text: str) -> Optional[str]:
    """Достать ключ из ЛЮБОГО вставленного текста.

    Это то, что делает установку ключа «вставил и всё»: покупатель копирует не
    аккуратную строку, а кусок письма («Ваш ключ: FLX2-… , сохраните его»), и мы
    обязаны найти ключ сами. Возвращает канонический ключ или None.

    Перебираем ВСЕх кандидатов, а не первого: в письме может быть и номер заказа,
    похожий на ключ, и сам ключ. Берём первого кандидата, который проходит
    контроль по контрольному символу, — случайный мусор его не проходит.
    """
    if not text:
        return None
    up = text.upper()
    # сначала честная попытка: вдруг вставили ровно ключ
    direct = normalize_key(up)
    if direct:
        return direct
    for m in _KEY_IN_TEXT.finditer(up):
        cand = normalize_key("".join(m.groups()))
        if cand:
            return cand
    return None


def paste_hint(text: str) -> str:
    """Почему во вставленном тексте ключа нет — конкретная подсказка, а не «ошибка».

    ВАЖНО: `str.isalnum()` в Python возвращает True и для кириллицы, поэтому
    «не наши символы» определяются принадлежностью ALPHABET, а не isalnum.
    Иначе на вставленном русском тексте мы бы вывалили пользователю простыню
    из «недопустимых символов» А Б В Г…
    """
    if not text or not text.strip():
        return "Поле пустое. Скопируй ключ из письма и вставь сюда (Ctrl+V)."
    up = text.upper()

    # 1) вставили обычный текст, а не ключ — самая частая ошибка у покупателя
    cyr = sorted({ch for ch in up if "\u0400" <= ch <= "\u04FF"})
    if cyr:
        return ("Похоже, вставлен обычный текст, а не ключ (в нём есть русские буквы). "
                "Ключ выглядит как FLX2-XXXXX-XXXXX-XXXXX-XXXXX — скопируй только его.")

    body = "".join(ch for ch in strip_prefix(up) if ch in ALPHABET or ch.isdigit()
                   or ch.isalpha())
    # 2) символы, которых в алфавите ключа не бывает вовсе
    bad = sorted({ch for ch in body if ch not in ALPHABET})
    if bad:
        ambiguous = [ch for ch in bad if ch in "01ILOU"]
        if ambiguous:
            listed = ", ".join("«" + ch + "»" for ch in ambiguous)
            return (f"В ключе не бывает символа {listed}. Их нет в алфавите ключа, "
                    "чтобы исключить путаницу — скорее всего это опечатка или ключ "
                    "скопирован из PDF/скриншота с ошибкой распознавания. "
                    "Сверь группы заново.")
        return ("Недопустимые символы: " + " ".join("«" + b + "»" for b in bad[:8]) + ". "
                "Алфавит ключа: " + ALPHABET)

    # 3) длина: нашли тело ключа, но оно короче/длиннее нужного
    if len(body) > KEY_BODY_LEN:
        return (f"Похоже, скопировано лишнее ({len(body)} символов при нужных "
                f"{KEY_BODY_LEN}). Скопируй только сам ключ вида "
                f"FLX2-XXXXX-XXXXX-XXXXX-XXXXX.")
    if body:
        return (f"В ключе {len(body)} символов, нужно {KEY_BODY_LEN}: 4 группы по 5 "
                f"(FLX2-XXXXX-XXXXX-XXXXX-XXXXX). Возможно, часть не скопировалась.")

    # 4) латиница нужной длины, но контрольный символ не сходится
    if len(up) >= KEY_BODY_LEN:
        return ("Ключ не найден. Проверь, что копируешь именно ключ доступа FLUX, "
                "а не API-ключ провайдера или номер заказа.")
    return ("Не удалось найти ключ во вставленном тексте. Ключ выглядит как "
            "FLX2-XXXXX-XXXXX-XXXXX-XXXXX.")


# ============================================================ причины блокировки
# Три РАЗНЫХ повода заблокировать клиента. Хранятся в БД (licenses.revoke_kind)
# и доезжают до окна активации, чтобы пользователь видел не «что-то сломалось»,
# а конкретную причину. Тексты живут здесь, а не в UI, потому что их формирует
# сервер, а показывает клиент — и они обязаны совпадать.
RK_DELETED = "deleted"        # ключ УДАЛЁН навсегда (возврат, мошенничество, утечка)
RK_SUSPENDED = "suspended"    # отозван на неопределённое время (можно вернуть)
RK_REVOKED = "revoked"        # обычный отзыв (историческое значение, = suspended)

REVOKE_KINDS = (RK_DELETED, RK_SUSPENDED, RK_REVOKED)

# заголовок окна активации по типу блокировки
REVOKE_TITLE = {
    RK_DELETED: "Этот ключ доступа был удалён",
    RK_SUSPENDED: "Этот ключ доступа отозван на неопределённое время",
    RK_REVOKED: "Этот ключ доступа отозван",
}

# что написать, если админ не указал причину
REVOKE_DEFAULT_REASON = {
    RK_DELETED: "причина не указана разработчиком",
    RK_SUSPENDED: "ключ приостановлен до решения разработчика",
    RK_REVOKED: "причина не указана разработчиком",
}


def normalize_kind(kind: str) -> str:
    """Привести произвольное значение к одному из известных (или к suspended)."""
    k = (kind or "").strip().lower()
    if k in REVOKE_KINDS:
        return k
    # «delete»/«deleted»/«удалён» из старых баз и ручных вызовов API
    if k in ("delete", "del", "purged", "removed"):
        return RK_DELETED
    return RK_SUSPENDED


def revoke_title(kind: str) -> str:
    return REVOKE_TITLE.get(normalize_kind(kind), REVOKE_TITLE[RK_SUSPENDED])


def revoke_reason_text(kind: str, reason: str) -> str:
    """Причина для показа. Пустая причина — НЕ пустая строка, а внятный текст."""
    r = (reason or "").strip()
    if r:
        return r
    return REVOKE_DEFAULT_REASON.get(normalize_kind(kind), REVOKE_DEFAULT_REASON[RK_SUSPENDED])


def revoke_message(kind: str, reason: str = "", key_id: str = "") -> str:
    """Полный текст блокировки для окна активации и для логов.

    Формат — ровно тот, что просил заказчик:
      «Этот ключ доступа был удалён. Причина: возврат средств»
      «Этот ключ доступа отозван на неопределённое время»
    """
    kind = normalize_kind(kind)
    title = REVOKE_TITLE[kind]
    reason_txt = (reason or "").strip()
    if kind == RK_SUSPENDED and not reason_txt:
        # «на неопределённое время» сам по себе и есть причина — не дублируем
        return title
    if reason_txt:
        return f"{title}. Причина: {reason_txt}"
    return f"{title}. {REVOKE_DEFAULT_REASON[kind].capitalize()}."


def is_permanent(kind: str) -> bool:
    """Удалённый ключ вернуть нельзя (только выпустить новый); suspended — можно."""
    return normalize_kind(kind) == RK_DELETED
