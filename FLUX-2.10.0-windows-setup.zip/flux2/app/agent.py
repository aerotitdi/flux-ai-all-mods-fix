"""Агент: цикл чата с тулзами, think-auto, авто-поиском, авто-скиллами, стримингом."""
from __future__ import annotations

import asyncio
import json
import re
import time
from typing import Awaitable, Callable

from . import providers, skills, think, vision
from .config import CONFIG
from .timers import SCHED
from .tools import REG
from .tools import search as search_tools

SYSTEM_BASE = """Ты — FLUX 2.0, десктопный ИИ-ассистент с 300+ инструментами.
Правила:
- Отвечай на языке пользователя.
- Инструменты вызывай сам, когда нужны; не выдумывай результаты инструментов.
- Каталог инструментов выдаётся частично (релевантное запросу); если нужного нет — вызови agent_tools_search.
- Браузер: окна и вкладки раздельно (browser_tabs_list -> targetId -> действия с конкретной вкладкой).
- Компьютер (JARVIS): окна ОС, мышь, клавиатура, скриншот, OCR, процессы — тулзы os_*, mouse_*,
  keyboard_*, screen_screenshot, ocr_screen, proc_*, shell_run, app_launch, clipboard_get_set.
- Браузерные тулзы подключаются к ЖИВОМУ браузеру пользователя, НЕ закрывая его:
  порт 9222 или DevToolsActivePort (галка в chrome://inspect/#remote-debugging).
  Перезапуск Chrome (browser_restart_user) - ТОЛЬКО если пользователь сам попросил.
  Если подключиться нельзя - один раз предложи включить галку или browser_enable_debug_shortcut.
  НЕ объясняй внутренние механизмы тулзов (порты, HWND, заголовки) - просто делай и давай результат.
  «Сверни/закрой/разверни окно или браузер» = os_window_minimize / os_window_close /
  os_window_maximize / os_minimize_all. Это НЕ отказ: инструмент для сворачивания окон У ТЕБЯ ЕСТЬ.
- ЗРЕНИЕ: если инструмент вернул снимок, система приложит картинку отдельным сообщением
  СРАЗУ после ответов инструментов. Смотри на неё и действуй по факту, а не по догадке.
- БРАУЗЕР — ПОШАГОВО. Один тулз = один шаг. Не останавливайся на полпути:
  1) browser_page_snapshot -> получи НУМЕРОВАННУЮ карту кликабельных элементов;
  2) выбери индекс нужного элемента и жми browser_act(index=N) (или browser_act_text);
  3) после КАЖДОГО действия снова browser_page_snapshot — страница изменилась;
  4) повторяй, пока задача не выполнена, и только потом отвечай пользователю.
  Просьба «открой канал X и включи последнее видео» = минимум 3 шага:
  навигация -> снимок -> клик по первому видео в списке -> проверка, что плеер играет.
  «Поставь на паузу / переключи / убавь звук» = media_* (media_status сначала).
  НЕ сдавайся после первого шага и не отвечай «готово», пока не проверил снимком.
- Код: обязательно прогоняй через code_test с нужным движком, прежде чем показывать результат.
- Если в контексте есть блок ВЕБ-КОНТЕКСТ — используй его как свежие данные со ссылками.
- Если в контексте есть блок СКИЛЛ — следуй его инструкции.
- Память: важное о пользователе сохраняй mem_remember, вспоминай mem_recall.
- ТАЙМЕРЫ: просьбы «напомни/засеки/поставь таймер/через N минут/в HH:MM» = timer_set
  (параметр `when` принимает и «5 минут», и «1ч30м», и «14:30», и «завтра 9:00»,
  и «каждые 10 минут»). Повтор — timer_every. НЕ пытайся «подождать» сам и не вызывай
  sleep: планировщик сработает в фоне, проиграет звук и сам пришлёт тебе уведомление.
  После timer_set просто подтверди пользователю время срабатывания.
- ОЗВУЧКА (строго, побуквенно): НАЧАЛО маркера = два символа: звёздочка, затем дефис: `*-`
  КОНЕЦ маркера = два символа: дефис, затем звёздочка: `-*`
  ПРАВИЛЬНО (будет озвучено):   *-Привет, задача выполнена.*-
  НЕПРАВИЛЬНО (НЕ будет озвучено): *-Привет*-   (конец `*-` вместо `-*`)
  НЕПРАВИЛЬНО (НЕ будет озвучено): -*Привет-*   (начало `-*` вместо `*-`)
  Перед отправкой ответа проверь два последних символа голосовой строки: там обязаны быть `-*`.
  КАЖДЫЙ ответ ОБЯЗАН содержать голосовую разметку (1-2 фразы сути): ответ без разметки - брак.
  Озвучивается ТОЛЬКО текст внутри правильного маркера; если разметки нет вовсе,
  система озвучит первое предложение ответа вместо тебя - не доводи до этого.
  Голосом помечай суть в 1-2 фразы, остальное - только для чата.
"""

EventFn = Callable[[dict], Awaitable[None]]


async def _emit(fn: EventFn, kind: str, **kw):
    await fn({"type": kind, **kw})


async def run_turn(user_text: str, history: list, on_event: EventFn, cookies: str | None = None) -> str:
    t0 = time.time()
    conn = CONFIG.active_connection()
    if not conn:
        await _emit(on_event, "error", text="Нет подключения: добавь провайдер в настройках (шестерёнка -> Подключения).")
        return ""
    model = CONFIG.active_model()
    if not model:
        await _emit(on_event, "error", text="У подключения не выбрана модель.")
        return ""

    # --- think-auto + авто-поиск -------------------------------------------
    dec = think.decide(user_text, len(history))
    await _emit(on_event, "think", mode=dec.mode, search=dec.search, why=dec.why)

    sys_parts = [SYSTEM_BASE]

    # сработавшие таймеры (берём из очереди планировщика — она наполняется фоном,
    # даже если пользователь молчал всё это время; звук и тост уже отработали)
    fired = SCHED.unacked()
    if fired:
        lines = []
        for t in fired:
            when = time.strftime("%H:%M:%S", time.localtime(t.get("last_fired") or time.time()))
            lines.append(f"- «{t.get('label')}» в {when}"
                         + (f" (просрочен на {int(t['overdue'])} с)" if t.get("overdue") else "")
                         + (f" — повтор, срабатывание №{t.get('fired_count')}" if t.get("interval") else ""))
        sys_parts.append(
            "СРАБОТАВШИЕ ТАЙМЕРЫ (пользователь их ещё не видел в чате):\n" + "\n".join(lines) +
            "\nОБЯЗАТЕЛЬНО начни ответ с явного сообщения об этом таймере/таймерах "
            "(например: «⏰ Таймер «чайник» сработал»), затем отвечай на текущий вопрос.")

    # авто-поиск до ответа модели
    if dec.search and CONFIG.settings.get("search_engine", "off") != "off":
        try:
            items = await search_tools.run_engine(CONFIG.settings["search_engine"], user_text, 6)
            if items:
                block = "\n".join(f"- {i['title']} :: {i['url']}\n  {i['snippet'][:200]}" for i in items)
                sys_parts.append(f"ВЕБ-КОНТЕКСТ (движок {CONFIG.settings['search_engine']}, автоматически):\n{block}")
                await _emit(on_event, "search", engine=CONFIG.settings["search_engine"], n=len(items))
        except Exception as e:
            await _emit(on_event, "search", engine="error", n=0, error=str(e))

    # авто-скиллы
    if CONFIG.settings.get("skills_auto", True):
        try:
            matched = await skills.match_skills(user_text, k=2)
            for s in matched:
                sys_parts.append(f"СКИЛЛ [{s['name']}]:\n{s['body']}")
                await _emit(on_event, "skill", name=s["name"])
        except Exception:
            pass

    # режим раздумий в промпте
    if dec.mode == "brief":
        sys_parts.append("Режим раздумий: brief — проговори 2-4 шага плана, затем ответ.")
    elif dec.mode == "medium":
        sys_parts.append("Режим раздумий: средне-тяжёлый — составь план из 3-5 шагов, "
                         "проверь ключевые шаги (данные, код, источники), затем ответ.")
    elif dec.mode == "deep":
        sys_parts.append("Режим раздумий: deep — составь подробный план, проверь шаги, затем ответ.")
    else:
        sys_parts.append("Режим раздумий: off — отвечай сразу, без лишних рассуждений.")

    messages = [{"role": "system", "content": "\n\n".join(sys_parts)}]
    messages += [m for m in history[-24:]]
    messages.append({"role": "user", "content": user_text})

    ctx = {"history": history, "session_stats": {"tools": 0, "started": t0}}
    rounds = int(CONFIG.settings.get("max_tool_rounds", 8))
    final_text = ""
    use_vision = vision.vision_enabled(conn, model)
    ctx["vision"] = use_vision
    if use_vision:
        await _emit(on_event, "vision_state", on=True)

    try:
        for rnd in range(rounds):
            tool_specs = REG.search(user_text + " " + (final_text or ""), k=18)
            schemas = [sp.schema() for sp in tool_specs]
            assistant_text = ""
            pending_calls = []
            async def _pump():
                """Один проход по стриму: копим текст и tool_calls."""
                nonlocal assistant_text, pending_calls
                async for ev in providers.chat_stream(conn, model, messages, tools=schemas,
                                                      think_mode=dec.mode, cookies=cookies):
                    if ev.kind == "delta":
                        assistant_text += ev.text
                        await _emit(on_event, "token", text=ev.text)
                    elif ev.kind == "tool_calls":
                        pending_calls = ev.calls

            try:
                await _pump()
            except providers.ProviderError as pe:
                msg = str(pe).lower()
                blind = any(k in msg for k in ("image", "multimodal", "multi-modal", "vision",
                                               "content policy", "invalid_request", "400"))
                if not use_vision or not blind:
                    raise
                # провайдер не принимает картинки — выкидываем их и повторяем текстом
                use_vision = False
                ctx["vision"] = False
                messages = [m for m in messages
                            if not (isinstance(m.get("content"), list)
                                    and any(pt.get("type") == "image_url" for pt in m["content"]))]
                assistant_text, pending_calls = "", []
                await _emit(on_event, "vision_state", on=False,
                            reason="провайдер отверг изображения — продолжаю текстом")
                await _pump()
            if not pending_calls:
                final_text = assistant_text
                messages.append({"role": "assistant", "content": assistant_text})
                break
            messages.append({"role": "assistant", "content": assistant_text,
                             "tool_calls": [{"id": c["id"], "type": "function",
                                             "function": {"name": c["name"],
                                                          "arguments": json.dumps(c["arguments"], ensure_ascii=False)}}
                                            for c in pending_calls]})
            round_images: list[str] = []
            for call in pending_calls:
                await _emit(on_event, "tool_start", name=call["name"], args=call["arguments"])
                res = await REG.dispatch(call["name"], call["arguments"], ctx)
                ctx["session_stats"]["tools"] = ctx["session_stats"].get("tools", 0) + 1
                await _emit(on_event, "tool_end", name=call["name"], ok=res.ok,
                            preview=res.text[:300], images=res.images)
                content = res.as_content()
                if res.images:
                    round_images.extend(res.images)
                    content += "\n[приложено изображений: " + str(len(res.images)) + "]"
                messages.append({"role": "tool", "tool_call_id": call["id"], "content": content})

            # --- зрение: картинки уходят ОТДЕЛЬНЫМ user-сообщением после всех tool ---
            if round_images and use_vision:
                shot = vision.build_user_message(round_images, note=(
                    f"Снимки от инструментов ({', '.join(c['name'] for c in pending_calls)}). "
                    "Опиши, что на них видно, и сделай следующий шаг задачи."))
                if shot:
                    messages.append(shot)
                    await _emit(on_event, "vision", images=len(round_images),
                                prepared=len(shot["content"]) - 1)
        else:
            final_text = final_text or "(лимит итераций инструментов исчерпан)"
    except Exception as e:
        await _emit(on_event, "error", text=f"{type(e).__name__}: {e}")

    # служба само-правки: модель ошиблась в маркере озвучки - учим на следующий ход
    if re.search(r"\*-(?:(?!\*-|-\*)[\s\S])*?\*-", final_text):
        note = ("СЛУЖЕБНОЕ (пользователю не показывать): ты нарушил разметку озвучки - "
                "закончил маркер символами `*-` вместо `-*`. Озвучка бывает ТОЛЬКО при *-привет-* "
                "(начало `*-`, конец `-*`). Пример правильной строки: *-Привет, всё готово.*- "
                "В следующих ответах заканчивай голосовую строку строго `-*`.")
        messages.append({"role": "system", "content": note})
        history.append({"role": "system", "content": note})
    elif not re.search(r"\*-(?:(?!\*-|-\*)[\s\S])*?-\*", final_text):
        note = ("СЛУЖЕБНОЕ (пользователю не показывать): в ответе НЕТ голосовой разметки. "
                "КАЖДЫЙ ответ обязан содержать 1-2 фразы внутри маркера *-...-* "
                "(начало `*-`, конец `-*`), иначе вместо тебя озвучат первое предложение. "
                "В следующих ответах всегда добавляй разметку.")
        messages.append({"role": "system", "content": note})
        history.append({"role": "system", "content": note})

    history.append({"role": "user", "content": user_text})
    history.append({"role": "assistant", "content": final_text})
    await _emit(on_event, "done", text=final_text, seconds=round(time.time() - t0, 1),
                think=dec.mode, search=dec.search)
    return final_text
