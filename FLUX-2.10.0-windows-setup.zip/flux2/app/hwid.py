"""Отпечаток оборудования (HWID) для привязки лицензии.

ПРИНЦИПЫ:
  * Собираем НЕСКОЛЬКО независимых компонентов и хешируем каждый отдельно.
  * Полный HWID = sha256 от всех компонентов. Дополнительно отдаём ВАРИАНТЫ —
    «полный без одного компонента». Сервер принимает совпадение с любым вариантом,
    поэтому замена сетевой карты, добавление диска или переустановка драйвера
    НЕ сбрасывают активацию, а смена материнской платы/BIOS даёт новый HWID.
  * Никаких персональных данных: только серийники железа и machine-id.
  * Компоненты, которых нет (виртуалка, Linux без DMI), просто пропускаются —
    минимум 2 компонента, иначе HWID считается ненадёжным.

Windows-источники (читаются СКРЫТО через app/winproc, без окна консоли):
  MachineGuid          — HKLM\\SOFTWARE\\Microsoft\\Cryptography
  SMBIOS UUID          — Win32_ComputerSystemProduct.UUID
  серийник платы       — Win32_BaseBoard.SerialNumber
  серийник BIOS        — Win32_BIOS.SerialNumber
  серийник диска       — Win32_DiskDrive.SerialNumber (первый физический)
  MAC                  — первый физический адаптер (без виртуальных)
  ProductId            — HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion

Linux/macOS: /etc/machine-id, /var/lib/dbus/machine-id, DMI из /sys/class/dmi/id,
IOPlatformUUID (ioreg), серийник диска из /dev/disk/by-id.
"""
from __future__ import annotations

import hashlib
import os
import platform
import re
import subprocess
import sys
import uuid
from typing import Optional

NT = sys.platform == "win32"
MAC = sys.platform == "darwin"

# Компоненты, которые считаются НАДЁЖНЫМИ для привязки. Порядок важен:
# первые в списке — самые стабильные (их смена = реальная смена машины).
STRONG = ("smbios_uuid", "machine_guid", "baseboard", "bios_serial", "product_id")
WEAK = ("mac", "disk_serial")

MIN_COMPONENTS = 2


def _h(value: str) -> str:
    return hashlib.sha256(("flux2-hwid::" + (value or "").strip()).encode()).hexdigest()


def _read_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def _ps(query: str, timeout: float = 12.0) -> str:
    """PowerShell/CIM-запрос СКРЫТО (без всплывающего окна)."""
    if not NT:
        return ""
    try:
        from .. import winproc
        return winproc.ps(query, timeout=timeout)
    except Exception:
        return ""


def _reg_value(path: str, name: str) -> str:
    if not NT:
        return ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ) as k:
            v, _ = winreg.QueryValueEx(k, name)
            return str(v).strip()
    except Exception:
        return ""


def _clean_serial(s: str) -> str:
    """Серийники часто приходят как 'To Be Filled By O.E.M.' или из пробелов —
    такой мусор не должен попадать в отпечаток (иначе у половины парка одинаковый HWID)."""
    s = (s or "").strip()
    junk = {"", "none", "null", "n/a", "na", "default", "unknown", "0", "00000000",
            "000000000000", "to be filled by o.e.m.", "tobefilledbyo.e.m.",
            "system serial number", "chassis serial number", "base board serial number",
            "not specified", "not available", "invalid", "oem", "o.e.m.", "ffffffff"}
    if s.lower() in junk:
        return ""
    if re.fullmatch(r"[\s0.\-]+", s):
        return ""
    return s


def collect() -> dict[str, str]:
    """Собрать сырые значения компонентов (пустые = недоступны)."""
    out: dict[str, str] = {}

    if NT:
        out["machine_guid"] = _reg_value(r"SOFTWARE\Microsoft\Cryptography", "MachineGuid")
        out["product_id"] = _reg_value(
            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "ProductId")
        out["smbios_uuid"] = _ps(
            "(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID")
        out["baseboard"] = _clean_serial(_ps(
            "(Get-CimInstance -ClassName Win32_BaseBoard).SerialNumber"))
        out["bios_serial"] = _clean_serial(_ps(
            "(Get-CimInstance -ClassName Win32_BIOS).SerialNumber"))
        out["disk_serial"] = _clean_serial(_ps(
            "(Get-CimInstance -ClassName Win32_DiskDrive | "
            "Where-Object { $_.MediaType -ne 'Removable Media' } | "
            "Sort-Object Index | Select-Object -First 1).SerialNumber"))
        out["mac"] = _ps(
            "(Get-CimInstance -ClassName Win32_NetworkAdapter | "
            "Where-Object { $_.PhysicalAdapter -eq $true -and $_.MACAddress } | "
            "Sort-Object Index | Select-Object -First 1).MACAddress").replace(":", "").upper()

    elif MAC:
        def _run(argv, timeout):
            try:
                return subprocess.run(argv, capture_output=True, text=True,
                                      timeout=timeout).stdout or ""
            except Exception:
                return ""

        reg = _run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], 15)
        m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', reg)
        if m:
            out["smbios_uuid"] = m.group(1)
        m = re.search(r'"IOPlatformSerialNumber"\s*=\s*"([^"]+)"', reg)
        if m:
            out["bios_serial"] = _clean_serial(m.group(1))
        m = re.search(r"ether\s+([0-9a-f:]{17})", _run(["ifconfig", "en0"], 10))
        if m:
            out["mac"] = m.group(1).replace(":", "").upper()

    else:  # Linux
        out["machine_guid"] = _read_file("/etc/machine-id") or _read_file("/var/lib/dbus/machine-id")
        out["smbios_uuid"] = _read_file("/sys/class/dmi/id/product_uuid")
        out["baseboard"] = _clean_serial(_read_file("/sys/class/dmi/id/board_serial"))
        out["bios_serial"] = _clean_serial(_read_file("/sys/class/dmi/id/product_serial"))
        out["product_id"] = _read_file("/sys/class/dmi/id/product_name")
        out["disk_serial"] = ""
        try:
            for fn in sorted(os.listdir("/dev/disk/by-id")):
                if "part" in fn:
                    continue
                m = re.search(r"^(ata|nvme|scsi)-(.+?)(_|-|$)", fn)
                if m:
                    out["disk_serial"] = _clean_serial(m.group(2))
                    break
        except OSError:
            pass
        out["mac"] = ""
        try:
            for nic in sorted(os.listdir("/sys/class/net")):
                if nic == "lo":
                    continue
                mac = _read_file(f"/sys/class/net/{nic}/address").replace(":", "").upper()
                if mac and mac != "000000000000":
                    out["mac"] = mac
                    break
        except OSError:
            pass

    # нормализация: пустые и «To Be Filled By O.E.M.» в отпечаток не попадают
    return {k: v.strip() for k, v in out.items() if (v or "").strip()}


def component_hashes(raw: Optional[dict] = None) -> dict[str, str]:
    """Хеши компонентов (сырые серийники наружу не отдаём)."""
    raw = collect() if raw is None else raw
    return {k: _h(v) for k, v in raw.items() if v}


def _hw_of(hs: dict[str, str]) -> str:
    """Отпечаток по карте «компонент -> хеш». Пустая строка, если компонентов мало."""
    hs = {k: v for k, v in (hs or {}).items() if v}
    strong = {k: v for k, v in hs.items() if k in STRONG}
    base = strong if len(strong) >= MIN_COMPONENTS else hs
    if len(base) < MIN_COMPONENTS:
        return ""
    ordered = [f"{k}={base[k]}" for k in sorted(base)]
    return hashlib.sha256(("flux2-hwid-v1|" + "|".join(ordered)).encode()).hexdigest()


def hwid(raw: Optional[dict] = None) -> str:
    """Основной отпечаток устройства."""
    return _hw_of(component_hashes(collect() if raw is None else raw))


def hwid_variants(raw: Optional[dict] = None, max_variants: int = 8) -> list[str]:
    """Полный HWID + варианты «без одного компонента».

    Сервер принимает совпадение с ЛЮБЫМ вариантом, поэтому отказ одного датчика
    (сгорела сетевая карта, заменили диск, виртуалка переехала) не убивает лицензию,
    а замена материнской платы (сразу два STRONG-компонента) — убивает.
    """
    hs = component_hashes(collect() if raw is None else raw)
    if not hs:
        return []
    out = [h for h in (_hw_of(hs),) if h]
    # сначала выбрасываем слабые компоненты (mac, диск) — они меняются чаще всего
    for drop in sorted(hs, key=lambda k: 0 if k in WEAK else 1):
        if len(hs) <= MIN_COMPONENTS:
            break
        sub = {k: v for k, v in hs.items() if k != drop}
        h = _hw_of(sub)
        if h and h not in out:
            out.append(h)
    return out[:max_variants]


def label(raw: Optional[dict] = None) -> str:
    """Человекочитаемое описание машины (для админки: «чье это устройство»)."""
    try:
        host = platform.node()
        sysname = f"{platform.system()} {platform.release()}"
        cpu = platform.processor() or platform.machine()
        return f"{host} · {sysname} · {cpu}".strip(" ·")
    except Exception:
        return "неизвестное устройство"


def info() -> dict:
    """Полная справка для диагностики (без сырых серийников — только хеши)."""
    raw = collect()
    hs = component_hashes(raw)
    h = hwid(raw)
    variants = hwid_variants(raw)
    return {
        "hwid": h,
        "hwid_short": (h[:16].upper() if h else ""),
        "reliable": bool(h),
        "components_found": sorted(hs),
        "components_missing": sorted(k for k in
                                     ("machine_guid", "smbios_uuid", "baseboard",
                                      "bios_serial", "product_id", "disk_serial", "mac")
                                     if k not in hs),
        "component_hashes": {k: v[:12] for k, v in hs.items()},
        "variants": variants,
        "label": label(raw),
        "platform": f"{platform.system()} {platform.release()} ({platform.machine()})",
    }


def stable_fallback() -> str:
    """Если надёжных компонентов нет (чистая виртуалка), используем uuid.getnode().

    ЧЕСТНО: это слабая привязка — MAC виртуалки меняется при клонировании.
    Возвращается отдельным методом, чтобы клиент мог предупредить пользователя
    («лицензия привязана ненадёжно, при переносе ВМ потребуется деактивация»).
    """
    return _h("node::" + str(uuid.getnode()))
