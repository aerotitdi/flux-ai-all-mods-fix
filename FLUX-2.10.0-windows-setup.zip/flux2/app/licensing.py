"""Клиент лицензирования FLUX: активация, привязка к HWID, офлайн-проверка, блокировка.

ЖИЗНЕННЫЙ ЦИКЛ
  1. Первый запуск -> нет билета -> окно активации -> пользователь вставляет ключ
     (можно куском письма — ключ найдётся сам).
  2. `activate()` считает отпечаток железа (app/hwid.py) и отправляет его вместе
     с ключом на сервер лицензий.
  3. Сервер проверяет ключ, ПРИВЯЗЫВАЕТ его к этому HWID (одно устройство) и
     возвращает подписанный Ed25519 билет. Билет сохраняется в data/license.json.
     Вместе с билетом сервер присылает `next_check_in` — когда прийти снова.
  4. Дальше проверка ОФЛАЙН: подпись билета проверяется встроенным публичным
     ключом вендора, сверяется HWID и срок. Сервер не нужен каждый запуск.
     Пользователь видит ОБРАТНЫЙ ОТСЧЁТ окна билета (countdown()): 5 дн -> 3 дн
     -> 1 дн -> 15 ч -> 0. На нуле FLUX просит подключиться к серверу.
  5. Вотчдог в app/server.py просыпается каждые 10 минут и зовёт `ping()`.
     ping() уходит на сервер ТОЛЬКО когда наступил предписанный срок
     (`next_check_at`), иначе возвращает skipped=True. Интервал назначает сервер
     — рандом 5-72 ч в зависимости от того, сколько клиентов сейчас активно,
     чтобы не напрягать систему зря.
  6. Если ключ отозван или удалён, сервер говорит об этом сразу, клиент стирает
     билет и ЗАПОМИНАЕТ причину: окно активации показывает «Этот ключ доступа был
     удалён. Причина: …» или «…отозван на неопределённое время» — и после
     перезапуска, и полностью офлайн.
  7. `heartbeat()` (тяжёлый, с передачей билета) дёргается редко: когда окно
     билета подходит к концу и его надо продлить.

ПОЧЕМУ ПИНГ ДЕШЁВЫЙ
  heartbeat() каждый раз тащит на сервер весь подписанный билет: 626 байт из 856
  байт всего обмена. При 1500 клиентах и частом опросе это гигабайты трафика
  впустую — на передаче одного и того же билета. ping() отправляет только key_id
  (~25 байт) и получает состояние (~240 байт), то есть ~267 байт за обмен вместо
  ~856. Замеры и расчёт квот — в deploy/worker/src/sched.mjs.

ПОЧЕМУ ПОКУПАТЕЛЬ НЕ ЗАВИСИТ ОТ ПК РАЗРАБОТЧИКА
  Сервер лицензий работает на Cloudflare Workers (deploy/), а не на машине
  разработчика. Плюс окно билета — 5 суток: всё это время FLUX работает полностью
  офлайн, проверяя подпись локально. Даже если Cloudflare ляжет на выходные,
  никто не заблокируется.

ПОЧЕМУ КЛЮЧ НЕЛЬЗЯ «УВЕЛИЧИТЬ»
  `expires`, `offline_until` и `next_check` лежат ВНУТРИ подписанного билета.
  Приватного ключа вендора в поставке нет, поэтому продлить себе срок, поднять
  план или назначить более редкую проверку нельзя: любая правка payload ломает
  подпись. Проверено тестами deploy/worker/test/crypto_parity.test.mjs и
  tests/test_licensing.py.

ЧЕСТНЫЕ ОГРАНИЧЕНИЯ (так работает любая офлайн-лицензия, а не только эта):
  * перевод системных часов назад ловится частично — билет с `issued` в будущем
    отвергается, но «заморозка» времени между проверками не определяется;
  * полная копия системы (клон диска) даст тот же HWID. Лечится только онлайн-
    политикой «одно активное соединение» — включается флагом `strict_online`.
"""
from __future__ import annotations

import json
import os
import time
from typing import Optional

from . import hwid as HW
from .config import CONFIG, app_dir

try:                                    # профиль сборки: зашитый адрес сервера лицензий
    from . import _build_profile as BP
except Exception:                       # pragma: no cover — файла может не быть в старой сборке
    BP = None

DEFAULT_SERVER = os.environ.get("FLUX_LICENSE_SERVER", "http://127.0.0.1:8790")
STATE_NAME = "license.json"
HEARTBEAT_HOURS_DEFAULT = 72

# коды ответов сервера -> текст для пользователя
ERROR_TEXT = {
    "invalid_key": "ключ не найден или введён с опечаткой",
    "revoked": "ключ отозван разработчиком",
    "expired": "срок действия лицензии истёк",
    "already_bound": "ключ уже активирован на другом устройстве",
    "not_activated": "это устройство не активировано данным ключом",
    "rate_limited": "слишком много попыток — подожди минуту",
    "bad_hwid": "не удалось снять отпечаток устройства",
    "no_admin_token": "сервер лицензий настроен не полностью",
}


class LicenseError(Exception):
    def __init__(self, code: str, message: str, **extra):
        super().__init__(message)
        self.code = code
        self.message = message
        self.extra = extra


def state_path() -> str:
    return os.path.join(app_dir(), "data", STATE_NAME)


def _pub():
    """Публичный ключ вендора + функция проверки билета.

    НАМЕРЕННО не импортирует license_server: этого пакета нет в клиентской поставке,
    проверка подписи реализована здесь же (криптография — из `cryptography`).
    """
    return _pub_standalone()


def _pub_standalone():
    from cryptography.hazmat.primitives.serialization import load_pem_public_key
    try:
        from . import _vendor_key
        pem = (_vendor_key.VENDOR_PUBLIC_KEY or "").strip().encode()
    except Exception:
        pem = b""
    if not pem:
        raise LicenseError("no_pubkey", "в приложение не встроен публичный ключ вендора — "
                                        "сборка повреждена")

    def verify_ticket(pub, ticket: dict, hw: str, now: Optional[float] = None) -> tuple[bool, str]:
        import base64
        now = time.time() if now is None else now
        payload = (ticket or {}).get("payload")
        sig = (ticket or {}).get("sig") or ""
        if not isinstance(payload, dict) or not sig:
            return False, "билет неполный"
        try:
            canon = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                               separators=(",", ":")).encode("utf-8")
            pad = "=" * (-len(sig) % 4)
            pub.verify(base64.urlsafe_b64decode(sig + pad), canon)
        except Exception:
            return False, "подпись билета недействительна"
        if payload.get("hwid") != hw:
            return False, "билет выдан на другое устройство"
        exp = int(payload.get("expires") or 0)
        if exp and now > exp:
            return False, "лицензия истекла"
        off = int(payload.get("offline_until") or 0)
        if off and now > off:
            return False, "истёк срок офлайн-проверки — нужно подключиться к серверу лицензий"
        if now < int(payload.get("issued") or 0) - 86400:
            return False, "билет выдан в будущем — проверь системное время"
        return True, "ok"

    return load_pem_public_key(pem), verify_ticket


def baked_server() -> str:
    """Адрес сервера лицензий, зашитый в сборку (пусто, если сборка из исходников)."""
    return ((getattr(BP, "LICENSE_SERVER_URL", "") or "").strip().rstrip("/")
            if BP is not None else "")


def server_url() -> str:
    """Какой сервер лицензий использовать.

    Приоритет:
      1. config.json -> license_server_url. Заполняется, если пользователь САМ
         ввёл адрес в окне активации («Дополнительно») — его воля важнее зашитого.
      2. адрес, зашитый в сборку (app/_build_profile.py). Именно этот путь проходит
         покупатель: он не видит поле сервера и не может его испортить.
      3. FLUX_LICENSE_SERVER / локальный сервер по умолчанию — для разработки.
    """
    cfg = (CONFIG.settings.get("license_server_url") or "").strip().rstrip("/")
    if cfg:
        return cfg
    baked = baked_server()
    if baked:
        return baked
    return DEFAULT_SERVER.rstrip("/")


def license_required() -> bool:
    """Можно ли запустить приложение без лицензии.

    `license_required=false` — режим разработки/сборки без сервера лицензий.
    В поставке должно быть true.
    """
    return bool(CONFIG.settings.get("license_required", True))


def _hwid() -> tuple[str, list[str], bool]:
    """(hwid, варианты, надёжно). Если железа не читается — слабая привязка по MAC."""
    raw = HW.collect()
    h = HW.hwid(raw)
    if h:
        return h, HW.hwid_variants(raw), True
    return HW.stable_fallback(), [HW.stable_fallback()], False


def _load_state() -> dict:
    try:
        with open(state_path(), "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _save_state(st: dict) -> None:
    path = state_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def clear_state(revoke: Optional[dict] = None) -> None:
    """Снять блокировку билета и ЗАПОМНИТЬ, почему именно.

    Раньше здесь просто обнулялся билет, и причина отзыва терялась вместе с ним:
    при следующем запуске окно активации показывало безликое «Лицензия отозвана».
    Теперь запись о блокировке (`revoke`) переживает перезапуск, и пользователь
    видит конкретный текст — «Этот ключ доступа был удалён. Причина: возврат
    средств» — даже полностью офлайн, потому что сервер для этого не нужен.

    Сам ключ при этом НЕ сохраняется целиком (только маска и короткий key_id):
    хранить полный ключ на заблокированной машине незачем.
    """
    from .license_fmt import mask_key, normalize_kind, revoke_message, revoke_reason_text
    st = _load_state()
    rec = {"kind": "suspended", "reason": "", "at": int(time.time())}
    if revoke:
        kind = normalize_kind(str(revoke.get("kind") or "suspended"))
        reason = str(revoke.get("reason") or "").strip()[:400]
        rec.update({
            "kind": kind,
            "reason": reason,
            "reason_text": revoke_reason_text(kind, reason),
            "title": str(revoke.get("title") or "")[:200],
            "message": str(revoke.get("message") or revoke_message(kind, reason))[:400],
            "permanent": bool(revoke.get("permanent", kind == "deleted")),
            "at": int(revoke.get("revoked_at") or time.time()),
            "key_id": str(revoke.get("key_id") or "")[:16],
            "server": server_url(),
        })
    else:
        rec.update({"reason_text": revoke_reason_text(rec["kind"], ""),
                    "title": "Этот ключ доступа отозван",
                    "message": revoke_message(rec["kind"], ""),
                    "permanent": False, "key_id": "", "server": server_url()})
    # КАКОЙ ключ заблокирован, показываем маской и коротким id — а полный ключ
    # с заблокированной машины стираем: он там больше не нужен (активация всё
    # равно отклоняется), зато уменьшается цена утечки data/license.json.
    masked = mask_key(st.get("key") or "")
    rec["key_masked"] = masked
    st.update({
        "ticket": None,
        "revoked": True,
        "revoked_at": int(time.time()),
        "revoke": rec,
        "key": "",
        "key_masked": masked,
    })
    _save_state(st)


def revoke_record() -> dict:
    """Запись о блокировке из локального состояния ({} если её нет)."""
    st = _load_state()
    if not st.get("revoked"):
        return {}
    rec = dict(st.get("revoke") or {})
    if not rec:
        # состояние от старой версии: revoked=True, а детали не сохранены
        from .license_fmt import revoke_message
        rec = {"kind": "suspended", "reason": "",
               "reason_text": "причина не указана разработчиком",
               "title": "Этот ключ доступа отозван",
               "message": revoke_message("suspended", ""),
               "permanent": False, "at": int(st.get("revoked_at") or 0)}
    rec.setdefault("key_masked", _mask(st.get("key", "")))
    rec["key_masked"] = rec.get("key_masked") or _mask(st.get("key", ""))
    return rec


# ============================================================ сетевые вызовы
async def _post(path: str, payload: dict, timeout: float = 20.0) -> dict:
    import aiohttp
    url = server_url() + path
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
            async with s.post(url, json=payload,
                              headers={"User-Agent": "FluxDesktop/2.9"}) as r:
                try:
                    data = await r.json()
                except Exception:
                    return {"ok": False, "error": "bad_response",
                            "message": f"сервер ответил не JSON (HTTP {r.status})",
                            "status": r.status}
                data["status"] = r.status
                return data
    except Exception as e:
        return {"ok": False, "error": "network", "status": 0,
                "message": f"сервер лицензий недоступен ({url}): {type(e).__name__}: {e}"}


async def activate(key: str, server: str = "") -> dict:
    """Активировать ключ на ЭТОМ устройстве. Первая активация привязывает лицензию."""
    from .license_fmt import extract_key, normalize_key, key_hint, paste_hint
    if server:
        CONFIG.settings["license_server_url"] = server.rstrip("/")
        CONFIG.save()
    # Ключ ищем во всём вставленном тексте: покупатель копирует его из письма
    # вместе с «Ваш ключ:» и подписью, и это не должно выглядеть как ошибка.
    norm = extract_key(key) or normalize_key(key)
    if not norm:
        raw = (key or "").strip()
        hint = paste_hint(raw) if len(raw) > 26 else key_hint(raw)
        raise LicenseError("invalid_key", "ключ введён с ошибкой: " + hint)
    hw, variants, reliable = _hwid()
    if not hw:
        raise LicenseError("bad_hwid", "не удалось снять отпечаток устройства")
    from app import __version__
    res = await _post("/v1/activate", {
        "key": norm, "hwid": hw, "hwid_variants": variants,
        "hwid_label": HW.label(), "app_version": __version__})
    if not res.get("ok"):
        code = res.get("error") or "unknown"
        revoke = res.get("revoke") or None
        if code == "revoked" and revoke:
            # запоминаем причину локально: окно активации покажет её и офлайн,
            # и после перезапуска, без повторного обращения к серверу
            st = _load_state()
            st["key"] = norm                    # чтобы маска показывала тот самый ключ
            _save_state(st)
            clear_state(revoke)
        raise LicenseError(code, res.get("message") or ERROR_TEXT.get(code, code),
                           bound=res.get("bound") or [], status=res.get("status"),
                           revoke=revoke or {})
    st = _load_state()
    st.update({"key": norm, "ticket": res["ticket"], "hwid": hw,
               "hwid_reliable": reliable, "hwid_label": HW.label(),
               "activated_at": int(time.time()), "last_check": int(time.time()),
               "server": server_url(), "plan": res.get("plan"),
               "license_id": res.get("license_id"), "revoked": False,
               "revoke": None, "key_masked": _mask(norm),
               "heartbeat_hours": int(res.get("heartbeat_hours") or HEARTBEAT_HOURS_DEFAULT),
               # когда сервер велел прийти снова и сколько живёт билет.
               # Оба числа ПРИХОДЯТ С СЕРВЕРА, а не выбираются клиентом: сервер
               # дозирует нагрузку по числу активных клиентов (рандом 5-72 ч),
               # а обратный отсчёт считается от offline_until внутри подписи.
               "next_check_in": int(res.get("next_check_in") or 0),
               "next_check_at": (int(time.time()) + int(res.get("next_check_in") or 0))
                                if res.get("next_check_in") else 0,
               "ticket_ttl_hours": float(res.get("ticket_ttl_hours") or 0),
               "active_clients": int(res.get("active_clients") or 0)})
    _save_state(st)
    return st


async def ping(force: bool = False) -> dict:
    """Дешёвая проверка «жив ли ключ» БЕЗ передачи билета.

    Зачем отдельный метод, когда есть heartbeat()
    ---------------------------------------------
    heartbeat() каждый раз тащит на сервер весь подписанный билет — 626 байт из
    856 байт всего обмена. При опросе каждые 10 минут и 1500 клиентах это 5 ГБ
    трафика в месяц только на передачу одного и того же билета.

    ping() отправляет лишь key_id (~25 байт) и получает состояние (~240 байт):
    жив ключ или заблокирован, сколько осталось до конца отсчёта и когда прийти
    снова. Обмен выходит в 3 раза меньше, поэтому опрашивать можно часто.

    Билет при этом остаётся главным доказательством: он проверен подписью вендора
    и работает офлайн. ping() — это только быстрая доставка ОТМЕНЫ, а не замена
    офлайн-проверки.

    Возвращает {"ok": True, ...} либо бросает LicenseError при блокировке.
    """
    st = _load_state()
    if not st.get("ticket"):
        return {"ok": False, "reason": "not_activated"}
    nci = int(st.get("next_check_in") or 0)
    nca = int(st.get("next_check_at") or 0)
    # уважаем интервал, который ПРЕДПИСАЛ сервер: он знает, сколько клиентов
    # сейчас активно, и растягивает опрос, чтобы не напрягать систему зря
    if not force and nca and time.time() < nca:
        return {"ok": True, "skipped": True, "next_check_at": nca,
                "in_seconds": max(0, nca - int(time.time()))}

    res = await _post("/v1/ping", {"key_id": st.get("license_id") or ""}, timeout=10.0)

    # СОВМЕСТИМОСТЬ СО СТАРЫМ СЕРВЕРОМ. /v1/ping есть только у Worker'а на
    # Cloudflare; локальный license_server/server.py его не знает и ответит 404.
    # Падать из-за этого нельзя: иначе обновление сервера сломало бы всех, кто ещё
    # на старой сборке клиента (и наоборот). В такой ситуации молча возвращаем
    # «не удалось опросить», а отзыв всё равно придёт через heartbeat().
    if res.get("error") == "not_found" or res.get("status") == 404:
        return {"ok": False, "unsupported": True,
                "reason": "сервер лицензий не поддерживает /v1/ping — "
                          "проверка пойдёт через heartbeat"}

    if res.get("revoked") or res.get("blocked"):
        info = res.get("revoke") or {"kind": "suspended", "reason": res.get("reason") or ""}
        clear_state(info)
        from .license_fmt import normalize_kind
        kind = normalize_kind(str(info.get("kind") or "suspended"))
        reason = str(info.get("reason") or "").strip()
        detail = (f": ключ доступа УДАЛЁН" + (f" ({reason})" if reason else "")
                  if kind == "deleted" else
                  (" на неопределённое время" + (f": {reason}" if reason else "")))
        raise LicenseError("revoked", "Лицензия ОТОЗВАНА разработчиком" + detail
                           + ". Приложение заблокировано — требуется новый ключ.",
                           revoke=info, status=res.get("status"))
    if res.get("error") == "network":
        # нет связи — не наказываем пользователя: работает офлайн-окно билета
        return {"ok": False, "offline": True, "reason": res.get("message", "")}
    if not res.get("ok"):
        code = res.get("error") or "unknown"
        raise LicenseError(code, res.get("message") or ERROR_TEXT.get(code, code),
                           status=res.get("status"))

    st = _load_state()
    st["last_check"] = int(time.time())
    nci = int(res.get("next_check_in") or nci or 0)
    st["next_check_in"] = nci
    st["next_check_at"] = int(time.time()) + nci if nci else 0
    if res.get("ticket_ttl_hours"):
        st["ticket_ttl_hours"] = float(res["ticket_ttl_hours"])
    if res.get("active_clients") is not None:
        st["active_clients"] = int(res.get("active_clients") or 0)
    if res.get("plan"):
        st["plan"] = res["plan"]
    _save_state(st)
    return {"ok": True, "next_check_in": nci,
            "next_check_in_hours": round(nci / 3600, 1) if nci else None,
            "seconds_left": res.get("seconds_left"),
            "left_human": res.get("left_human"),
            "active_clients": st.get("active_clients")}


async def heartbeat(force: bool = False) -> dict:
    """Онлайн-проверка: не отозван ли ключ. Возвращает сводку."""
    st = _load_state()
    if not st.get("ticket"):
        return {"ok": False, "reason": "not_activated"}
    hb = int(st.get("heartbeat_hours") or HEARTBEAT_HOURS_DEFAULT)
    if not force and st.get("last_check") and (time.time() - st["last_check"]) < hb * 3600:
        return {"ok": True, "skipped": True, "checked_at": st["last_check"]}
    hw, variants, _ = _hwid()
    from app import __version__
    res = await _post("/v1/heartbeat", {"key": st.get("key", ""), "hwid": st.get("hwid") or hw,
                                        "hwid_variants": variants, "ticket": st["ticket"],
                                        "app_version": __version__})
    if res.get("revoked"):
        revoke = res.get("revoke") or {"kind": "suspended",
                                       "reason": res.get("reason") or ""}
        from .license_fmt import normalize_kind
        kind = normalize_kind(str(revoke.get("kind") or "suspended"))
        reason = str(revoke.get("reason") or "").strip()
        clear_state(revoke)
        # Формулировка намеренно содержит и «ОТОЗВАНА», и «требуется новый ключ»:
        # это читает человек в плашке блокировки, и по этим же словам тесты
        # отличают отзыв от сетевой ошибки.
        detail = (f": ключ доступа УДАЛЁН" + (f" ({reason})" if reason else "")
                  if kind == "deleted" else
                  (" на неопределённое время" + (f": {reason}" if reason else "")))
        raise LicenseError("revoked", "Лицензия ОТОЗВАНА разработчиком" + detail
                           + ". Приложение заблокировано — требуется новый ключ.",
                           revoke=revoke, status=res.get("status"))
    if res.get("ok"):
        st = _load_state()
        st["last_check"] = int(time.time())
        if res.get("ticket"):                      # сервер перевыпустил билет
            st["ticket"] = res["ticket"]
        if res.get("plan"):
            st["plan"] = res["plan"]
        st["heartbeat_hours"] = int(res.get("heartbeat_hours") or hb)
        st["revoked"] = False
        st["revoke"] = None            # отзыв снят — запись о блокировке больше не нужна
        _save_state(st)
        return {"ok": True, "renewed": bool(res.get("renewed")), "plan": st.get("plan")}
    if res.get("error") == "network":
        # нет связи — не наказываем пользователя, работаем по офлайн-окну билета
        return {"ok": False, "offline": True, "reason": res.get("message", "")}
    code = res.get("error") or "unknown"
    raise LicenseError(code, res.get("message") or ERROR_TEXT.get(code, code),
                       status=res.get("status"))


async def keystatus(key: str) -> dict:
    """Проверить ключ на сервере, НЕ активируя его.

    Используется окном активации: пользователь вставил ключ — и сразу узнаёт,
    что с ним («удалён, причина: …», «отозван на неопределённое время», «истёк»,
    «можно активировать»). Место в лицензии при этом не занимается, устройство не
    привязывается, поэтому ошибочная вставка ничего не портит.

    Офлайн это не работает — но и не должно: функция лишь подсказка, решение
    принимает activate().
    """
    from .license_fmt import extract_key, normalize_key, paste_hint
    norm = extract_key(key) or normalize_key(key or "")
    if not norm:
        return {"ok": False, "error": "invalid_key", "format_ok": False,
                "message": paste_hint(key or "")}
    res = await _post("/v1/keystatus", {"key": norm}, timeout=8.0)
    res.setdefault("format_ok", True)
    return res


async def deactivate() -> dict:
    """Освободить устройство, чтобы перенести лицензию на другой компьютер."""
    st = _load_state()
    if not st.get("key"):
        return {"ok": False, "reason": "нет активной лицензии"}
    res = await _post("/v1/deactivate", {"key": st["key"], "hwid": st.get("hwid", "")})
    try:
        os.remove(state_path())
    except OSError:
        pass
    return res


# ============================================================ локальная проверка
def validate(now: Optional[float] = None) -> dict:
    """Офлайн-проверка билета. НИКОГДА не обращается к сети.

    Возвращает {"ok": bool, "reason": str, ...}. При ok=False приложение должно
    показать окно активации.
    """
    now = time.time() if now is None else now
    if not license_required():
        return {"ok": True, "mode": "license_required=false (режим разработки)"}
    st = _load_state()
    if st.get("revoked"):
        rec = revoke_record()
        msg = rec.get("message") or "Этот ключ доступа отозван"
        # permanent = ключ УДАЛЁН: новый ключ обязателен, «Вернуть» не поможет
        return {"ok": False, "reason": msg + (". Требуется новый ключ."
                                              if rec.get("permanent") else
                                              ". Обратись к разработчику или введи новый ключ."),
                "need_key": True, "revoked": True, "revoke": rec}
    ticket = st.get("ticket")
    if not ticket:
        first = not st.get("activated_at") and not st.get("key")
        return {"ok": False,
                "reason": ("Введи лицензионный ключ, чтобы продолжить." if first else
                           "Приложение не активировано. Введи лицензионный ключ."),
                "need_key": True, "first_run": first}
    hw, variants, reliable = _hwid()
    if not hw:
        return {"ok": False, "reason": "Не удалось снять отпечаток устройства "
                                       "(нет доступа к данным о железе).", "need_key": False}
    stored_hw = st.get("hwid") or hw
    try:
        pub, verify_ticket = _pub()
    except LicenseError as e:
        return {"ok": False, "reason": str(e), "need_key": False}
    except Exception as e:
        return {"ok": False,
                "reason": f"Не удалось проверить лицензию: {type(e).__name__}: {e}",
                "need_key": False}

    ok, why = verify_ticket(pub, ticket, stored_hw, now)
    if not ok:
        # билет выдан на это устройство, но железо изменилось сильнее допуска —
        # пробуем варианты отпечатка (замена одного компонента)
        for v in variants:
            ok2, why2 = verify_ticket(pub, ticket, v, now)
            if ok2:
                ok, why = True, "ok (совпал вариант отпечатка)"
                break
        if not ok:
            need_key = "другое устройство" in why or "подделан" in why
            return {"ok": False, "reason": f"Проверка лицензии не пройдена: {why}",
                    "need_key": need_key, "hwid_changed": "другое устройство" in why}
    payload = (ticket or {}).get("payload") or {}
    exp = int(payload.get("expires") or 0)
    off = int(payload.get("offline_until") or 0)
    return {"ok": True, "plan": st.get("plan") or payload.get("plan"),
            "license_id": st.get("license_id") or payload.get("kid"),
            "customer": payload.get("customer") or "",
            "expires": exp, "days_left": (round((exp - now) / 86400, 1) if exp else None),
            "offline_until": off,
            "offline_days_left": round((off - now) / 86400, 1) if off else None,
            "hwid": stored_hw, "hwid_reliable": bool(st.get("hwid_reliable", reliable)),
            "hwid_label": st.get("hwid_label", ""),
            "last_check": st.get("last_check"), "activated_at": st.get("activated_at"),
            "server": st.get("server") or server_url(), "why": why}


def status() -> dict:
    """Сводка для UI: активировано ли, какой план, сколько осталось."""
    v = validate()
    st = _load_state()
    v["activated"] = bool(st.get("ticket")) and not st.get("revoked")
    v["key_masked"] = _mask(st.get("key", ""))
    v["required"] = license_required()
    v["server"] = server_url()
    v["hwid_info"] = hwid_info()      # отпечаток, которым лицензия привязана/привяжется
    # --- что показывать в окне активации -----------------------------------
    rec = revoke_record()
    v["revoke"] = rec or None
    v["revoked"] = bool(st.get("revoked"))
    # Первый запуск: состояния нет вовсе (ни билета, ни попытки активации, ни отзыва).
    # UI на этом основании показывает «Введи ключ доступа» вместо технических строк.
    v["first_run"] = (not st.get("ticket") and not st.get("revoked")
                      and not st.get("activated_at"))
    if rec:
        v["headline"] = rec.get("title") or "Этот ключ доступа отозван"
        v["headline_reason"] = rec.get("reason_text") or ""
        v["headline_kind"] = rec.get("kind") or "suspended"
        v["headline_permanent"] = bool(rec.get("permanent"))
    elif v["first_run"]:
        v["headline"] = "Введи ключ доступа"
        v["headline_reason"] = ""
        v["headline_kind"] = ""
        v["headline_permanent"] = False
    else:
        v["headline"] = "Требуется лицензионный ключ"
        v["headline_reason"] = v.get("reason") or ""
        v["headline_kind"] = ""
        v["headline_permanent"] = False
    # адрес сервера, зашитый в сборку: если он есть, поле сервера в UI не нужно
    v["server_baked"] = baked_server()
    v["server_locked"] = bool(baked_server()) and not (
        (CONFIG.settings.get("license_server_url") or "").strip())
    # --- обратный отсчёт и предписанный сервером интервал опроса -------------
    # Считается ЛОКАЛЬНО от подписанного offline_until: сервер для этого не нужен,
    # поэтому цифры не «прыгают» и не зависят от доступности сети.
    v["countdown"] = countdown()
    v["edition"] = getattr(BP, "EDITION", "developer") if BP is not None else "developer"
    v["build"] = {"dev": bool(getattr(BP, "DEV", True)) if BP is not None else True,
                  "flavor": getattr(BP, "BUILD_FLAVOR", "source") if BP is not None else "source",
                  "id": getattr(BP, "BUILD_ID", "") if BP is not None else ""}
    return v


def _mask(key: str) -> str:
    if not key:
        return ""
    parts = key.split("-")
    if len(parts) != 5:
        return key[:4] + "…"
    return "-".join([parts[0], parts[1], "*****", "*****", parts[4]])


def humanize_left(seconds: Optional[float]) -> str:
    """«5 дн 3 ч» / «15 ч» / «10 мин» / «0 ч» — тот отсчёт, что видит пользователь.

    Совпадает с deploy/worker/src/sched.mjs::humanizeLeft, чтобы сервер и клиент
    показывали одно и то же.
    """
    s = max(0, int(round(seconds or 0)))
    if s <= 0:
        return "0 ч"
    d, rem = divmod(s, 86400)
    h, rem2 = divmod(rem, 3600)
    m = rem2 // 60
    if d:
        return f"{d} дн {h} ч" if h else f"{d} дн"
    if h:
        return f"{h} ч {m} мин" if m else f"{h} ч"
    return f"{m} мин" if m else "меньше минуты"


def countdown(now: Optional[float] = None) -> dict:
    """Сколько осталось работать без связи с сервером лицензий.

    Это и есть «обратный отсчёт» из ТЗ: сервер при каждой отметке продлевает
    окно билета, а между отметками клиент сам считает вниз — 5 дн -> 3 дн -> 1 дн
    -> 15 ч -> 0 -> окно активации. Считается ЛОКАЛЬНО от подписанного
    `offline_until`, поэтому цифры не зависят от доступности сети.

    Подделать отсчёт нельзя: `offline_until` лежит внутри билета, подписанного
    приватным ключом вендора, которого в поставке нет.
    """
    now = time.time() if now is None else now
    st = _load_state()
    ticket = st.get("ticket") or {}
    payload = ticket.get("payload") if isinstance(ticket, dict) else None
    out = {
        "active": bool(ticket) and not st.get("revoked"),
        "seconds_left": None, "human": "", "until": 0,
        "next_check_at": int(st.get("next_check_at") or 0),
        "next_check_in": int(st.get("next_check_in") or 0),
        "next_check_human": "",
        "ticket_ttl_hours": float(st.get("ticket_ttl_hours") or 0),
        "active_clients": int(st.get("active_clients") or 0),
        "expired": False,
    }
    if out["next_check_in"]:
        out["next_check_in"] = max(0, out["next_check_at"] - int(now)) \
            if out["next_check_at"] else out["next_check_in"]
        out["next_check_human"] = humanize_left(out["next_check_in"])
    if not isinstance(payload, dict):
        return out
    until = int(payload.get("offline_until") or 0)
    if not until:
        return out
    left = max(0, until - int(now))
    out.update({"until": until, "seconds_left": left, "human": humanize_left(left),
                "expired": left <= 0})
    return out


def require() -> tuple[bool, str]:
    """Простой шлюз для main.py: (можно запускать, причина)."""
    v = validate()
    return bool(v.get("ok")), v.get("reason", "")


def hwid_info() -> dict:
    """Что видит клиент в качестве отпечатка (для окна активации и «О программе»).

    Показываем ИМЕННО ТОТ отпечаток, который реально уходит на сервер:
    если надёжные компоненты железа не читаются (чистая виртуалка, урезанная
    сборка ОС), используется запасной по MAC — и это надо показать пользователю,
    а не отдавать пустую строку.
    """
    info = HW.info()
    hw, variants, reliable = _hwid()
    info["effective_hwid"] = hw
    info["effective_short"] = hw[:16].upper() if hw else ""
    info["reliable"] = reliable
    info["variants_count"] = len(variants)
    if not reliable:
        info["warning"] = ("Надёжный отпечаток недоступен (нет данных SMBIOS/реестра). "
                           "Привязка выполнена по MAC-адресу — она слабая: при клонировании "
                           "виртуальной машины или смене сетевого адаптера лицензия может "
                           "потребовать повторной активации.")
    return info
