"""Конфигурация FLUX 2.0: минимум настроек на виду, всё остальное — в модалках.

Файл config.json лежит рядом с exe (или в ~/.flux2 при запуске из исходников).
Структура:
  settings  — то, что видно на главной панели: поиск + модель чата (+ think/code)
  voice     — микрофон и голос Flux (TTS)
  connections — список подключений к провайдерам (как в Open WebUI: базовый адрес,
                Bearer-ключ, тип API, расширенные поля)
"""
from __future__ import annotations

import json
import os
import sys
import uuid
from typing import Any, Optional

APP_NAME = "FLUX 2.0"

DEFAULT_CONNECTION = {
    "id": "",
    "name": "",
    "type": "external",            # Тип подключения: Внешнее
    "base_url": "",                # URL / Базовый адрес API
    "auth": "Bearer",              # Вход: Bearer / None / X-API-Key
    "api_key": "",                 # Ключ API
    "api_type": "chat_completions",  # тип API: Chat Completions
    "forward_cookies": False,      # Передавать файлы cookie
    "headers": {},                 # Заголовки (JSON)
    "passthrough": [],             # Сквозные параметры: thinking, output_config...
    "id_prefix": "",               # ID префикса
    "provider": "default",         # Провайдер
    "model_ids": [],               # IDs Модели
    "tags": [],                    # Теги
}

DEFAULTS: dict[str, Any] = {
    "cfgver": 2,
    "settings": {
        "search_engine": "duckduckgo",   # duckduckgo|searxng|bing|google|wikipedia|brave|off
        "searxng_url": "http://localhost:8888",
        "brave_key": "",
        "model_ref": "",                  # "connection_id::model_id"
        "think_mode": "medium",           # auto|off|brief|medium|deep (medium = средне-тяжёлый, всегда)
        "skills_auto": True,
        "code_engine": "python",
        "stt_mode": "auto",               # auto|browser|provider|whisper
        "autospeak": False,
        "wake_mode": "start",             # off|start|any  (флюкс/люкс/flux)
        "cdp_mode": "user",               # user = твой настоящий Chrome (рестарт с портом при нужде) | isolated
        "window_engine": "auto",          # auto|chrome|edge|webview|web
        "ui_scene": "space",              # space|uranus|solar|galaxy
        "ollama_on": True,
        "ollama_url": "http://127.0.0.1:11434",
        "max_tool_rounds": 999,           # лимит итераций инструментов снят
        # --- зрение (мультимодальность) -------------------------------------
        "vision_mode": "auto",            # auto|on|off: отправлять ли картинки модели
        "vision_max_px": 1568,            # длинная сторона после ресайза
        "vision_max_images": 3,           # картинок за один ход
        # --- браузер: как глубоко читать страницу ---------------------------
        "page_snapshot_max": 220,         # элементов в карте страницы
        "page_shadow_dom": True,          # обходить shadow roots (YouTube и др.)
        # --- медиаплеер FLUX -------------------------------------------------
        "music_source": "ask",            # ask|native|youtube|yandex|vk|spotify
        "music_loop": False,              # зацикливать трек/плейлист
        "music_dir": "",                  # каталог локальной фонотеки (пусто = Музыка ОС)
        # --- страж ПК: уровни подтверждения привилегированных действий -------
        "guard_mode": "confirm",          # off|confirm|auto  (auto = без запроса, ОПАСНО)
        "guard_quarantine": "",           # каталог карантина (пусто = data/quarantine)
    },
    "voice": {
        "mic_id": "",
        "voice": "ru-RU-DmitryNeural",
        "rate": 0,      # -50..+50 %
        "pitch": 0,     # -20..+20 Hz
        "tts_engine": "winget",   # winget|edge|browser|off  (winget = text-to-speech.wingetgui.com, mp3)
    },
    "connections": [],
}


def app_dir() -> str:
    """Каталог данных: рядом с exe, иначе ~/.flux2."""
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.environ.get("FLUX2_HOME") or os.path.join(os.path.expanduser("~"), ".flux2")
    os.makedirs(base, exist_ok=True)
    for sub in ("data", "data/shots", "data/skills_cache", "data/audio"):
        os.makedirs(os.path.join(base, sub), exist_ok=True)
    return base


def config_path() -> str:
    return os.path.join(app_dir(), "config.json")


def _deep_merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class Config:
    def __init__(self, path: Optional[str] = None):
        self.path = path or config_path()
        self.data: dict[str, Any] = _deep_merge(DEFAULTS, {})
        self.load()

    def load(self) -> None:
        self._raw_ver = 1
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                self._raw_ver = int(raw.get("cfgver", 1))
                self.data = _deep_merge(DEFAULTS, raw)
            except Exception:
                self.data = _deep_merge(DEFAULTS, {})
        else:
            self.save()
        self._migrate()

    def _migrate(self) -> None:
        """Миграции между версиями конфига (по версии ИЗ ФАЙЛА, не из DEFAULTS)."""
        ver = self._raw_ver
        if ver < 2:
            # v2.6: think по умолчанию - средне-тяжёлый всегда
            self.settings["think_mode"] = "medium"
            ver = 2
        if ver != self._raw_ver or "cfgver" not in self.data:
            self.data["cfgver"] = ver
            self.save()

    def save(self) -> None:
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.path)

    # --- helpers -----------------------------------------------------------
    @property
    def settings(self) -> dict:
        return self.data.setdefault("settings", {})

    @property
    def voice(self) -> dict:
        return self.data.setdefault("voice", {})

    @property
    def connections(self) -> list:
        return self.data.setdefault("connections", [])

    def get_connection(self, conn_id: str) -> Optional[dict]:
        for c in self.connections:
            if c.get("id") == conn_id:
                return c
        return None

    def model_ref_parts(self) -> tuple[str, str]:
        ref = self.settings.get("model_ref", "") or ""
        if "::" in ref:
            a, b = ref.split("::", 1)
            return a, b
        return "", ""

    def active_connection(self) -> Optional[dict]:
        cid, _ = self.model_ref_parts()
        conn = self.get_connection(cid) if cid else None
        if conn:
            return conn
        return self.connections[0] if self.connections else None

    def active_model(self) -> str:
        cid, mid = self.model_ref_parts()
        conn = self.active_connection()
        if mid:
            return mid
        if conn and conn.get("model_ids"):
            return conn["model_ids"][0]
        return ""

    def upsert_connection(self, conn: dict) -> dict:
        conn = _deep_merge(DEFAULT_CONNECTION, conn)
        if not conn.get("id"):
            conn["id"] = uuid.uuid4().hex[:10]
        if not conn.get("name"):
            conn["name"] = conn.get("base_url") or conn["id"]
        for i, c in enumerate(self.connections):
            if c.get("id") == conn["id"]:
                self.connections[i] = conn
                break
        else:
            self.connections.append(conn)
        self.save()
        return conn

    def delete_connection(self, conn_id: str) -> None:
        self.data["connections"] = [c for c in self.connections if c.get("id") != conn_id]
        self.save()


CONFIG = Config()


def get() -> Config:
    return CONFIG
