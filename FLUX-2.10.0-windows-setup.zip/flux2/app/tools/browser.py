"""Тулзы браузера: окна и вкладки раздельно, переключение, работа с любой вкладкой.

Транспорт выбирает шина app.browserbus: расширение FLUX Bridge (живой Chrome, chrome.debugger)
или классический CDP (9222 / DevToolsActivePort). Ничего не закрывается автоматически.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import subprocess
import time

from .. import browser_cdp as cdp
from .. import browserbus as bus
from ..config import app_dir
from .registry import P, REG, ToolResult

C = "browser"
T = REG.tool


@T("browser_status", "Статус подключения к браузеру: мост расширения (живой Chrome) или CDP; версия и число вкладок", [], C, core=True)
async def _(ctx):
    from .. import bridge
    if bridge.online():
        tabs = await bus.targets()
        return f"транспорт: расширение FLUX Bridge -> ЖИВОЙ Chrome пользователя · вкладок: {len(tabs)}"
    if await cdp.discover():
        v = await cdp.version()
        tabs = await bus.targets()
        return f"транспорт: CDP ({cdp._http_base()}) · {v.get('Browser')} · вкладок: {len(tabs)}"
    if cdp.chrome_running():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    return "браузер не запущен: вызови browser_tabs_list - FLUX поднимет твой Chrome сам (ничего не закрывая)"


@T("browser_tabs_list", "Список всех ВКЛАДОК живого браузера (id, окно, заголовок, url, активна)", [], C, core=True)
async def _(ctx):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    ts = await bus.targets()
    return "\n".join(f"{t['id']} окно={t.get('windowId')} {'[активна]' if t.get('active') else ''} "
                     f"{t['title'][:60]} :: {t['url'][:90]}" for t in ts) or "вкладок нет"


@T("browser_windows_list", "Список ОКОН браузера с их вкладками и границами", [], C, core=True)
async def _(ctx):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    wm = await bus.windows_map()
    out = []
    for w in wm:
        out.append(f"ОКНО #{w['windowId']} bounds={w.get('bounds')}{' [в фокусе]' if w.get('focused') else ''}")
        for t in w["tabs"]:
            out.append(f"  вкладка {t['id']} | {t['title'][:60]} | {t['url'][:80]}")
    return "\n".join(out) or "окон нет"


@T("browser_tab_switch", "Переключить (активировать) вкладку по id", [P("tab", desc="id вкладки")], C, core=True)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.activate(tab)
    return f"вкладка {tab} активна"


@T("browser_tab_open", "Открыть новую вкладку с URL", [P("url", desc="URL")], C)
async def _(ctx, url):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    tid = await bus.new_tab(url)
    return f"вкладка открыта: {tid}"


@T("browser_tab_close", "Закрыть вкладку по id", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.close(tab)
    return "вкладка закрыта"


@T("browser_tab_navigate", "Перейти по URL в указанной вкладке", [P("tab", desc="id вкладки"), P("url", desc="URL")], C)
async def _(ctx, tab, url):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.navigate(tab, url)
    return f"переход: {url}"


@T("browser_tab_reload", "Перезагрузить вкладку", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.reload(tab)
    return "перезагружена"


@T("browser_tab_go_back", "Назад по истории вкладки", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    return await bus.back(tab)


@T("browser_tab_go_forward", "Вперёд по истории вкладки", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    return await bus.forward(tab)


@T("browser_tab_info", "Заголовок и URL вкладки", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    title = await bus.evaluate(tab, "document.title")
    url = await bus.evaluate(tab, "location.href")
    return f"title={title}\nurl={url}"


@T("browser_tab_screenshot", "Скриншот вкладки (PNG в data/shots, вернёт путь и картинку)", [P("tab", desc="id вкладки")], C, core=True)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    data = await bus.screenshot_b64(tab)
    path = os.path.join(app_dir(), "data", "shots", f"shot_{int(time.time()*1000)}.png")
    with open(path, "wb") as f:
        f.write(base64.b64decode(data))
    return ToolResult(True, f"скриншот сохранён: {path}", images=[path])


@T("browser_tab_text", "Видимый текст страницы вкладки", [P("tab", desc="id вкладки"), P("max_chars", "integer", desc="лимит", required=False, default=6000)], C, core=True)
async def _(ctx, tab, max_chars):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    txt = await bus.evaluate(tab, "document.body ? document.body.innerText : ''")
    return (txt or "")[:max_chars] or "(пусто)"


@T("browser_tab_html", "HTML страницы вкладки", [P("tab", desc="id вкладки"), P("max_chars", "integer", desc="лимит", required=False, default=6000)], C)
async def _(ctx, tab, max_chars):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    html = await bus.evaluate(tab, "document.documentElement.outerHTML")
    return (html or "")[:max_chars]


@T("browser_tab_eval", "Выполнить JS-выражение во вкладке и вернуть результат", [P("tab", desc="id вкладки"), P("expression", desc="JS")], C)
async def _(ctx, tab, expression):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    val = await bus.evaluate(tab, expression)
    return json.dumps(val, ensure_ascii=False, default=str)[:6000]


@T("browser_tab_click", "Клик по CSS-селектору во вкладке", [P("tab", desc="id вкладки"), P("selector", desc="CSS-селектор")], C)
async def _(ctx, tab, selector):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.click_selector(tab, selector)
    return f"клик: {selector}"


@T("browser_tab_type", "Ввести текст в поле (селектор) во вкладке", [P("tab", desc="id вкладки"), P("selector", desc="CSS-селектор поля"), P("text", desc="текст")], C)
async def _(ctx, tab, selector, text):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.type_text(tab, selector, text)
    return f"введено в {selector}"


@T("browser_tab_scroll", "Прокрутить вкладку на dy пикселей", [P("tab", desc="id вкладки"), P("dy", "integer", desc="пиксели (+ вниз)")], C)
async def _(ctx, tab, dy):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.scroll(tab, dy)
    return f"прокрутка {dy}px"


@T("browser_tab_key", "Нажать клавишу во вкладке (Enter, Tab, Escape...)", [P("tab", desc="id вкладки"), P("key", desc="клавиша")], C)
async def _(ctx, tab, key):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.key(tab, key)
    return f"клавиша {key}"


@T("browser_tab_wait", "Ждать появления селектора во вкладке", [P("tab", desc="id вкладки"), P("selector", desc="CSS"), P("timeout_s", "integer", desc="секунд", required=False, default=10)], C)
async def _(ctx, tab, selector, timeout_s):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        ok = await bus.evaluate(tab, f"!!document.querySelector({json.dumps(selector)})")
        if ok:
            return "появился"
        await asyncio.sleep(0.5)
    return "таймаут ожидания"


@T("browser_tab_cookies", "Cookie вкладки", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    cs = await bus.cookies(tab)
    return json.dumps([{"name": c.get("name"), "value": str(c.get("value", ""))[:40], "domain": c.get("domain")}
                       for c in cs[:40]], ensure_ascii=False)


@T("browser_tab_pdf", "Сохранить вкладку в PDF", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    data = await bus.pdf(tab)
    path = os.path.join(app_dir(), "data", f"page_{int(time.time())}.pdf")
    with open(path, "wb") as f:
        f.write(base64.b64decode(data))
    return f"pdf: {path}"


@T("browser_tab_find", "Найти текст на странице вкладки (число вхождений + контекст)", [P("tab", desc="id вкладки"), P("needle", desc="текст")], C)
async def _(ctx, tab, needle):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    txt = await bus.evaluate(tab, "document.body ? document.body.innerText : ''") or ""
    import re as _re
    hits = [m.start() for m in _re.finditer(_re.escape(needle), txt, _re.IGNORECASE)]
    ctxs = [txt[max(0, h - 60):h + 80].replace("\n", " ") for h in hits[:5]]
    return f"вхождений={len(hits)}\n" + "\n".join("…" + c + "…" for c in ctxs)


@T("browser_tab_links", "Ссылки страницы вкладки (текст + href)", [P("tab", desc="id вкладки"), P("limit", "integer", desc="лимит", required=False, default=40)], C)
async def _(ctx, tab, limit):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    links = await bus.evaluate(tab, """
      Array.from(document.querySelectorAll('a[href]')).slice(0, %d)
        .map(a => (a.innerText||'').trim().slice(0,60) + ' :: ' + a.href)""" % limit)
    return "\n".join(links) or "ссылок нет"


@T("browser_tab_forms", "Формы и поля страницы вкладки (селекторы для ввода)", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    forms = await bus.evaluate(tab, """
      Array.from(document.querySelectorAll('input,select,textarea,button')).slice(0,40)
        .map(el => el.tagName + ' type=' + (el.type||'') + ' name=' + (el.name||el.id||'') +
             ' placeholder=' + (el.placeholder||''))""")
    return "\n".join(forms) or "форм нет"


@T("browser_tabs_count", "Сколько всего окон и вкладок открыто", [], C)
async def _(ctx):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    wm = await bus.windows_map()
    return f"окон={len(wm)} вкладок={sum(len(w['tabs']) for w in wm.values())}"


@T("browser_window_focus", "Вывести окно на передний план (по windowId)", [P("window_id", "integer", desc="id окна")], C)
async def _(ctx, window_id):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    from .. import bridge
    if bridge.online():
        wm = await bus.windows_map()
        w = next((w for w in wm if w["windowId"] == window_id), None)
        if not w or not w["tabs"]:
            return ToolResult(False, f"окно {window_id} не найдено или без вкладок")
        await bus.activate(w["tabs"][0]["id"])
        return f"окно {window_id} в фокусе"
    bw = await cdp.browser_ws()
    await cdp._cmd_ws(bw, "Browser.setWindowBounds",
                      {"windowId": window_id, "bounds": {"windowState": "normal"}})
    return f"окно {window_id} активировано"


@T("browser_window_set_bounds", "Изменить размер/позицию окна", [P("window_id", "integer", desc="id окна"), P("left", "integer", desc="left", required=False, default=0), P("top", "integer", desc="top", required=False, default=0), P("width", "integer", desc="ширина", required=False, default=1280), P("height", "integer", desc="высота", required=False, default=800)], C)
async def _(ctx, window_id, left, top, width, height):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    from .. import bridge
    if bridge.online():
        await bridge.call({"cmd": "winset", "windowId": window_id,
                           "bounds": {"left": left, "top": top, "width": width, "height": height}})
        return "окно перемещено/изменено"
    bw = await cdp.browser_ws()
    await cdp._cmd_ws(bw, "Browser.setWindowBounds",
                      {"windowId": window_id, "bounds": {"left": left, "top": top, "width": width, "height": height}})
    return "окно перемещено/изменено"


@T("browser_enable_debug_shortcut", "ОДИН РАЗ прописать --remote-debugging-port=9222 в ярлыки Chrome (на Chrome 136+ работает только с НЕдефолтным профилем; основной способ - расширение extension/ или галка chrome://inspect)", [], C, core=True)
async def _(ctx):
    if os.name != "nt":
        return ToolResult(False, "только Windows; на Linux/mac используй расширение extension/ или chrome://inspect")
    ps = """
$ws = New-Object -ComObject WScript.Shell
$dirs = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
  (Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs'),
  (Join-Path $env:ProgramData 'Microsoft\\Windows\\Start Menu\\Programs'))
$fixed = 0
foreach ($d in $dirs) {
  if (-not (Test-Path $d)) { continue }
  Get-ChildItem -Path $d -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {
    $l = $ws.CreateShortcut($_.FullName)
    if ($l.TargetPath -like '*chrome.exe*' -and $l.Arguments -notlike '*remote-debugging-port*') {
      $l.Arguments = ($l.Arguments + ' --remote-debugging-port=9222').Trim()
      $l.Save(); $fixed++
    }
  }
}
$fixed
"""
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True)
    n = (r.stdout or "").strip()
    if n and n != "0":
        return f"флаг прописан в ярлыков: {n}. ВАЖНО: на Chrome 136+ флаг работает только с отдельным профилем; для твоего основного профиля поставь галку в chrome://inspect/#remote-debugging или установи расширение extension/"
    return ToolResult(False, "ярлыки Chrome не найдены/уже с флагом. Лучший способ: установить расширение extension/ (chrome://extensions -> загрузить распакованное)")


@T("browser_restart_user", "ПЕРЕЗАПУСТИТЬ Chrome пользователя с debug-портом и реставрацией вкладок. ВЫЗЫВАТЬ ТОЛЬКО если пользователь САМ попросил перезапустить браузер!", [], C)
async def _(ctx):
    ok = await cdp.restart_user_browser()
    if ok:
        tabs = await cdp.targets()
        return ToolResult(True, f"твой Chrome перезапущен с debug-портом, вкладок восстановлено: {len(tabs)}")
    return ToolResult(False, "не вышло перезапустить Chrome (не найден или не поднялся порт)")


@T("browser_launch", "Подключиться к браузеру (мост расширения или CDP). НИЧЕГО не закрывает: живой Chrome трогается только через browser_restart_user по твоей просьбе", [], C, core=True)
async def _(ctx):
    from .. import bridge
    if await bus.ensure():
        tr = bus.transport()
        tabs = await bus.targets()
        return ToolResult(True, f"подключено ({tr}): вкладок видно {len(tabs)}")
    return ToolResult(False, cdp.FRIENDLY_HINT)


@T("browser_tab_console_errors", "Ошибки консоли страницы (слушаем новые + последние)", [P("tab", desc="id вкладки")], C)
async def _(ctx, tab):
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    await bus.evaluate(tab, """
      (window.__fluxErrors || (window.__fluxErrors = [], window.addEventListener('error',
        e => window.__fluxErrors.push(e.message)), window.__fluxErrors))""")
    errs = await bus.evaluate(tab, "window.__fluxErrors ? window.__fluxErrors.slice(-20) : []")
    return json.dumps(errs, ensure_ascii=False) or "ошибок нет (слушаем новые)"


@T("browser_tab_download_text", "Скачать текстовое содержимое URL и вернуть", [P("url", desc="URL")], C)
async def _(ctx, url):
    import aiohttp
    async with aiohttp.ClientSession() as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=30)) as r:
            return (await r.text())[:6000]
