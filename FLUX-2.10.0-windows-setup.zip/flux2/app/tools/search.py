"""Поиск: движки (авто-гуглинг) + вертикали знаний (26)."""
from __future__ import annotations

import html as _html
import json
import re

import aiohttp

from ..config import CONFIG
from .registry import P, REG, ToolResult

C = "search"
T = REG.tool
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"}


def _clean(s: str) -> str:
    s = re.sub(r"<[^>]+>", "", s or "")
    return _html.unescape(s).strip()


async def _get(url, **kw):
    async with aiohttp.ClientSession(headers=UA) as s:
        async with s.get(url, timeout=aiohttp.ClientTimeout(total=20), **kw) as r:
            return r.status, await r.text()


def _fmt(items) -> str:
    return "\n".join(f"- {i['title']}\n  {i['url']}\n  {i['snippet'][:220]}" for i in items) or "ничего не найдено"


async def duckduckgo(q: str, n: int = 6):
    st, txt = await _get(f"https://html.duckduckgo.com/html/?q={q}")
    blocks = re.findall(r'<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)</a>.*?(?:<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)</a>)?', txt)
    out = []
    for href, title, snip in blocks[:n]:
        m = re.search(r"uddg=([^&]+)", href)
        out.append({"title": _clean(title), "url": m.group(1) if m else href, "snippet": _clean(snip)})
    return out


async def bing(q: str, n: int = 6):
    st, txt = await _get(f"https://www.bing.com/search?q={q}&setlang=ru")
    out = []
    for m in re.finditer(r'<li class="b_algo".*?<h2><a href="([^"]+)".*?>([\s\S]*?)</a></h2>([\s\S]*?)</li>', txt):
        out.append({"title": _clean(m.group(2)), "url": m.group(1), "snippet": _clean(re.sub(r"<[^>]+>", " ", m.group(3)))})
        if len(out) >= n:
            break
    return out


async def google(q: str, n: int = 6):
    st, txt = await _get(f"https://www.google.com/search?q={q}&num={n}&hl=ru")
    out = []
    for m in re.finditer(r'<a href="/url\?q=([^&"]+)[^"]*"[^>]*>([\s\S]*?)</a>', txt):
        title = _clean(m.group(2))
        if len(title) > 12:
            out.append({"title": title, "url": m.group(1), "snippet": ""})
        if len(out) >= n:
            break
    return out


async def searxng(q: str, n: int = 6):
    base = CONFIG.settings.get("searxng_url", "http://localhost:8888").rstrip("/")
    st, txt = await _get(f"{base}/search?q={q}&format=json")
    if st != 200:
        raise RuntimeError(f"searxng {st}")
    d = json.loads(txt)
    return [{"title": r.get("title", ""), "url": r.get("url", ""), "snippet": r.get("content", "")} for r in d.get("results", [])[:n]]


async def brave(q: str, n: int = 6):
    key = CONFIG.settings.get("brave_key", "")
    if not key:
        raise RuntimeError("нет brave_key в настройках")
    async with aiohttp.ClientSession(headers={"X-Subscription-Token": key, "Accept": "application/json"}) as s:
        async with s.get(f"https://api.search.brave.com/res/v1/web/search?q={q}&count={n}",
                         timeout=aiohttp.ClientTimeout(total=20)) as r:
            d = await r.json()
    return [{"title": x.get("title", ""), "url": x.get("url", ""), "snippet": x.get("description", "")}
            for x in d.get("web", {}).get("results", [])[:n]]


async def wikipedia(q: str, n: int = 6):
    st, txt = await _get(f"https://ru.wikipedia.org/w/api.php?action=opensearch&search={q}&limit={n}&format=json")
    if st != 200:
        st, txt = await _get(f"https://en.wikipedia.org/w/api.php?action=opensearch&search={q}&limit={n}&format=json")
    try:
        d = json.loads(txt)
    except Exception:
        return []
    if not isinstance(d, list) or len(d) < 4:
        return []
    return [{"title": t, "url": u, "snippet": sn} for t, u, sn in zip(d[1], d[3], d[2])]


ENGINES = {
    "duckduckgo": duckduckgo, "bing": bing, "google": google,
    "searxng": searxng, "brave": brave, "wikipedia": wikipedia,
}


async def run_engine(engine: str, q: str, n: int = 6):
    if engine == "off":
        return []
    fn = ENGINES.get(engine, duckduckgo)
    return await fn(q, n)


@T("web_search", "Поиск в интернете движком из настроек (авто-гуглинг)", [P("query", desc="запрос"), P("n", "integer", desc="результатов", required=False, default=6)], C, core=True)
async def _(ctx, query, n):
    engine = CONFIG.settings.get("search_engine", "duckduckgo")
    items = await run_engine(engine, query, n)
    return f"[движок: {engine}]\n{_fmt(items)}"


for _eng in ENGINES:
    def _mk(eng):
        async def handler(ctx, query, n=6):
            return _fmt(await run_engine(eng, query, n))
        return handler
    T(f"web_search_{_eng}", f"Поиск движком {_eng} напрямую", [P("query", desc="запрос"), P("n", "integer", desc="результатов", required=False, default=6)], C)(_mk(_eng))


@T("wiki_summary", "Краткая сводка Википедии по теме", [P("topic", desc="тема")], C, core=True)
async def _(ctx, topic):
    st, txt = await _get(f"https://ru.wikipedia.org/api/rest_v1/page/summary/{topic}")
    if st != 200:
        st, txt = await _get(f"https://en.wikipedia.org/api/rest_v1/page/summary/{topic}")
    d = json.loads(txt)
    return f"{d.get('title')}\n{d.get('extract', '')}\n{d.get('content_urls', {}).get('desktop', {}).get('page', '')}"


@T("wiki_search", "Поиск статей Википедии", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    return _fmt(await wikipedia(query, n))


@T("arxiv_search", "Поиск научных статей arXiv", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    st, txt = await _get(f"http://export.arxiv.org/api/query?search_query=all:{query}&max_results={n}")
    out = []
    for m in re.finditer(r"<entry>([\s\S]*?)</entry>", txt):
        e = m.group(1)
        out.append({"title": _clean(re.search(r"<title>([\s\S]*?)</title>", e).group(1)),
                    "url": re.search(r"<id>(.*?)</id>", e).group(1),
                    "snippet": _clean(re.search(r"<summary>([\s\S]*?)</summary>", e).group(1))[:200]})
    return _fmt(out)


@T("crossref_search", "Поиск научных публикаций Crossref", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    st, txt = await _get(f"https://api.crossref.org/works?query={query}&rows={n}")
    d = json.loads(txt)
    out = [{"title": (i.get("title") or ["?"])[0], "url": i.get("URL", ""),
            "snippet": f"{i.get('published', {}).get('date-parts', [['?']])[0][0]} citations={i.get('is-referenced-by-count', 0)}"}
           for i in d.get("message", {}).get("items", [])]
    return _fmt(out)


@T("pubmed_search", "Поиск биомедицинских публикаций PubMed", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    st, txt = await _get(f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={query}&retmax={n}&retmode=json")
    ids = json.loads(txt).get("esearchresult", {}).get("idlist", [])
    if not ids:
        return "не найдено"
    st, txt = await _get(f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id={','.join(ids)}&retmode=json")
    d = json.loads(txt).get("result", {})
    return "\n".join(f"- {d[i]['title']} (PMID {i}, {d[i].get('pubdate','')})" for i in ids)


@T("github_search", "Поиск репозиториев GitHub", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    st, txt = await _get(f"https://api.github.com/search/repositories?q={q_escape(query)}&per_page={n}")
    d = json.loads(txt)
    return _fmt([{"title": i["full_name"] + f" ★{i['stargazers_count']}", "url": i["html_url"],
                  "snippet": i.get("description") or ""} for i in d.get("items", [])])


def q_escape(q: str) -> str:
    from urllib.parse import quote
    return quote(q)


@T("stackoverflow_search", "Поиск вопросов Stack Overflow", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    st, txt = await _get(f"https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=votes&q={q_escape(query)}&site=stackoverflow&pagesize={n}")
    d = json.loads(txt)
    return _fmt([{"title": _html.unescape(i["title"]), "url": i["link"],
                  "snippet": f"votes={i['score']} answers={i['answer_count']}"} for i in d.get("items", [])])


@T("hackernews_top", "Топ новостей Hacker News", [P("n", "integer", desc="сколько", required=False, default=10)], C)
async def _(ctx, n):
    st, txt = await _get("https://hacker-news.firebaseio.com/v0/topstories.json")
    ids = json.loads(txt)[:n]
    out = []
    for i in ids:
        st, t2 = await _get(f"https://hacker-news.firebaseio.com/v0/item/{i}.json")
        d = json.loads(t2)
        out.append(f"- {d.get('title')} ({d.get('score')} очков) {d.get('url', '')}")
    return "\n".join(out)


@T("reddit_search", "Поиск постов Reddit", [P("query", desc="запрос"), P("n", "integer", desc="сколько", required=False, default=5)], C)
async def _(ctx, query, n):
    st, txt = await _get(f"https://www.reddit.com/search.json?q={q_escape(query)}&limit={n}", headers=UA)
    d = json.loads(txt)
    return _fmt([{"title": c["data"]["title"], "url": "https://reddit.com" + c["data"]["permalink"],
                  "snippet": f"r/{c['data']['subreddit']} score={c['data']['score']}"} for c in d.get("data", {}).get("children", [])])


@T("geocode", "Адрес/место -> координаты (Nominatim)", [P("place", desc="место")], C)
async def _(ctx, place):
    st, txt = await _get(f"https://nominatim.openstreetmap.org/search?q={q_escape(place)}&format=json&limit=1")
    d = json.loads(txt)
    return f"lat={d[0]['lat']} lon={d[0]['lon']} :: {d[0]['display_name']}" if d else "не найдено"


@T("reverse_geocode", "Координаты -> адрес (Nominatim)", [P("lat", "number", desc="широта"), P("lon", "number", desc="долгота")], C)
async def _(ctx, lat, lon):
    st, txt = await _get(f"https://nominatim.openstreetmap.org/reverse?lat={lat}&lon={lon}&format=json")
    d = json.loads(txt)
    return d.get("display_name", "не найдено")


@T("weather_now", "Погода сейчас в месте (open-meteo, без ключа)", [P("place", desc="город/место")], C, core=True)
async def _(ctx, place):
    st, txt = await _get(f"https://geocoding-api.open-meteo.com/v1/search?name={q_escape(place)}&count=1&language=ru")
    g = (json.loads(txt).get("results") or [{}])[0]
    if not g.get("latitude"):
        return "место не найдено"
    st, txt = await _get(f"https://api.open-meteo.com/v1/forecast?latitude={g['latitude']}&longitude={g['longitude']}&current_weather=true")
    w = json.loads(txt).get("current_weather", {})
    return f"{g.get('name')}: {w.get('temperature')}°C, ветер {w.get('windspeed')} км/ч, код погоды {w.get('weathercode')}"


@T("weather_forecast", "Прогноз погоды на 7 дней (open-meteo)", [P("place", desc="город/место")], C)
async def _(ctx, place):
    st, txt = await _get(f"https://geocoding-api.open-meteo.com/v1/search?name={q_escape(place)}&count=1&language=ru")
    g = (json.loads(txt).get("results") or [{}])[0]
    if not g.get("latitude"):
        return "место не найдено"
    st, txt = await _get(f"https://api.open-meteo.com/v1/forecast?latitude={g['latitude']}&longitude={g['longitude']}&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=7")
    d = json.loads(txt).get("daily", {})
    return "\n".join(f"{d['time'][i]}: {d['temperature_2m_min'][i]}..{d['temperature_2m_max'][i]}°C осадки {d['precipitation_probability_max'][i]}%"
                     for i in range(len(d.get("time", []))))


@T("exchange_rates", "Курсы валют ЦБ-независимо (open.er-api.com)", [P("base", desc="код базы", required=False, default="USD")], C)
async def _(ctx, base):
    st, txt = await _get(f"https://open.er-api.com/v6/latest/{base}")
    d = json.loads(txt)
    r = d.get("rates", {})
    pick = {k: r[k] for k in ("RUB", "EUR", "CNY", "KZT", "UAH", "BYN", "GBP", "JPY") if k in r}
    return f"база {base} ({d.get('time_last_update_utc','')}): " + ", ".join(f"{k}={v}" for k, v in pick.items())


@T("crypto_price", "Цена криптовалюты (CoinGecko)", [P("coin", desc="id монеты", required=False, default="bitcoin"), P("currency", desc="валюта", required=False, default="usd")], C)
async def _(ctx, coin, currency):
    st, txt = await _get(f"https://api.coingecko.com/api/v3/simple/price?ids={coin}&vs_currencies={currency}&include_24hr_change=true")
    d = json.loads(txt).get(coin, {})
    return f"{coin}: {d.get(currency)} {currency} (24h: {d.get(f'{currency}_24h_change', 0):.2f}%)" if d else "монета не найдена"


@T("dictionary_word", "Толкование слова (free dictionary: en + ru fallback)", [P("word", desc="слово")], C)
async def _(ctx, word):
    st, txt = await _get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{q_escape(word)}")
    if st == 200:
        d = json.loads(txt)[0]
        means = [m.get("definitions", [{}])[0].get("definition", "") for m in d.get("meanings", [])[:3]]
        return f"{d.get('word')} [{d.get('phonetic','')}]: " + "; ".join(means)
    st, txt = await _get(f"https://ru.wiktionary.org/api/rest_v1/page/summary/{q_escape(word)}")
    if st == 200:
        d = json.loads(txt)
        return d.get("extract", "не найдено")
    return "не найдено"


@T("translate_text", "Перевод текста (MyMemory, без ключа)", [P("text", desc="текст"), P("src", desc="язык от", required=False, default="ru"), P("dst", desc="язык в", required=False, default="en")], C, core=True)
async def _(ctx, text, src, dst):
    st, txt = await _get(f"https://api.mymemory.translated.net/get?q={q_escape(text[:450])}&langpair={src}|{dst}")
    d = json.loads(txt)
    return d.get("responseData", {}).get("translatedText", "ошибка перевода")
