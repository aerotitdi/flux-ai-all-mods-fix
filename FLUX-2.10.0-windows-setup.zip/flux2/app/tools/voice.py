"""Голос: микрофон, распознавание, голос Flux (TTS) (10)."""
from __future__ import annotations

import json

from .. import voicelab
from ..config import CONFIG
from .registry import P, REG, ToolResult

C = "voice"
T = REG.tool


@T("voice_mics_list", "Список микрофонов системы", [], C)
def _(ctx):
    mics = voicelab.list_mics()
    if not mics:
        return "микрофоны не видны с бэкенда (в окне/браузере микрофон выбирается в настройках голоса); поставь sounddevice для консоли"
    cur = CONFIG.voice.get("mic_id", "")
    return "\n".join(f"{'*' if m['id'] == cur else ' '} {m['id']}: {m['name']}" for m in mics)


@T("voice_set_mic", "Выбрать микрофон по id", [P("mic_id", desc="id устройства")], C)
def _(ctx, mic_id):
    CONFIG.voice["mic_id"] = mic_id
    CONFIG.save()
    return f"микрофон: {mic_id}"


@T("voice_tts_voices", "Список голосов Flux (Edge TTS), фильтр по языку", [P("lang", desc="префикс языка", required=False, default="ru")], C)
def _(ctx, lang):
    vs = voicelab.voice_list()
    return "\n".join(f"{v['short']} ({v['gender']})" for v in vs if v["short"].lower().startswith((lang or "").lower()))[:4000]


@T("voice_set_voice", "Выбрать голос Flux", [P("voice", desc="имя голоса, напр. ru-RU-DmitryNeural")], C)
def _(ctx, voice):
    CONFIG.voice["voice"] = voice
    CONFIG.save()
    return f"голос: {voice}"


@T("voice_speak", "Озвучить текст голосом Flux", [P("text", desc="текст"), P("voice", desc="голос (опц.)", required=False, default="")], C, core=True)
async def _(ctx, text, voice):
    path = await voicelab.synth_to_file(text, voice or CONFIG.voice.get("voice"))
    if not path:
        return ToolResult(False, "TTS-движок недоступен (нужен edge-tts или браузерный режим)")
    return ToolResult(True, f"озвучено: {path}", data={"audio": path})


@T("voice_stop", "Остановить озвучку (флаг для UI)", [], C)
def _(ctx):
    return "stop-signal: UI остановит воспроизведение"


@T("voice_set_rate", "Скорость голоса Flux (-50..+50 %)", [P("rate", "integer", desc="проценты")], C)
def _(ctx, rate):
    CONFIG.voice["rate"] = max(-50, min(50, rate))
    CONFIG.save()
    return f"скорость: {CONFIG.voice['rate']}%"


@T("voice_set_pitch", "Тон голоса Flux (-20..+20 Hz)", [P("pitch", "integer", desc="герцы")], C)
def _(ctx, pitch):
    CONFIG.voice["pitch"] = max(-20, min(20, pitch))
    CONFIG.save()
    return f"тон: {CONFIG.voice['pitch']}Hz"


@T("voice_stt_modes", "Текущий режим распознавания речи и доступные", [], C)
def _(ctx):
    return f"текущий={CONFIG.settings.get('stt_mode')} ; варианты: auto|browser|provider|whisper"


@T("voice_test", "Самотест голосового тракта: синтез тестовой фразы", [], C)
async def _(ctx):
    path = await voicelab.synth_to_file("Флюкс на связи, голосовой тракт работает.")
    return ToolResult(bool(path), f"тест: {path or 'TTS недоступен'}", data={"audio": path} if path else {})
