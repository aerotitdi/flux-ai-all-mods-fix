"""Медиа: «Флюкс, поставь на паузу» — в ЛЮБОМ приложении, не только в браузере.

Три уровня, выбираются автоматически (target=auto):

1) **GSMTCS** (Global System Media Transport Controls) — системный реестр плееров
   Windows. Через него видно и управляется ВСЁ, что зарегистрировалось в ОС:
   Chrome/Edge, Spotify, Яндекс Музыка (десктоп), VK Музыка, плеер Windows,
   Winamp и т.д. Даёт название трека, исполнителя, альбом, состояние и позицию.
   Доступ через WinRT в СКРЫТОМ PowerShell (app/winproc.py) — окно не появляется.

2) **Медиа-клавиши** через SendInput (VK_MEDIA_PLAY_PAUSE и т.п.) — фолбэк для
   плееров, которые не зарегистрированы в GSMTCS. Работает глобально, как нажатие кнопки на
   клавиатуре.

3) **Страница браузера** — browser_media_control из app/tools/page.py (когда нужно
   управлять конкретной вкладкой: YouTube, Яндекс Музыка в браузере, VK).

СОБСТВЕННЫЙ ПЛЕЕР FLUX («включи музыку у себя, а не в браузере»):
проигрывание идёт ВНУТРИ окна FLUX через <audio> в ui/index.html (событие SSE
`player`). Поддерживает плейлист, повтор трека/списка и громкость — никакого
внешнего приложения не запускается. Источники:
  * локальные файлы (music_dir, иначе «Музыка» пользователя) — сканируются;
  * прямые URL на аудиофайл;
  * сервисы (YouTube Music / Яндекс Музыка / VK Музыка) — ОТКРЫВАЮТСЯ и дальше
    управляются через media/browser_media_control. Выдирать защищённые потоки
    из этих сервисов мы не будем: это нарушение их условий и DRM, а управление
    плеером и так работает штатно.
"""
from __future__ import annotations

import ctypes
import json
import os
import random
import shutil
import sys
import time
from typing import Optional

from .. import events, winproc
from ..config import CONFIG, app_dir
from .registry import P, REG, ToolResult

C = "media"
T = REG.tool

NT = sys.platform == "win32"
MAC = sys.platform == "darwin"
AUDIO_EXT = (".mp3", ".flac", ".wav", ".m4a", ".aac", ".ogg", ".opus", ".wma", ".aiff")

# клавиши мультимедиа (виртуальные коды Windows)
VK_MEDIA = {"next": 0xB0, "prev": 0xB1, "stop": 0xB2, "play_pause": 0xB3,
            "mute": 0xAD, "vol_down": 0xAE, "vol_up": 0xAF}


# =========================================================== GSMTCS (WinRT)
_GSMTCS_PS = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}
[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Control.GlobalSystemMediaTransportControlsSession,Windows.Media.Control,ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Control.GlobalSystemMediaTransportControlsMediaProperties,Windows.Media.Control,ContentType=WindowsRuntime] | Out-Null
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])

function DumpSession($s) {
  $props = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsMediaProperties])
  $pb = $s.GetPlaybackInfo()
  $tl = $s.GetTimelineProperties()
  [pscustomobject]@{
    app        = $s.SourceAppUserModelId
    title      = $props.Title
    artist     = $props.Artist
    album      = $props.Album
    track      = $props.TrackNumber
    status     = [string]$pb.PlaybackStatus
    position_s = [math]::Round($tl.Position.TotalSeconds, 1)
    duration_s = [math]::Round($tl.EndTime.TotalSeconds, 1)
    canPlay    = $pb.Controls.IsPlayEnabled
    canPause   = $pb.Controls.IsPauseEnabled
    canNext    = $pb.Controls.IsNextEnabled
    canPrev    = $pb.Controls.IsPreviousEnabled
  }
}

$action = $a0
if ($action -eq 'list' -or $action -eq 'status') {
  $sessions = @($mgr.GetSessions())
  if ($sessions.Count -eq 0) { Write-Output '{"sessions":[]}'; exit 0 }
  $out = @()
  foreach ($s in $sessions) { try { $out += DumpSession $s } catch {} }
  if ($action -eq 'status') {
    $cur = $mgr.GetCurrentSession()
    $now = $null
    if ($cur) { try { $now = DumpSession $cur } catch {} }
    Write-Output (@{current = $now; sessions = $out} | ConvertTo-Json -Depth 5 -Compress)
  } else {
    Write-Output (@{sessions = $out} | ConvertTo-Json -Depth 5 -Compress)
  }
  exit 0
}

$s = $mgr.GetCurrentSession()
if (-not $s) { Write-Output '{"ok":false,"err":"нет активного плеера в системе (GSMTCS пуст)"}'; exit 0 }
$map = @{ play='TryPlayAsync'; pause='TryPauseAsync'; toggle='TryTogglePlayPauseAsync';
          stop='TryStopAsync'; next='TrySkipNextAsync'; prev='TrySkipPreviousAsync' }
if (-not $map.ContainsKey($action)) { Write-Output ('{"ok":false,"err":"неизвестное действие"}'); exit 0 }
$res = Await ($s.($map[$action])()) ([System.Boolean])
$info = DumpSession $s
Write-Output (@{ok = [bool]$res; action = $action; after = $info} | ConvertTo-Json -Depth 5 -Compress)
"""


def gsmtcs(action: str, timeout: float = 20.0) -> dict:
    """Вызов GSMTCS через скрытый PowerShell. action: status|list|play|pause|toggle|stop|next|prev."""
    if not NT:
        return {"ok": False, "err": "GSMTCS доступен только в Windows"}
    out = winproc.ps(_GSMTCS_PS, args=[action], timeout=timeout)
    if not out:
        return {"ok": False, "err": "WinRT не ответил (Windows 10 1809+?)"}
    try:
        return json.loads(out)
    except Exception:
        return {"ok": False, "err": "не разобрать ответ", "raw": out[:300]}


# =========================================================== медиа-клавиши
def send_media_key(name: str, repeat: int = 1) -> bool:
    """Нажать мультимедийную клавишу (SendInput). Работает глобально."""
    vk = VK_MEDIA.get(name)
    if not vk:
        return False
    if NT:
        try:
            u32 = ctypes.windll.user32

            class KEYBDINPUT(ctypes.Structure):
                _fields_ = [("wVk", ctypes.wintypes.WORD), ("wScan", ctypes.wintypes.WORD),
                            ("dwFlags", ctypes.wintypes.DWORD), ("time", ctypes.wintypes.DWORD),
                            ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]

            class INPUT(ctypes.Structure):
                class _U(ctypes.Union):
                    _fields_ = [("ki", KEYBDINPUT), ("pad", ctypes.c_byte * 24)]
                _fields_ = [("type", ctypes.wintypes.DWORD), ("u", _U)]

            KEYEVENTF_KEYUP = 0x0002
            u32.SendInput.argtypes = [ctypes.wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
            for _ in range(max(1, repeat)):
                arr = (INPUT * 2)()
                arr[0].type = 1
                arr[0].u.ki.wVk = vk
                arr[1].type = 1
                arr[1].u.ki.wVk = vk
                arr[1].u.ki.dwFlags = KEYEVENTF_KEYUP
                u32.SendInput(2, arr, ctypes.sizeof(INPUT))
                time.sleep(0.06)
            return True
        except Exception:
            return False
    if MAC:
        return False
    # Linux: playerctl / dbus MPRIS
    for exe in ("playerctl",):
        if shutil.which(exe):
            cmd = {"play_pause": "play-pause", "next": "next", "prev": "previous",
                   "stop": "stop"}.get(name)
            if cmd:
                try:
                    winproc.run([exe, cmd], timeout=8)
                    return True
                except Exception:
                    pass
    return False


def system_volume(delta: Optional[int] = None, level: Optional[int] = None,
                  mute: Optional[bool] = None) -> dict:
    """Громкость. Точная установка — через pycaw (если есть), иначе шагами клавишами."""
    if mute is not None and NT:
        send_media_key("mute", 1)
        return {"ok": True, "method": "media-key", "mute": mute}
    try:
        from ctypes import POINTER, cast
        import comtypes                                    # pycaw требует comtypes
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        dev = AudioUtilities.GetSpeakers()
        iface = dev.Activate(IAudioEndpointVolume._iid_, comtypes.CLSCTX_ALL, None)
        vol = cast(iface, POINTER(IAudioEndpointVolume))
        if mute is not None:
            vol.SetMute(1 if mute else 0, None)
        if level is not None:
            vol.SetMasterVolumeLevelScalar(max(0.0, min(1.0, level / 100.0)), None)
        elif delta:
            cur = vol.GetMasterVolumeLevelScalar()
            vol.SetMasterVolumeLevelScalar(max(0.0, min(1.0, cur + delta / 100.0)), None)
        return {"ok": True, "method": "pycaw",
                "level": round(vol.GetMasterVolumeLevelScalar() * 100),
                "muted": bool(vol.GetMute())}
    except Exception:
        pass
    steps = abs(level - 50) // 2 if level is not None else abs(delta or 10) // 2
    key = "vol_up" if (delta or 0) > 0 or (level or 0) > 50 else "vol_down"
    for _ in range(max(1, min(steps, 25))):
        send_media_key(key)
    return {"ok": True, "method": "media-keys (поставь pycaw для точной установки)",
            "pressed": key, "times": max(1, min(steps, 25))}


# =========================================================== собственный плеер
def music_dir() -> str:
    d = (CONFIG.settings.get("music_dir") or "").strip()
    if d and os.path.isdir(d):
        return d
    home = os.path.expanduser("~")
    for cand in (os.path.join(home, "Music"), os.path.join(home, "Музыка"),
                 os.path.join(home, "Downloads")):
        if os.path.isdir(cand):
            return cand
    return home


def scan_library(limit: int = 400) -> list[dict]:
    """Рекурсивно собирает аудиофайлы из каталога фонотеки."""
    root = music_dir()
    out: list[dict] = []
    skip = {".git", "__pycache__", "node_modules", ".venv", "appdata", "$recycle.bin"}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d.lower() not in skip and not d.startswith(".")]
        for fn in filenames:
            if not fn.lower().endswith(AUDIO_EXT):
                continue
            p = os.path.join(dirpath, fn)
            try:
                st = os.stat(p)
            except OSError:
                continue
            out.append({"path": p, "name": os.path.splitext(fn)[0],
                        "folder": os.path.basename(dirpath),
                        "mb": round(st.st_size / 1048576, 1)})
            if len(out) >= limit:
                return out
    return out


SERVICES = {
    "youtube": {"name": "YouTube Music", "search": "https://music.youtube.com/search?q={q}",
                "home": "https://music.youtube.com"},
    "yandex": {"name": "Яндекс Музыка", "search": "https://music.yandex.ru/search?text={q}",
               "home": "https://music.yandex.ru"},
    "vk": {"name": "VK Музыка", "search": "https://vk.com/audio?q={q}", "home": "https://vk.com/audio"},
    "spotify": {"name": "Spotify", "search": "https://open.spotify.com/search/{q}",
                "home": "https://open.spotify.com"},
    "youtube_site": {"name": "YouTube", "search": "https://www.youtube.com/results?search_query={q}",
                     "home": "https://www.youtube.com"},
}


def _player_event(action: str, **kw) -> dict:
    """Команда собственному плееру FLUX (окно играет её через <audio>)."""
    return events.publish({"type": "player", "action": action, **kw})


# =========================================================== ТУЛЗЫ
@T("media_status",
   "Что сейчас играет в системе: трек, исполнитель, альбом, плеер-приложение, позиция, "
   "длительность + все зарегистрированные плееры. Работает для Chrome/Edge/Spotify/"
   "Яндекс Музыки/VK Музыки и любого приложения с медиа-клавишами.",
   [P("include_browser", "boolean", desc="добавить вкладки браузера с видео/аудио",
      required=False, default=True)], C, core=True)
async def _(ctx, include_browser):
    lines: list[str] = []
    data: dict = {}
    if NT:
        g = gsmtcs("status")
        data["system"] = g
        cur = g.get("current")
        if cur:
            pos = f"{cur.get('position_s', 0)}/{cur.get('duration_s', 0)}с"
            lines.append(f"СЕЙЧАС В СИСТЕМЕ: {cur.get('status', '?')} — "
                         f"{cur.get('title') or '(без названия)'}"
                         f"{(' · ' + cur['artist']) if cur.get('artist') else ''}"
                         f"{(' · ' + cur['album']) if cur.get('album') else ''} | {pos}")
            lines.append(f"плеер: {cur.get('app', '?')} | доступно: "
                         f"{'play ' if cur.get('canPlay') else ''}"
                         f"{'pause ' if cur.get('canPause') else ''}"
                         f"{'next ' if cur.get('canNext') else ''}"
                         f"{'prev' if cur.get('canPrev') else ''}".strip())
        else:
            lines.append(f"в системе ничего не играет ({g.get('err') or 'GSMTCS пуст'})")
        sess = g.get("sessions") or []
        if len(sess) > 1:
            def _appname(s: dict) -> str:
                a = str(s.get("app") or "?")
                return a.split("!")[0].split("\\")[-1]
            lines.append("другие плееры: "
                         + "; ".join(f"{_appname(s)}={s.get('status')}" for s in sess[1:6]))
    else:
        if shutil.which("playerctl"):
            try:
                out = winproc.run(["playerctl", "--list-all"], timeout=8).stdout
                lines.append(f"плееры (playerctl): {(out or '').strip()[:300] or 'нет'}")
                meta = winproc.run(["playerctl", "metadata"], timeout=8).stdout
                if meta:
                    lines.append("метаданные: " + meta.strip()[:300])
            except Exception:
                pass
        else:
            lines.append("системный медиа-реестр недоступен на этой ОС (нужен Windows или playerctl)")

    if include_browser:
        try:
            from .. import browserbus as bus
            if await bus.ensure():
                tabs = await bus.targets()
                for t in tabs[:12]:
                    url = (t.get("url") or "").lower()
                    if not any(k in url for k in ("youtube", "music", "vk.com/audio",
                                                  "spotify", "twitch", "netflix", "kinopoisk")):
                        continue
                    try:
                        st = await bus.evaluate(str(t["id"]),
                                                "(() => { const m = document.querySelector('video,audio');"
                                                " return m ? {p: m.paused, t: Math.round(m.currentTime),"
                                                " d: Math.round(m.duration||0), v: Math.round(m.volume*100)} : null })()")
                    except Exception:
                        st = None
                    if st:
                        lines.append(f"ВКЛАДКА {t['id']} «{(t.get('title') or '')[:50]}»: "
                                     f"{'ПАУЗА' if st.get('p') else 'ИГРАЕТ'} "
                                     f"{st.get('t')}/{st.get('d')}с громк.{st.get('v')}%")
        except Exception:
            pass
    return ToolResult(True, "\n".join(lines) or "нет данных о воспроизведении", data=data)


@T("media_control",
   "Управление воспроизведением В СИСТЕМЕ (любой плеер: браузер, Spotify, Яндекс Музыка, "
   "VK Музыка, плеер Windows). action: play|pause|toggle|next|prev|stop|vol_up|vol_down|mute. "
   "Сначала системный транспорт (GSMTCS), при неудаче — медиа-клавиши.",
   [P("action", desc="play|pause|toggle|next|prev|stop|vol_up|vol_down|mute",
      required=False, default="toggle",
      enum=["play", "pause", "toggle", "next", "prev", "stop", "vol_up", "vol_down", "mute"]),
    P("volume", "integer", desc="точная громкость 0-100 (вместо vol_up/vol_down)",
      required=False, default=-1)], C, core=True)
def _(ctx, action, volume):
    act = (action or "toggle").lower()
    if volume is not None and int(volume) >= 0:
        r = system_volume(level=int(volume))
        return ToolResult(r.get("ok", False), f"громкость {volume}% ({r.get('method')})", data=r)
    if act in ("vol_up", "vol_down"):
        r = system_volume(delta=10 if act == "vol_up" else -10)
        return ToolResult(r.get("ok", False), f"{act} ({r.get('method')})", data=r)
    if act == "mute":
        r = system_volume(mute=True)
        return ToolResult(r.get("ok", False), "звук выключен", data=r)

    keymap = {"play": "play_pause", "pause": "play_pause", "toggle": "play_pause",
              "next": "next", "prev": "prev", "stop": "stop"}
    if NT:
        g = gsmtcs(act)
        if g.get("ok"):
            after = g.get("after") or {}
            return ToolResult(True, f"{act}: {after.get('status', '?')} — "
                                    f"{after.get('title') or '(без названия)'} "
                                    f"({after.get('app', '?')})", data=g)
        # GSMTCS не смог -> медиа-клавиша
        if send_media_key(keymap[act]):
            return ToolResult(True, f"{act} медиа-клавишей (плеер не в GSMTCS)",
                              data={"method": "media-key", "gsmtcs": g})
        return ToolResult(False, f"не удалось: {g.get('err')} и медиа-клавиша не сработала")
    if send_media_key(keymap[act]):
        return ToolResult(True, f"{act} через playerctl/медиа-клавишу")
    return ToolResult(False, "нет системного медиа-канала на этой ОС")


@T("media_open_service",
   "Открыть музыкальный/видео сервис и найти там трек или видео: youtube|youtube_site|yandex|vk|spotify. "
   "Сервис открывается в браузере, дальше управляется через media_control / browser_media_control.",
   [P("service", desc="youtube|youtube_site|yandex|vk|spotify",
      enum=list(SERVICES)),
    P("query", desc="что искать (пусто = главная страница)", required=False, default="")], C)
async def _(ctx, service, query):
    svc = SERVICES.get(service)
    if not svc:
        return ToolResult(False, f"неизвестный сервис: {service}. Доступны: {', '.join(SERVICES)}")
    import urllib.parse
    url = svc["home"] if not query.strip() else svc["search"].format(
        q=urllib.parse.quote(query.strip()))
    try:
        from .. import browserbus as bus
        tab = await bus.new_tab(url)
        return ToolResult(True, f"{svc['name']} открыт: {url}\nвкладка {tab}. "
                                f"Дальше: browser_page_snapshot -> browser_act(index=N), "
                                f"а управление звуком — media_control / browser_media_control.",
                          data={"tab": str(tab), "url": url, "service": service})
    except Exception as e:
        return ToolResult(False, f"не удалось открыть: {type(e).__name__}: {e}")


@T("music_play",
   "Включить музыку В САМОМ FLUX (собственный плеер в окне, без браузера и внешних программ). "
   "query — часть названия файла из фонотеки; пусто = случайный трек. "
   "loop=true зацикливает, playlist=true играет фонотеку подряд.",
   [P("query", desc="что ищем в фонотеке (пусто = случайный трек)", required=False, default=""),
    P("loop", "boolean", desc="зациклить трек", required=False, default=None),
    P("shuffle", "boolean", desc="перемешать плейлист", required=False, default=False),
    P("limit", "integer", desc="сколько треков положить в плейлист", required=False, default=20)], C, core=True)
def _(ctx, query, loop, shuffle, limit):
    lib = scan_library(400)
    if not lib:
        return ToolResult(False, f"в фонотеке {music_dir()} нет аудиофайлов "
                                 f"({', '.join(AUDIO_EXT)}). Задай каталог в настройках (music_dir) "
                                 f"или используй media_open_service для YouTube/Яндекс/VK Музыки.")
    q = (query or "").strip().lower()
    picks = [t for t in lib if q in t["name"].lower() or q in t["folder"].lower()] if q else list(lib)
    if not picks:
        sample = ", ".join(t["name"][:28] for t in lib[:12])
        return ToolResult(False, f"в фонотеке нет «{query}». Что есть: {sample}")
    if shuffle:
        random.shuffle(picks)
    picks = picks[: max(1, int(limit or 20))]
    if loop is None:
        loop = bool(CONFIG.settings.get("music_loop"))
    names = [os.path.basename(t["path"]) for t in picks]
    _player_event("play", files=names[:int(limit or 20)], loop=bool(loop),
                  shuffle=bool(shuffle), start=0)
    return ToolResult(True, f"играет в плеере FLUX: «{picks[0]['name']}»"
                            f"{' (зациклено)' if loop else ''}"
                            + (f" · плейлист {len(picks)} трек(ов)" if len(picks) > 1 else "")
                            + f"\nкаталог: {music_dir()}",
                      data={"tracks": picks[:20], "loop": bool(loop)})


@T("music_player_control",
   "Управление собственным плеером FLUX: play|pause|toggle|next|prev|stop|loop|shuffle|volume",
   [P("action", desc="play|pause|toggle|next|prev|stop|loop|shuffle|volume",
      enum=["play", "pause", "toggle", "next", "prev", "stop", "loop", "shuffle", "volume"]),
    P("value", "integer", desc="громкость 0-100 (для action=volume)", required=False, default=-1)], C)
def _(ctx, action, value):
    _player_event(action, value=int(value) if value is not None and int(value) >= 0 else None)
    return f"плеер FLUX: {action}" + (f" {value}%" if value is not None and int(value) >= 0 else "")


@T("music_library",
   "Что есть в фонотеке FLUX: список аудиофайлов (каталог music_dir или «Музыка» пользователя)",
   [P("filter", desc="фильтр по подстроке", required=False, default=""),
    P("limit", "integer", desc="сколько показать", required=False, default=40)], C)
def _(ctx, filter, limit):
    lib = scan_library(400)
    if filter:
        f = filter.lower()
        lib = [t for t in lib if f in t["name"].lower() or f in t["folder"].lower()]
    if not lib:
        return f"фонотека пуста (каталог: {music_dir()})"
    rows = [f"{t['name'][:50]}  [{t['folder'][:24]}]  {t['mb']} МБ"
            for t in lib[: max(1, int(limit or 40))]]
    return f"каталог: {music_dir()} · найдено {len(lib)}\n" + "\n".join(rows)


@T("media_info", "Диагностика медиа-подсистемы: GSMTCS, медиа-клавиши, pycaw, фонотека, сервисы",
   [], C)
def _(ctx):
    info: dict = {"platform": sys.platform,
                  "music_dir": music_dir(),
                  "library_size": len(scan_library(400)),
                  "services": {k: v["name"] for k, v in SERVICES.items()},
                  "player_loop": bool(CONFIG.settings.get("music_loop")),
                  "music_source": CONFIG.settings.get("music_source", "ask")}
    if NT:
        g = gsmtcs("list", timeout=15)
        info["gsmtcs"] = {"ok": bool(g.get("sessions") is not None),
                          "sessions": len(g.get("sessions") or []),
                          "err": g.get("err")}
        info["media_keys"] = "SendInput (VK_MEDIA_*)"
    else:
        info["playerctl"] = bool(shutil.which("playerctl"))
    try:
        import pycaw                                       # noqa: F401
        info["volume"] = "pycaw (точная установка громкости)"
    except Exception:
        info["volume"] = "медиа-клавиши шагами (поставь pycaw+comtypes для точной)"
    return json.dumps(info, ensure_ascii=False, default=str)
