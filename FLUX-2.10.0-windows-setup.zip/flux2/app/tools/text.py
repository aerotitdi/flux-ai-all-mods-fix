"""Текстовые инструменты (46)."""
from __future__ import annotations

import random
import re
from collections import Counter

from .registry import P, REG, ToolResult

C = "text"
T = REG.tool


def _lines(s): return [l for l in (s or "").split("\n")]


@T("text_upper", "Текст в ВЕРХНИЙ регистр", [P("text", desc="текст")], C)
def _(ctx, text): return text.upper()


@T("text_lower", "Текст в нижний регистр", [P("text", desc="текст")], C)
def _(ctx, text): return text.lower()


@T("text_title", "Каждое Слово С Заглавной", [P("text", desc="текст")], C)
def _(ctx, text): return text.title()


@T("text_capitalize", "Первая буква предложения заглавная", [P("text", desc="текст")], C)
def _(ctx, text): return text.capitalize()


@T("text_swapcase", "Инвертировать регистр символов", [P("text", desc="текст")], C)
def _(ctx, text): return text.swapcase()


@T("text_reverse", "Развернуть текст посимвольно", [P("text", desc="текст")], C)
def _(ctx, text): return text[::-1]


@T("text_reverse_words", "Развернуть порядок слов", [P("text", desc="текст")], C)
def _(ctx, text): return " ".join(text.split()[::-1])


@T("text_slug", "URL-slug из текста (translit-lite)", [P("text", desc="текст")], C)
def _(ctx, text):
    tbl = str.maketrans({"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "yo",
                         "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
                         "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
                         "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "",
                         "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya"})
    s = text.lower().translate(tbl)
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s


@T("text_camel", "строка в camelCase", [P("text", desc="текст")], C)
def _(ctx, text):
    parts = re.split(r"[^a-zA-Zа-яА-Я0-9]+", text)
    parts = [p for p in parts if p]
    return parts[0].lower() + "".join(p.capitalize() for p in parts[1:]) if parts else ""


@T("text_pascal", "строка в PascalCase", [P("text", desc="текст")], C)
def _(ctx, text):
    parts = [p for p in re.split(r"[^a-zA-Zа-яА-Я0-9]+", text) if p]
    return "".join(p.capitalize() for p in parts)


@T("text_snake", "строка в snake_case", [P("text", desc="текст")], C)
def _(ctx, text):
    s = re.sub(r"(?<!^)(?=[A-Z])", "_", text)
    return re.sub(r"[^a-zA-Zа-яА-Я0-9]+", "_", s).lower().strip("_")


@T("text_kebab", "строка в kebab-case", [P("text", desc="текст")], C)
def _(ctx, text):
    s = re.sub(r"(?<!^)(?=[A-Z])", "-", text)
    return re.sub(r"[^a-zA-Zа-яА-Я0-9]+", "-", s).lower().strip("-")


@T("text_strip", "Убрать пробелы по краям", [P("text", desc="текст")], C)
def _(ctx, text): return text.strip()


@T("text_trim_lines", "Убрать пробелы по краям каждой строки", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(l.strip() for l in _lines(text))


@T("text_collapse_spaces", "Сжать множественные пробелы в один", [P("text", desc="текст")], C)
def _(ctx, text): return re.sub(r"[ \t]+", " ", text)


@T("text_remove_empty_lines", "Удалить пустые строки", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(l for l in _lines(text) if l.strip())


@T("text_dedupe_lines", "Удалить дубликаты строк (с порядком)", [P("text", desc="текст")], C)
def _(ctx, text):
    seen, out = set(), []
    for l in _lines(text):
        if l not in seen:
            seen.add(l); out.append(l)
    return "\n".join(out)


@T("text_sort_lines", "Сортировать строки по возрастанию", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(sorted(_lines(text)))


@T("text_sort_lines_desc", "Сортировать строки по убыванию", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(sorted(_lines(text), reverse=True))


@T("text_shuffle_lines", "Перемешать строки случайно", [P("text", desc="текст")], C)
def _(ctx, text):
    ls = _lines(text); random.shuffle(ls); return "\n".join(ls)


@T("text_number_lines", "Пронумеровать строки", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(f"{i+1}. {l}" for i, l in enumerate(_lines(text)))


@T("text_count_words", "Число слов", [P("text", desc="текст")], C)
def _(ctx, text): return len(text.split())


@T("text_count_chars", "Число символов (и без пробелов)", [P("text", desc="текст")], C)
def _(ctx, text):
    n = len(re.sub(r"\s", "", text))
    return f"всего={len(text)} без_пробелов={n}"


@T("text_count_lines", "Число строк", [P("text", desc="текст")], C)
def _(ctx, text): return len(_lines(text))


@T("text_extract_emails", "Извлечь e-mail адреса", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(sorted(set(re.findall(r"[\w.+-]+@[\w-]+\.[\w.]+", text)))) or "не найдено"


@T("text_extract_urls", "Извлечь URL", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(sorted(set(re.findall(r"https?://[^\s<>\"')]+", text)))) or "не найдено"


@T("text_extract_phones", "Извлечь телефонные номера", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(sorted(set(re.findall(r"\+?\d[\d\s()-]{7,}\d", text)))) or "не найдено"


@T("text_extract_hashtags", "Извлечь #хэштеги и @упоминания", [P("text", desc="текст")], C)
def _(ctx, text): return "\n".join(sorted(set(re.findall(r"[#@][\wа-яА-Яё]+", text)))) or "не найдено"


@T("text_replace", "Замена подстроки", [P("text", desc="текст"), P("find", desc="что найти"), P("repl", desc="чем заменить")], C)
def _(ctx, text, find, repl): return text.replace(find, repl)


@T("text_replace_regex", "Замена по regex", [P("text", desc="текст"), P("pattern", desc="regex"), P("repl", desc="чем заменить")], C)
def _(ctx, text, pattern, repl): return re.sub(pattern, repl, text)


@T("text_split", "Разделить строку по разделителю (список строк)", [P("text", desc="текст"), P("sep", desc="разделитель")], C)
def _(ctx, text, sep): return "\n".join(text.split(sep))


@T("text_join", "Склеить строки списка через разделитель", [P("text", desc="строки через перенос"), P("sep", desc="разделитель")], C)
def _(ctx, text, sep): return sep.join(_lines(text))


@T("text_truncate", "Обрезать до N символов с многоточием", [P("text", desc="текст"), P("n", "integer", desc="лимит")], C)
def _(ctx, text, n): return text[:n] + ("…" if len(text) > n else "")


@T("text_pad_left", "Дополнить слева до ширины", [P("text", desc="текст"), P("width", "integer", desc="ширина"), P("ch", desc="символ", required=False, default=" ")], C)
def _(ctx, text, width, ch): return text.rjust(width, ch)


@T("text_pad_right", "Дополнить справа до ширины", [P("text", desc="текст"), P("width", "integer", desc="ширина"), P("ch", desc="символ", required=False, default=" ")], C)
def _(ctx, text, width, ch): return text.ljust(width, ch)


@T("text_repeat", "Повторить текст N раз", [P("text", desc="текст"), P("n", "integer", desc="раз")], C)
def _(ctx, text, n): return text * max(0, min(n, 1000))


@T("text_indent", "Добавить отступ каждой строке", [P("text", desc="текст"), P("prefix", desc="отступ", required=False, default="    ")], C)
def _(ctx, text, prefix): return "\n".join(prefix + l for l in _lines(text))


@T("text_wrap", "Перенос по ширине колонки", [P("text", desc="текст"), P("width", "integer", desc="ширина", required=False, default=80)], C)
def _(ctx, text, width):
    import textwrap
    return "\n".join(textwrap.fill(p, width) for p in _lines(text))


@T("text_palindrome_check", "Проверка: палиндром ли строка", [P("text", desc="текст")], C)
def _(ctx, text):
    s = re.sub(r"[^a-zа-я0-9]", "", text.lower())
    return "да" if s == s[::-1] else "нет"


@T("text_anagram_check", "Проверка: анаграммы ли две строки", [P("a", desc="строка 1"), P("b", desc="строка 2")], C)
def _(ctx, a, b):
    f = lambda s: Counter(re.sub(r"[^a-zа-я0-9]", "", s.lower()))
    return "да" if f(a) == f(b) else "нет"


@T("text_levenshtein", "Расстояние Левенштейна между строками", [P("a", desc="строка 1"), P("b", desc="строка 2")], C)
def _(ctx, a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


@T("text_contains", "Содержит ли текст подстроку (регистронезависимо)", [P("text", desc="текст"), P("needle", desc="подстрока")], C)
def _(ctx, text, needle): return "да" if needle.lower() in text.lower() else "нет"


@T("text_starts_with", "Начинается ли текст с префикса", [P("text", desc="текст"), P("prefix", desc="префикс")], C)
def _(ctx, text, prefix): return "да" if text.startswith(prefix) else "нет"


@T("text_template", "Шаблон {placeholder} -> значения из JSON", [P("template", desc="шаблон с {ключ}"), P("values_json", desc="JSON объекта")], C)
def _(ctx, template, values_json):
    import json
    return template.format(**json.loads(values_json))


@T("text_lorem", "Сгенерировать рыбный текст", [P("words", "integer", desc="число слов", required=False, default=50)], C)
def _(ctx, words):
    pool = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor "
            "incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud").split()
    return " ".join(random.choice(pool) for _ in range(max(1, words)))


@T("text_markdown_strip", "Убрать markdown-разметку", [P("text", desc="markdown")], C)
def _(ctx, text):
    s = re.sub(r"```[\s\S]*?```", lambda m: m.group(0)[3:m.group(0).rfind("```")], text)
    s = re.sub(r"[#>*_`~]+", "", s)
    return re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)


@T("text_html_strip", "Убрать HTML-теги", [P("text", desc="html")], C)
def _(ctx, text):
    import html
    return html.unescape(re.sub(r"<[^>]+>", "", text))


@T("text_initials", "Инициалы из ФИО", [P("text", desc="ФИО")], C)
def _(ctx, text): return ". ".join(p[0].upper() for p in text.split() if p) + "." if text.strip() else ""


@T("text_translit_ru_en", "Транслитерация RU->EN", [P("text", desc="текст")], C)
def _(ctx, text):
    tbl = {"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "yo", "ж": "zh",
           "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o",
           "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts",
           "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya"}
    out = []
    for ch in text:
        lc = ch.lower()
        if lc in tbl:
            tr = tbl[lc]
            out.append(tr.capitalize() if ch.isupper() else tr)
        else:
            out.append(ch)
    return "".join(out)


@T("text_word_positions", "Позиции (индексы) вхождения слова", [P("text", desc="текст"), P("word", desc="слово")], C)
def _(ctx, text, word):
    return [m.start() for m in re.finditer(re.escape(word), text, re.IGNORECASE)]
