"""Страж ПК: инвентаризация автозапуска, снятие блокировок, карантин, блокировка запуска.

ВСЕ привилегированные действия проходят через app/guard_policy.py:
запретный список (антивирусы, UAC, Winlogon, системные каталоги, удаление файлов)
-> подтверждение пользователя в окне FLUX -> аудит-лог.

Инвентаризация автозапуска — только чтение, поэтому без подтверждения. Она закрывает
«вирусы бывают разные»: смотрим не только Run-ключи, а все места, где закрепляется малварь —
планировщик, службы, WMI-подписки, IFEO-перехваты, AppInit_DLLs, Winlogon, браузерные
расширения, LSA-провайдеры и COM-hijack.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import time
from typing import Optional

from .. import winproc
from ..config import CONFIG, app_dir
from ..guard_policy import AUDIT_PATH, POLICY, TIER_DENY, check
from .registry import P, REG, ToolResult

C = "guardian"
T = REG.tool

NT = sys.platform == "win32"
MAC = sys.platform == "darwin"

# Ветки автозапуска Windows: (улей, путь, человекочитаемое имя)
RUN_KEYS = [
    ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Run", "Run (текущий пользователь)"),
    ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "RunOnce (пользователь)"),
    ("HKLM", r"Software\Microsoft\Windows\CurrentVersion\Run", "Run (все пользователи)"),
    ("HKLM", r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "RunOnce (все)"),
    ("HKLM", r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "Run (32-бит на x64)"),
    ("HKLM", r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce", "RunOnce (32-бит)"),
    ("HKCU", r"Environment", "Переменные окружения пользователя"),
    ("HKLM", r"SYSTEM\CurrentControlSet\Control\Session Manager", "BootExecute (до входа)"),
]
HIJACK_KEYS = [
    ("HKLM", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows", "AppInit_DLLs / Load"),
    ("HKLM", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon", "Winlogon (Shell/Userinit/Notify)"),
    ("HKLM", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options",
     "IFEO (перехват запуска программ)"),
    ("HKLM", r"SYSTEM\CurrentControlSet\Control\Lsa", "LSA (Security Packages / Notification)"),
    ("HKLM", r"SYSTEM\CurrentControlSet\Control\SafeBoot", "SafeBoot (что грузится в безоп. режиме)"),
    ("HKLM", r"SOFTWARE\Microsoft\Active Setup\Installed Components", "Active Setup"),
    ("HKCU", r"Software\Microsoft\Internet Explorer\UrlSearchHooks", "UrlSearchHooks"),
    ("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellServiceObjectDelayLoad",
     "ShellServiceObjectDelayLoad"),
    ("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Objects",
     "Browser Helper Objects (BHO)"),
]
RESTRICTION_KEYS = [
    (r"Software\Microsoft\Windows\CurrentVersion\Policies\System", [
        ("DisableTaskMgr", "заблокирован Диспетчер задач"),
        ("DisableRegistryTools", "заблокирован редактор реестра"),
        ("DisableLockWorkstation", "заблокирована блокировка экрана (Win+L)"),
        ("NoDispCPL", "заблокирована панель управления экраном"),
        ("DisableChangePassword", "запрещена смена пароля"),
        ("EnableLUA", "UAC (0 = ВЫКЛЮЧЕН — это дыра, должен быть 1)"),
        ("ConsentPromptBehaviorAdmin", "поведение UAC для админов"),
        ("PromptOnSecureDesktop", "UAC на защищённом рабочем столе"),
        ("NoAdminPage", "скрыта страница администраторов"),
    ]),
    (r"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer", [
        ("NoFolderOptions", "скрыт пункт «Параметры папки»"),
        ("NoRun", "заблокирован «Выполнить» (Win+R)"),
        ("NoFind", "скрыт «Поиск»"),
        ("NoControlPanel", "заблокирована Панель управления"),
        ("NoDrives", "скрыты диски"),
        ("NoViewContextMenu", "убран контекстное меню"),
        ("NoSetFolders", "скрыты настройки папок"),
        ("DisableLocalMachineRun", "отключён автозапуск Run (HKLM)"),
        ("DisableCurrentUserRun", "отключён автозапуск Run (HKCU)"),
    ]),
    (r"Software\Policies\Microsoft\Windows\System", [
        ("DisableCMD", "заблокирована командная строка"),
        ("DisablePowerShell", "заблокирован PowerShell"),
        ("DisableTaskManager", "заблокирован Диспетчер задач (политика)"),
    ]),
    (r"Software\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop", [
        ("NoChangingWallPaper", "запрещена смена обоев"),
    ]),
    (r"Software\Policies\Microsoft\Windows Defender", [
        ("DisableAntiSpyware", "ОТКЛЮЧЁН Windows Defender — критично"),
        ("DisableAntiVirus", "ОТКЛЮЧЁН антивирус Defender — критично"),
    ]),
    (r"Software\Policies\Microsoft\Windows Defender\Real-Time Protection", [
        ("DisableRealtimeMonitoring", "ОТКЛЮЧЕНА защита в реальном времени — критично"),
        ("DisableBehaviorMonitoring", "ОТКЛЮЧЕН поведенческий анализ — критично"),
    ]),
    (r"Software\Policies\Microsoft\Windows\Safer\CodeIdentifiers", [
        ("DefaultLevel", "Software Restriction Policies (блокировка запуска программ)"),
    ]),
]

# признаки вредоносного закрепления
SUSPICIOUS_DIRS = ("\\appdata\\local\\temp\\", "\\appdata\\roaming\\", "\\programdata\\",
                   "\\users\\public\\", "\\windows\\temp\\", "\\downloads\\",
                   "\\appdata\\local\\microsoft\\windows\\inetcache\\", "\\perflogs\\",
                   "/tmp/", "/var/tmp/", "/dev/shm/")
SUSPICIOUS_CMD = ("powershell -enc", "-encodedcommand", "-e jabo", "cmd /c start",
                  "mshta ", "rundll32.exe javascript", "wscript ", "cscript ",
                  "bitsadmin /transfer", "certutil -urlcache", "regsvr32 /i:http",
                  "schtasks /create", "iex(", "invoke-expression", "downloadstring",
                  "frombase64string", "-w hidden", "-windowstyle hidden")


def quarantine_dir() -> str:
    d = (CONFIG.settings.get("guard_quarantine") or "").strip()
    if not d:
        d = os.path.join(app_dir(), "data", "quarantine")
    os.makedirs(d, exist_ok=True)
    return d


def _sha256(path: str, limit_mb: int = 200) -> str:
    h = hashlib.sha256()
    try:
        if os.path.getsize(path) > limit_mb * 1048576:
            with open(path, "rb") as f:
                h.update(f.read(1048576))
            return h.hexdigest() + " (первые 1 МБ)"
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1048576), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception as e:
        return f"ошибка: {e}"


# ============================================================== Windows: реестр
def _reg_read(hive: str, path: str) -> Optional[dict]:
    if not NT:
        return None
    import winreg
    root = {"HKCU": winreg.HKEY_CURRENT_USER, "HKLM": winreg.HKEY_LOCAL_MACHINE,
            "HKU": winreg.HKEY_USERS}.get(hive.upper())
    if root is None:
        return None
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as k:
            i, vals = 0, {}
            while True:
                try:
                    name, data, typ = winreg.EnumValue(k, i)
                except OSError:
                    break
                vals[name or "(по умолчанию)"] = (data, typ)
                i += 1
            return {"path": path, "values": vals, "subkeys": []}
    except FileNotFoundError:
        return None
    except PermissionError as e:
        return {"path": path, "error": f"нет доступа: {e}", "values": {}, "subkeys": []}
    except Exception as e:
        return {"path": path, "error": f"{type(e).__name__}: {e}", "values": {}, "subkeys": []}


def _reg_subkeys(hive: str, path: str, limit: int = 200) -> list[str]:
    if not NT:
        return []
    import winreg
    root = {"HKCU": winreg.HKEY_CURRENT_USER, "HKLM": winreg.HKEY_LOCAL_MACHINE}.get(hive.upper())
    if root is None:
        return []
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as k:
            out, i = [], 0
            while i < limit:
                try:
                    out.append(winreg.EnumKey(k, i))
                except OSError:
                    break
                i += 1
            return out
    except Exception:
        return []


def _reg_delete_value(hive: str, path: str, name: str) -> str:
    if not NT:
        return "недоступно на этой ОС"
    import winreg
    root = {"HKCU": winreg.HKEY_CURRENT_USER, "HKLM": winreg.HKEY_LOCAL_MACHINE}.get(hive.upper())
    if root is None:
        return f"неизвестный улей: {hive}"
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, name)
        return "удалено"
    except FileNotFoundError:
        return "значения нет"
    except PermissionError:
        return "ОТКАЗАНО В ДОСТУПЕ (нужны права администратора)"
    except Exception as e:
        return f"{type(e).__name__}: {e}"


def _startup_folders() -> list[dict]:
    out = []
    if NT:
        cands = [
            ("Пользователь", os.path.join(os.environ.get("APPDATA", ""),
                                          r"Microsoft\Windows\Start Menu\Programs\Startup")),
            ("Все пользователи", os.path.join(os.environ.get("ProgramData", ""),
                                              r"Microsoft\Windows\Start Menu\Programs\StartUp")),
        ]
    elif MAC:
        cands = [("Пользователь", os.path.expanduser("~/Library/LaunchAgents")),
                 ("Система", "/Library/LaunchDaemons")]
    else:
        cands = [("Пользователь", os.path.expanduser("~/.config/autostart")),
                 ("Система", "/etc/xdg/autostart")]
    for label, path in cands:
        if not path or not os.path.isdir(path):
            continue
        for fn in sorted(os.listdir(path)):
            if fn.lower().startswith("desktop.ini") or fn.lower() == "desktop.ini":
                continue
            fp = os.path.join(path, fn)
            out.append({"source": f"Папка автозагрузки ({label})", "name": fn,
                        "command": fp, "path": fp})
    return out


def _scheduled_tasks() -> list[dict]:
    if not NT:
        out = []
        for exe in ("systemctl",):
            if shutil.which(exe):
                try:
                    r = winproc.run([exe, "list-unit-files", "--type=service", "--state=enabled"],
                                    timeout=20)
                    for line in (r.stdout or "").splitlines()[1:]:
                        name = line.split()[0] if line.split() else ""
                        if name and name.endswith(".service"):
                            out.append({"source": "systemd (enabled)", "name": name,
                                        "command": f"{exe} start {name}"})
                except Exception:
                    pass
        try:
            r = winproc.run(["crontab", "-l"], timeout=10)
            for line in (r.stdout or "").splitlines():
                if line.strip() and not line.startswith("#"):
                    out.append({"source": "crontab", "name": line[:60], "command": line})
        except Exception:
            pass
        return out
    try:
        r = winproc.run(["schtasks", "/query", "/fo", "CSV", "/v"], timeout=60)
        rows = (r.stdout or "").splitlines()
        if len(rows) < 2:
            return []
        import csv, io
        rdr = csv.DictReader(io.StringIO("\n".join(rows)))
        out = []
        for row in rdr:
            name = (row.get("TaskName") or "").strip()
            if not name:
                continue
            cmd = (row.get("Task To Run") or "").strip()
            status = (row.get("Status") or "").strip()
            sched = (row.get("Schedule Type") or "").strip()
            author = (row.get("Author") or "").strip()
            if not cmd or cmd.upper() in ("N/A", "НА/Д"):
                continue
            out.append({"source": f"Планировщик ({sched})", "name": name,
                        "command": cmd, "status": status, "author": author})
        return out
    except Exception:
        return []


def _services_autostart() -> list[dict]:
    if not NT:
        return []
    ps = r"""
Get-CimInstance Win32_Service -Filter "StartMode='Auto'" |
  Select-Object Name, DisplayName, PathName, State, StartMode, StartName |
  ConvertTo-Json -Compress
"""
    out = winproc.ps(ps, timeout=45)
    if not out:
        return []
    try:
        data = json.loads(out)
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    return [{"source": "Служба (автозапуск)", "name": s.get("Name", ""),
             "command": (s.get("PathName") or "").strip(),
             "display": s.get("DisplayName", ""), "state": s.get("State", ""),
             "account": s.get("StartName", "")} for s in data]


def _wmi_subscriptions() -> list[dict]:
    """WMI Event Subscription — любимый способ бессрочного закрепления малвари."""
    if not NT:
        return []
    ps = r"""
$out = @()
foreach ($cls in @('__EventFilter','CommandLineEventConsumer','ActiveScriptEventConsumer')) {
  try {
    Get-WmiObject -Namespace root\subscription -Class $cls -ErrorAction Stop | ForEach-Object {
      $out += [pscustomobject]@{ kind = $cls; name = $_.Name;
        detail = ($(if ($_.CommandLineTemplate) { $_.CommandLineTemplate }
                    elseif ($_.ScriptText) { $_.ScriptText.Substring(0, [Math]::Min(300, $_.ScriptText.Length)) }
                    elseif ($_.Query) { $_.Query } else { '' })) }
    }
  } catch {}
}
$out | ConvertTo-Json -Compress
"""
    out = winproc.ps(ps, timeout=40)
    if not out:
        return []
    try:
        data = json.loads(out)
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    return [{"source": f"WMI-подписка ({d.get('kind')})", "name": d.get("name", ""),
             "command": (d.get("detail") or "")[:300]} for d in data]


def _suspicion(command: str, path: str = "") -> list[str]:
    """Почему запись автозапуска выглядит подозрительно (эвристика, без вердикта)."""
    low = (command or "").lower()
    hits = []
    for pat in SUSPICIOUS_CMD:
        if pat in low:
            hits.append(f"команда содержит «{pat}»")
    tgt = (path or _exe_from_cmd(command)).lower().replace("/", "\\")
    for d in SUSPICIOUS_DIRS:
        if d in tgt:
            hits.append(f"исполняемый файл в подозрительном каталоге ({d.strip(chr(92))})")
    if re.search(r"[a-z0-9]{16,}\.(exe|dll|scr|com|bat|cmd|js|vbs|ps1)$", tgt):
        hits.append("имя файла похоже на случайный набор символов")
    if low.count("-") > 0 and re.search(r"(-w\s*hidden|-windowstyle\s*hidden|-nop\b|-noni\b)", low):
        hits.append("скрытый режим выполнения")
    if NT and tgt and os.path.exists(tgt):
        try:
            import ctypes
            import ctypes.wintypes
            _vlib = ctypes.windll.version
            _vlib.GetFileVersionInfoSizeW.restype = ctypes.wintypes.DWORD
            _vh = ctypes.wintypes.DWORD()
            ver = _vlib.GetFileVersionInfoSizeW(tgt, ctypes.byref(_vh))
            if ver == 0:
                hits.append("у файла нет версионной информации (нет подписи/метаданных)")
        except Exception:
            pass
    return hits[:6]


def _exe_from_cmd(command: str) -> str:
    c = (command or "").strip()
    m = re.match(r'^"([^"]+)"', c)
    if m:
        return m.group(1)
    return c.split(" ")[0] if c else ""


# ============================================================== ТУЛЗЫ: чтение
@T("guard_autostart_list",
   "ПОЛНАЯ инвентаризация автозапуска: Run/RunOnce (HKCU+HKLM+Wow6432Node), папки Startup, "
   "планировщик задач, службы с автозапуском, WMI-подписки, Winlogon, AppInit_DLLs, "
   "IFEO-перехваты, LSA, BHO, Active Setup. Только чтение — ничего не меняет. "
   "Помечает подозрительное (temp/appdata/public, скрытый PowerShell, случайные имена).",
   [P("source", desc="фильтр: run|task|service|wmi|folder|hijack|all",
      required=False, default="all", enum=["run", "task", "service", "wmi", "folder", "hijack", "all"]),
    P("suspicious_only", "boolean", desc="только с признаками вредоносности",
      required=False, default=False),
    P("limit", "integer", desc="сколько записей показать", required=False, default=120)], C, core=True)
def _(ctx, source, suspicious_only, limit):
    src = (source or "all").lower()
    items: list[dict] = []

    if src in ("all", "run", "hijack"):
        for hive, path, label in (RUN_KEYS if src != "hijack" else HIJACK_KEYS):
            d = _reg_read(hive, path)
            if not d:
                continue
            if d.get("error"):
                items.append({"source": label, "name": path, "command": "",
                              "flags": [d["error"]]})
                continue
            for name, (data, _typ) in (d.get("values") or {}).items():
                if name == "(по умолчанию)" and not str(data).strip():
                    continue
                cmd = str(data)
                items.append({"source": label, "name": name, "command": cmd[:400],
                              "reg": f"{hive}\\{path}", "value": name,
                              "flags": _suspicion(cmd)})
    if src in ("all", "hijack"):
        # IFEO: перехват запуска — Debugger у чужого образа = классика малвари
        for sk in _reg_subkeys("HKLM", HIJACK_KEYS[2][1], 400):
            d = _reg_read("HKLM", HIJACK_KEYS[2][1] + "\\" + sk)
            if not d:
                continue
            dbg = (d.get("values") or {}).get("Debugger")
            if dbg:
                items.append({"source": "IFEO (перехват запуска)", "name": sk,
                              "command": str(dbg[0])[:300],
                              "reg": f"HKLM\\{HIJACK_KEYS[2][1]}\\{sk}", "value": "Debugger",
                              "flags": ["ПЕРЕХВАТ ЗАПУСКА: вместо программы стартует Debugger"]})
    if src in ("all", "folder"):
        for f in _startup_folders():
            f["flags"] = _suspicion(f.get("command", ""), f.get("path", ""))
            items.append(f)
    if src in ("all", "task"):
        for t in _scheduled_tasks():
            t["flags"] = _suspicion(t.get("command", ""))
            items.append(t)
    if src in ("all", "service"):
        for s in _services_autostart():
            s["flags"] = _suspicion(s.get("command", ""))
            items.append(s)
    if src in ("all", "wmi"):
        for w in _wmi_subscriptions():
            w["flags"] = _suspicion(w.get("command", ""))
            w["flags"].append("WMI-подписка: редкий легитимный сценарий, частый у малвари")
            items.append(w)

    if suspicious_only:
        items = [i for i in items if i.get("flags")]
    items.sort(key=lambda i: (not i.get("flags"), i.get("source", ""), i.get("name", "")))
    if not items:
        return ("записей не найдено" + (f" (фильтр: {src})" if src != "all" else "")
                + ("" if NT else " — на этой ОС доступны только systemd/crontab/папки autostart"))

    out = [f"НАЙДЕНО {len(items)} записей автозапуска"
           + (f" · ПОДОЗРИТЕЛЬНЫХ: {sum(1 for i in items if i.get('flags'))}"
              if any(i.get("flags") for i in items) else " · подозрительных нет")]
    for i in items[: max(1, int(limit or 120))]:
        mark = "⚠ " if i.get("flags") else "  "
        out.append(f"{mark}[{i['source']}] {i['name']}")
        if i.get("command"):
            out.append(f"     {i['command'][:220]}")
        for f in i.get("flags") or []:
            out.append(f"     → {f}")
    if len(items) > int(limit or 120):
        out.append(f"… и ещё {len(items) - int(limit or 120)} (увеличь limit)")
    out.append("\nУбрать запись: guard_autostart_remove (потребует твоего подтверждения).")
    return "\n".join(out)


@T("guard_policy_status",
   "Какие ОГРАНИЧЕНИЯ Windows сейчас включены: заблокированы ли Диспетчер задач, редактор "
   "реестра, командная строка, «Выполнить», параметры папки; не отключён ли Defender/UAC. "
   "Типичная картина после заражения: малварь закрывает доступ к инструментам лечения.",
   [], C, core=True)
def _(ctx):
    if not NT:
        return ToolResult(True, "политики Windows доступны только в Windows. "
                                "На этой ОС проверяй guard_autostart_list.")
    found, clean = [], 0
    for path, values in RESTRICTION_KEYS:
        for hive in ("HKCU", "HKLM"):
            d = _reg_read(hive, path)
            if not d or d.get("error"):
                continue
            for name, meaning in values:
                if name not in (d.get("values") or {}):
                    continue
                data, _typ = d["values"][name]
                try:
                    num = int(data)
                except (TypeError, ValueError):
                    num = None
                # EnableLUA=1 и ConsentPromptBehaviorAdmin>0 — это НОРМА, а не блокировка
                if name == "EnableLUA" and num == 1:
                    clean += 1
                    continue
                if name == "ConsentPromptBehaviorAdmin" and num in (2, 5):
                    clean += 1
                    continue
                if name == "PromptOnSecureDesktop" and num == 1:
                    clean += 1
                    continue
                if name in ("DisableAntiSpyware", "DisableAntiVirus",
                            "DisableRealtimeMonitoring", "DisableBehaviorMonitoring"):
                    if num == 1:
                        found.append((f"🔴 {meaning}", hive, path, name, data))
                    else:
                        clean += 1
                    continue
                if num in (0, None):
                    clean += 1
                    continue
                level = "🔴" if name.startswith("Disable") or name.startswith("No") else "🟠"
                found.append((f"{level} {meaning}", hive, path, name, data))
    if not found:
        return ToolResult(True, f"ограничений не найдено (проверено значений: {clean}). "
                                f"Диспетчер задач, реестр и cmd доступны.",
                          data={"clean": clean})
    lines = [f"ОБНАРУЖЕНО ОГРАНИЧЕНИЙ: {len(found)} — их ставит малварь, чтобы мешать лечению:"]
    for txt, hive, path, name, data in found:
        lines.append(f"  {txt}\n     {hive}\\{path} → {name} = {data}")
    lines.append("\nСнять их: guard_policy_restore (потребует подтверждения; значения "
                 "сначала сохраняются в резервную копию и пишутся в аудит-лог).")
    return ToolResult(True, "\n".join(lines), data={"found": len(found)})


@T("guard_policy_restore",
   "СНЯТЬ блокировки Windows, которые мешают лечению: вернуть Диспетчер задач, редактор "
   "реестра, cmd, «Выполнить», параметры папки; включить Defender/UAC, если их выключили. "
   "Только УДАЛЯЕТ ограничивающие значения (и никогда не устанавливает их). "
   "Требует подтверждения пользователя.",
   [P("only", desc="taskmgr|registry|cmd|run|folders|defender|uac|all",
      required=False, default="all",
      enum=["taskmgr", "registry", "cmd", "run", "folders", "defender", "uac", "all"]),
    P("confirm_token", desc="токен подтверждения из окна FLUX", required=False, default="")],
   C, core=True)
def _(ctx, only, confirm_token):
    if not NT:
        return ToolResult(False, "доступно только в Windows")
    want = (only or "all").lower()
    groups = {"taskmgr": ("DisableTaskMgr", "DisableTaskManager"),
              "registry": ("DisableRegistryTools",),
              "cmd": ("DisableCMD", "DisablePowerShell"),
              "run": ("NoRun",),
              "folders": ("NoFolderOptions", "NoControlPanel", "NoSetFolders", "NoDispCPL"),
              "defender": ("DisableAntiSpyware", "DisableAntiVirus",
                           "DisableRealtimeMonitoring", "DisableBehaviorMonitoring"),
              "uac": ("EnableLUA",)}
    targets = set()
    if want == "all":
        for v in groups.values():
            targets |= set(v)
    else:
        targets |= set(groups.get(want, ()))
    if not targets:
        return ToolResult(False, f"неизвестная группа: {want}")

    d = check("policy_restore", f"{want}:{','.join(sorted(targets))[:200]}", confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО политикой: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "policy_restore",
                                "target": want})

    removed, backup, errors = [], [], []
    for path, _values in RESTRICTION_KEYS:
        for hive in ("HKCU", "HKLM"):
            data = _reg_read(hive, path)
            if not data or data.get("error"):
                continue
            for name in list((data.get("values") or {})):
                if name not in targets:
                    continue
                old = data["values"][name][0]
                # EnableLUA наоборот ДОЛЖЕН быть 1 — если стоит 0, это и есть поломка
                if name == "EnableLUA" and str(old) == "1":
                    continue
                res = _reg_delete_value(hive, path, name)
                rec = {"hive": hive, "path": path, "name": name, "old": str(old), "result": res}
                if res == "удалено":
                    removed.append(rec)
                elif res == "значения нет":
                    continue
                else:
                    errors.append(rec)
    try:
        bpath = os.path.join(app_dir(), "data", "guard_policy_backup.json")
        prev = []
        if os.path.exists(bpath):
            with open(bpath, "r", encoding="utf-8") as f:
                prev = json.load(f)
        prev.append({"ts": time.time(), "when": time.strftime("%Y-%m-%d %H:%M:%S"),
                     "filter": want, "removed": removed, "errors": errors})
        with open(bpath, "w", encoding="utf-8") as f:
            json.dump(prev, f, ensure_ascii=False, indent=1)
        backup = bpath
    except Exception:
        pass
    POLICY.audit("policy_restore", want, "DONE", f"снято {len(removed)} ограничений")
    if not removed and not errors:
        return ToolResult(True, f"ограничений группы «{want}» не найдено — снимать нечего.")
    out = [f"снято ограничений: {len(removed)}"]
    for r in removed:
        out.append(f"  ✓ {r['hive']}\\{r['path']} → {r['name']} (было {r['old']})")
    for e in errors:
        out.append(f"  ✗ {e['hive']}\\{e['name']}: {e['result']}")
    if backup:
        out.append(f"резервная копия прежних значений: {backup}")
    if want in ("taskmgr", "all"):
        out.append("Диспетчер задач должен открываться. Если нет — нужен запуск от "
                   "администратора (HKLM-значения).")
    return ToolResult(True, "\n".join(out), data={"removed": removed, "errors": errors})


@T("guard_process_list",
   "Запущенные процессы с признаками подозрительности: путь, подпись, родитель, командная "
   "строка. Помечает запуск из temp/appdata/public, отсутствие подписи и скрытые аргументы.",
   [P("filter", desc="фильтр по имени/пути", required=False, default=""),
    P("suspicious_only", "boolean", desc="только подозрительные", required=False, default=False),
    P("limit", "integer", desc="сколько показать", required=False, default=60)], C, core=True)
def _(ctx, filter, suspicious_only, limit):
    procs = []
    if NT:
        ps = r"""
Get-CimInstance Win32_Process |
  Select-Object ProcessId, ParentProcessId, Name, ExecutablePath, CommandLine,
                CreationDate |
  ConvertTo-Json -Compress
"""
        out = winproc.ps(ps, timeout=45)
        try:
            data = json.loads(out) if out else []
        except Exception:
            data = []
        if isinstance(data, dict):
            data = [data]
        for p in data:
            path = (p.get("ExecutablePath") or "").strip()
            cmd = (p.get("CommandLine") or "").strip()
            flags = _suspicion(cmd, path)
            procs.append({"pid": p.get("ProcessId"), "ppid": p.get("ParentProcessId"),
                          "name": p.get("Name", ""), "path": path, "command": cmd[:300],
                          "flags": flags})
    else:
        backend = ""
        if shutil.which("ps"):
            try:
                r = winproc.run(["ps", "-eo", "pid,ppid,user,args"], timeout=20)
                for line in (r.stdout or "").splitlines()[1:]:
                    parts = line.strip().split(None, 3)
                    if len(parts) < 4:
                        continue
                    pid, ppid, user, cmd = parts
                    exe = _exe_from_cmd(cmd)
                    procs.append({"pid": int(pid) if pid.isdigit() else 0, "ppid": ppid,
                                  "name": os.path.basename(exe), "path": exe,
                                  "command": cmd[:300], "user": user,
                                  "flags": _suspicion(cmd, exe)})
                backend = "ps"
            except Exception:
                procs = []
        if not procs and os.path.isdir("/proc"):
            # фолбэк: читаем /proc напрямую — работает там, где нет ps
            # (минимальные контейнеры, урезанные сборки)
            for pid in sorted(os.listdir("/proc")):
                if not pid.isdigit():
                    continue
                try:
                    with open(f"/proc/{pid}/cmdline", "rb") as f:
                        cmd = f.read().replace(b"\0", b" ").decode("utf-8", "replace").strip()
                    ppid, user = "", ""
                    with open(f"/proc/{pid}/stat", "r", encoding="utf-8", errors="replace") as f:
                        parts = f.read().rsplit(")", 1)[-1].split()
                        if len(parts) > 1:
                            ppid = parts[1]
                    try:
                        st = os.stat(f"/proc/{pid}")
                        import pwd
                        user = pwd.getpwuid(st.st_uid).pw_name
                    except Exception:
                        pass
                    try:
                        exe = os.readlink(f"/proc/{pid}/exe")
                    except OSError:
                        exe = _exe_from_cmd(cmd)
                    procs.append({"pid": int(pid), "ppid": ppid, "user": user,
                                  "name": os.path.basename(exe or cmd.split(" ")[0] or "?"),
                                  "path": exe, "command": cmd[:300],
                                  "flags": _suspicion(cmd, exe)})
                except (OSError, ValueError):
                    continue          # процесс завершился, пока мы читали
            backend = backend or "/proc"
        if not procs:
            return ToolResult(False, f"не удалось прочитать процессы (бэкенд: {backend or 'нет'})")

    if filter:
        f = filter.lower()
        procs = [p for p in procs if f in (p.get("name", "") + p.get("path", "")
                                           + p.get("command", "")).lower()]
    if suspicious_only:
        procs = [p for p in procs if p.get("flags")]
    procs.sort(key=lambda p: (not p.get("flags"), p.get("name", "").lower()))
    if not procs:
        return "процессов не найдено" + (" (подозрительных нет)" if suspicious_only else "")
    out = [f"процессов: {len(procs)} (бэкенд: {'winrm/cim' if NT else ('ps' if shutil.which('ps') and procs else '/proc')})"
           + (f" · подозрительных: {sum(1 for p in procs if p.get('flags'))}"
              if any(p.get("flags") for p in procs) else "")]
    for p in procs[: max(1, int(limit or 60))]:
        mark = "⚠ " if p.get("flags") else "  "
        out.append(f"{mark}{p['pid']:>7} {p['name'][:34]:<34} {p.get('path', '')[:80]}")
        for f in p.get("flags") or []:
            out.append(f"          → {f}")
    return "\n".join(out)


@T("guard_process_kill",
   "Завершить процесс (PID или имя). ЗАПРЕЩЕНО для антивирусов и системных компонентов — "
   "политика не даст это сделать ни в каком режиме. Требует подтверждения пользователя.",
   [P("target", desc="PID или имя процесса"),
    P("tree", "boolean", desc="завершить вместе с дочерними", required=False, default=True),
    P("confirm_token", desc="токен подтверждения из окна FLUX", required=False, default="")],
   C, core=True)
def _(ctx, target, tree, confirm_token):
    tgt = str(target or "").strip()
    if not tgt:
        return ToolResult(False, "не указан PID или имя процесса")
    d = check("process_kill", tgt, confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО политикой: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "process_kill",
                                "target": tgt})
    if NT:
        argv = ["taskkill", "/F"] + (["/T"] if tree else [])
        argv += (["/PID", tgt] if tgt.isdigit() else ["/IM", tgt])
        r = winproc.run(argv, timeout=25)
        ok = r.returncode == 0
        out = ((r.stdout or "") + (r.stderr or "")).strip()
    else:
        if tgt.isdigit():
            r = winproc.run(["kill", "-9", tgt], timeout=15)
        else:
            r = winproc.run(["pkill", "-9", "-f", tgt], timeout=15)
        ok = r.returncode == 0
        out = ((r.stdout or "") + (r.stderr or "")).strip() or ("завершено" if ok else "не найдено")
    POLICY.audit("process_kill", tgt, "DONE" if ok else "ERROR", out[:200])
    return ToolResult(ok, out[:600] or ("завершено" if ok else "не удалось"),
                      data={"target": tgt, "ok": ok})


@T("guard_file_quarantine",
   "Поместить файл в КАРАНТИН FLUX: файл ПЕРЕНОСИТСЯ (не удаляется), считается sha256, "
   "пишется журнал — его можно вернуть через guard_file_restore. Требует подтверждения. "
   "Запрещено для системных каталогов.",
   [P("path", desc="путь к файлу"),
    P("reason", desc="почему подозрителен", required=False, default=""),
    P("confirm_token", desc="токен подтверждения из окна FLUX", required=False, default="")],
   C, core=True)
def _(ctx, path, reason, confirm_token):
    src = os.path.abspath((path or "").strip().strip('"'))
    if not src or not os.path.exists(src):
        return ToolResult(False, f"файл не найден: {path}")
    if os.path.isdir(src):
        return ToolResult(False, "это каталог — карантин работает с файлами. "
                                 "Для каталога сначала guard_autostart_list/fs_tree.")
    d = check("quarantine", src, confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО политикой: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "quarantine",
                                "target": src})
    qdir = quarantine_dir()
    digest = _sha256(src)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dst = os.path.join(qdir, f"{stamp}_{os.path.basename(src)}.quarantined")
    try:
        shutil.move(src, dst)
    except PermissionError:
        POLICY.audit("quarantine", src, "ERROR", "нет прав (нужен запуск от администратора)")
        return ToolResult(False, f"нет прав на перемещение {src}. "
                                 f"Запусти FLUX от администратора или сними блокировку файла.")
    except Exception as e:
        POLICY.audit("quarantine", src, "ERROR", f"{type(e).__name__}: {e}")
        return ToolResult(False, f"не удалось переместить: {type(e).__name__}: {e}")

    journal = os.path.join(qdir, "journal.jsonl")
    rec = {"ts": time.time(), "when": time.strftime("%Y-%m-%d %H:%M:%S"),
           "original": src, "quarantined": dst, "sha256": digest,
           "size": os.path.getsize(dst), "reason": reason or ""}
    try:
        with open(journal, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
    POLICY.audit("quarantine", src, "DONE", f"sha256={digest[:16]}… -> {dst}")
    return ToolResult(True, f"в карантине: {src}\n  sha256: {digest}\n  лежит: {dst}\n"
                            f"  вернуть: guard_file_restore(path=\"{dst}\")",
                      data=rec)


@T("guard_file_restore",
   "Вернуть файл из карантина FLUX на прежнее место (по журналу карантина)",
   [P("path", desc="путь файла в карантине или sha256", required=False, default=""),
    P("confirm_token", desc="токен подтверждения", required=False, default="")], C)
def _(ctx, path, confirm_token):
    journal = os.path.join(quarantine_dir(), "journal.jsonl")
    if not os.path.exists(journal):
        return ToolResult(False, "карантин пуст")
    key = (path or "").strip().lower()
    recs = []
    with open(journal, "r", encoding="utf-8") as f:
        for line in f:
            try:
                recs.append(json.loads(line))
            except Exception:
                pass
    hit = None
    for r in reversed(recs):
        if not key or key in (r.get("quarantined", "").lower(), r.get("sha256", "").lower(),
                              r.get("original", "").lower()):
            hit = r
            break
    if not hit:
        return ToolResult(False, f"в карантине нет «{path}». Записей: {len(recs)}")
    d = check("file_restore", hit["quarantined"], confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "file_restore",
                                "target": hit["quarantined"]})
    if not os.path.exists(hit["quarantined"]):
        return ToolResult(False, f"файл карантина отсутствует: {hit['quarantined']}")
    if os.path.exists(hit["original"]):
        return ToolResult(False, f"на месте назначения уже есть файл: {hit['original']}. "
                                 f"Удали или переименуй его вручную — автоматически "
                                 f"перезаписывать не буду.")
    try:
        os.makedirs(os.path.dirname(hit["original"]), exist_ok=True)
        shutil.move(hit["quarantined"], hit["original"])
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    POLICY.audit("file_restore", hit["original"], "DONE", f"из {hit['quarantined']}")
    return ToolResult(True, f"возвращён: {hit['original']}", data=hit)


@T("guard_quarantine_list", "Что лежит в карантине FLUX (журнал с sha256 и причиной)", [], C)
def _(ctx):
    journal = os.path.join(quarantine_dir(), "journal.jsonl")
    if not os.path.exists(journal):
        return f"карантин пуст ({quarantine_dir()})"
    out = []
    with open(journal, "r", encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            alive = "есть" if os.path.exists(r.get("quarantined", "")) else "НЕТ"
            out.append(f"{r.get('when')} | {os.path.basename(r.get('original', ''))} "
                       f"| {r.get('size', 0)//1024} КБ | {alive} | {r.get('reason', '')}"
                       f"\n    {r.get('sha256', '')[:32]}…\n    было: {r.get('original')}")
    return f"карантин: {quarantine_dir()} · записей {len(out)}\n" + "\n".join(out[-40:])


@T("guard_block_launch",
   "Запретить запуск конкретной программы (IFEO Debugger). ЗАПРЕЩЕНО для системных и "
   "защитных образов — политика не даст. Требует подтверждения. Обратимо: guard_unblock_launch.",
   [P("exe", desc="имя файла (malware.exe) или полный путь"),
    P("confirm_token", desc="токен подтверждения", required=False, default="")], C)
def _(ctx, exe, confirm_token):
    name = os.path.basename((exe or "").strip().strip('"'))
    if not name.lower().endswith((".exe", ".com", ".scr", ".bat", ".cmd", ".js", ".vbs", ".ps1")):
        return ToolResult(False, f"«{name}» не похоже на исполняемый файл")
    d = check("block_launch", name, confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО политикой: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "block_launch",
                                "target": name})
    if not NT:
        return ToolResult(False, "IFEO — механизм Windows; на этой ОС используй "
                                 "guard_file_quarantine для самого файла")
    # Debugger указывает на заведомо безобидный системный процесс, который сразу выходит.
    # Это штатный механизм IFEO, он НЕ трогает сам файл и полностью обратим.
    stub = r"%SystemRoot%\System32\systray.exe"
    ok = winproc.ps_ok(
        "$k = 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\' + $a0;"
        " if (-not (Test-Path $k)) { New-Item -Path $k -Force | Out-Null };"
        " Set-ItemProperty -Path $k -Name 'Debugger' -Value $a1;"
        " Set-ItemProperty -Path $k -Name 'FluxBlockedReason' -Value $a2",
        args=[name, stub, "заблокировано FLUX " + time.strftime("%Y-%m-%d %H:%M")], timeout=25)
    POLICY.audit("block_launch", name, "DONE" if ok else "ERROR", f"IFEO Debugger={stub}")
    if not ok:
        return ToolResult(False, "не удалось записать IFEO (нужны права администратора)")
    return ToolResult(True, f"запуск «{name}» заблокирован через IFEO.\n"
                            f"Отменить: guard_unblock_launch(exe=\"{name}\")\n"
                            f"Сам файл не тронут — если он вредоносный, лучше ещё и "
                            f"guard_file_quarantine.",
                      data={"exe": name, "method": "IFEO Debugger"})


@T("guard_unblock_launch", "Снять блокировку запуска программы (удаляет IFEO Debugger)",
   [P("exe", desc="имя файла"),
    P("confirm_token", desc="токен подтверждения", required=False, default="")], C)
def _(ctx, exe, confirm_token):
    name = os.path.basename((exe or "").strip().strip('"'))
    d = check("unblock_launch", name, confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "unblock_launch",
                                "target": name})
    if not NT:
        return ToolResult(False, "доступно только в Windows")
    ok = winproc.ps_ok(
        "$k = 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\' + $a0;"
        " if (Test-Path $k) { Remove-ItemProperty -Path $k -Name 'Debugger' -ErrorAction SilentlyContinue }",
        args=[name], timeout=25)
    POLICY.audit("unblock_launch", name, "DONE" if ok else "ERROR")
    return ToolResult(ok, f"блокировка с «{name}» снята" if ok else "не удалось снять блокировку")


@T("guard_autostart_remove",
   "Удалить ЗАПИСЬ автозапуска (значение Run/RunOnce или запись в папке Startup). "
   "ЗАПРЕЩЕНО для Winlogon Shell/Userinit. Требует подтверждения. Значение предварительно "
   "сохраняется в резервную копию.",
   [P("reg_path", desc="путь реестра, например Software\\Microsoft\\Windows\\CurrentVersion\\Run"),
    P("value", desc="имя значения (имя записи автозапуска)"),
    P("hive", desc="HKCU|HKLM", required=False, default="HKCU", enum=["HKCU", "HKLM"]),
    P("confirm_token", desc="токен подтверждения", required=False, default="")], C)
def _(ctx, reg_path, value, hive, confirm_token):
    if not NT:
        return ToolResult(False, "доступно только в Windows")
    rp = (reg_path or "").strip().lstrip("\\")
    val = (value or "").strip()
    if not rp or not val:
        return ToolResult(False, "нужны reg_path и value (возьми их из guard_autostart_list)")
    target = f"{hive}\\{rp}::{val}"
    d = check("autostart_remove", target, confirm_token)
    if not d.allowed:
        if d.tier == TIER_DENY:
            return ToolResult(False, "ЗАПРЕЩЕНО политикой: " + d.reason)
        return ToolResult(False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ. " + d.reason,
                          data={"need_confirm": d.request_id, "action": "autostart_remove",
                                "target": target})
    data = _reg_read(hive, rp)
    old = None
    if data and val in (data.get("values") or {}):
        old = str(data["values"][val][0])
    res = _reg_delete_value(hive, rp, val)
    if res == "удалено" and old is not None:
        try:
            bpath = os.path.join(app_dir(), "data", "guard_autostart_backup.json")
            prev = json.load(open(bpath, encoding="utf-8")) if os.path.exists(bpath) else []
            prev.append({"ts": time.time(), "hive": hive, "path": rp, "value": val, "old": old})
            with open(bpath, "w", encoding="utf-8") as f:
                json.dump(prev, f, ensure_ascii=False, indent=1)
        except Exception:
            pass
    POLICY.audit("autostart_remove", target, "DONE" if res == "удалено" else "ERROR",
                 f"было: {old or '?'}")
    ok = res == "удалено"
    return ToolResult(ok, f"{target}: {res}" + (f"\nпрежнее значение: {old}\n"
                                                f"восстановить можно из data/"
                                                f"guard_autostart_backup.json" if ok else ""),
                      data={"target": target, "old": old, "result": res})


@T("guard_report",
   "Сводный отчёт «стража ПК»: ограничения Windows, подозрительный автозапуск, "
   "подозрительные процессы, опасные расширения браузера, состояние карантина, "
   "режим политики и последние записи аудита.",
   [P("deep", "boolean", desc="сканировать и службы/WMI/расширения (медленнее)",
      required=False, default=True)], C, core=True)
def _(ctx, deep):
    sections = []
    sections.append(f"РЕЖИМ ПОЛИТИКИ: {POLICY.mode} "
                    f"(confirm = привилегированные действия только с твоего разрешения)")
    try:
        sections.append("ОГРАНИЧЕНИЯ:\n" + REG.tools["guard_policy_status"].handler(ctx=ctx).text)
    except Exception as e:
        sections.append(f"ОГРАНИЧЕНИЯ: ошибка {e}")
    try:
        r = REG.tools["guard_autostart_list"].handler(
            ctx=ctx, source="all", suspicious_only=True, limit=25)
        sections.append("ПОДОЗРИТЕЛЬНЫЙ АВТОЗАПУСК:\n" + (r.text if hasattr(r, "text") else str(r)))
    except Exception as e:
        sections.append(f"АВТОЗАПУСК: ошибка {e}")
    try:
        r = REG.tools["guard_process_list"].handler(ctx=ctx, filter="", suspicious_only=True,
                                                    limit=20)
        sections.append("ПОДОЗРИТЕЛЬНЫЕ ПРОЦЕССЫ:\n" + (r.text if hasattr(r, "text") else str(r)))
    except Exception as e:
        sections.append(f"ПРОЦЕССЫ: ошибка {e}")
    if deep:
        try:
            r = REG.tools["ext_risk_report"].handler(ctx=ctx, min_risk=2)
            sections.append("РАСШИРЕНИЯ БРАУЗЕРА:\n" + (r.text if hasattr(r, "text") else str(r)))
        except Exception as e:
            sections.append(f"РАСШИРЕНИЯ: ошибка {e}")
    q = quarantine_dir()
    try:
        n = sum(1 for _ in open(os.path.join(q, "journal.jsonl"), encoding="utf-8")) \
            if os.path.exists(os.path.join(q, "journal.jsonl")) else 0
    except Exception:
        n = 0
    sections.append(f"КАРАНТИН: {q} · записей {n}")
    aud = POLICY.read_audit(8)
    if aud:
        sections.append("ПОСЛЕДНИЕ ДЕЙСТВИЯ СТРАЖА:\n" + "\n".join(
            f"  {a['time']} {a['action']} → {a['decision']} · {a['target'][:60]}" for a in aud))
    return "\n\n".join(sections)


@T("guard_audit_log",
   "Журнал всех привилегированных действий стража: кто, что, когда, разрешил ли пользователь, "
   "чем кончилось. Полный лог — data/guard_audit.jsonl",
   [P("limit", "integer", desc="сколько последних записей", required=False, default=40),
    P("filter", desc="фильтр по подстроке", required=False, default="")], C)
def _(ctx, limit, filter):
    recs = POLICY.read_audit(max(1, int(limit or 40)), filter or "")
    if not recs:
        return "аудит-лог пуст — привилегированных действий ещё не было"
    head = f"записей: {len(recs)} (лог: {AUDIT_PATH()})\n"
    return head + "\n".join(
        f"  {r['time']} [{r['tier']}] {r['action']} → {r['decision']}"
        f"{' (токен ' + r['token'] + ')' if r.get('token') else ''}\n"
        f"      цель: {r['target'][:110]}"
        + (f"\n      {r['detail'][:110]}" if r.get("detail") else "")
        for r in reversed(recs))
