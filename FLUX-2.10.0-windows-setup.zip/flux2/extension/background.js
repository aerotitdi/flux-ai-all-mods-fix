// FLUX Bridge: мост chrome.debugger <-> WebSocket FLUX (ws://127.0.0.1:8642/bridge)
// Работает в ЖИВОМ Chrome пользователя: без --remote-debugging-port, без рестартов.
let ws = null;
const WS_URL = 'ws://127.0.0.1:8642/bridge';

function log(...a) { console.log('[flux-bridge]', ...a); }

// keepalive: MV3 усыпляет service worker через ~30с простоя - будим себя alarms
chrome.alarms.create('flux-keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'flux-keepalive' && (!ws || ws.readyState !== 1)) { log('alarm: reconnect'); connect(); }
});
chrome.runtime.onStartup.addListener(() => connect());
chrome.runtime.onInstalled.addListener(() => connect());

function connect() {
  // дедупликация: не создаём второй сокет, если текущий ещё живёт/подключается
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) return;
  let sock;
  try { sock = new WebSocket(WS_URL); } catch (e) { setTimeout(connect, 3000); return; }
  ws = sock;   // глобально виден только этот сокет
  sock.onopen = () => {
    if (ws !== sock || sock.readyState !== WebSocket.OPEN) return;   // защита от гонки
    log('connected to FLUX');
    sock.send(JSON.stringify({ type: 'hello', name: 'flux-bridge' }));
  };
  sock.onmessage = (ev) => {
    if (ws !== sock) return;
    let d; try { d = JSON.parse(ev.data); } catch (e) { return; }
    if (d.type === 'ping') { if (sock.readyState === WebSocket.OPEN) sock.send(JSON.stringify({ type: 'pong' })); return; }
    if (d.type === 'req') handle(d);
  };
  sock.onclose = () => { if (ws === sock) { ws = null; setTimeout(connect, 3000); } };
  sock.onerror = () => { try { sock.close(); } catch (e) {} };
}
connect();

chrome.debugger.onEvent.addListener((src, method, params) => {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'event', tabId: src.tabId, method, params }));
});
chrome.debugger.onDetach.addListener((src, reason) => {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'detach', tabId: src.tabId, reason }));
});

function reply(d, result, error) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'resp', id: d.id, result: result || null, error: error || null }));
}

async function ensureAttach(tabId) {
  try { await chrome.debugger.attach({ tabId }, '1.3'); }
  catch (e) { if (!/already attached/i.test(String(e && e.message))) throw e; }
}

async function cdpCmd(tabId, method, params) {
  await ensureAttach(tabId);
  return await chrome.debugger.sendCommand({ tabId }, method, params || {});
}

async function handle(d) {
  try {
    const c = d.cmd; let r;
    if (c === 'targets') {
      const ts = await chrome.tabs.query({});
      r = ts.filter(t => t.url && !/^chrome(-extension)?:/.test(t.url))
            .map(t => ({ id: String(t.id), windowId: t.windowId, title: t.title || '', url: t.url || '', active: !!t.active }));
    } else if (c === 'windows') {
      const wins = await chrome.windows.getAll({ populate: true });
      r = wins.map(w => ({
        windowId: w.id, focused: !!w.focused,
        bounds: { left: w.left, top: w.top, width: w.width, height: w.height },
        tabs: (w.tabs || []).filter(t => t.url && !/^chrome(-extension)?:/.test(t.url))
          .map(t => ({ id: String(t.id), title: t.title || '', url: t.url || '', active: !!t.active }))
      }));
    } else if (c === 'activate') {
      const t = await chrome.tabs.get(d.tabId);
      await chrome.tabs.update(d.tabId, { active: true });
      await chrome.windows.update(t.windowId, { focused: true });
      r = { ok: true };
    } else if (c === 'close') { await chrome.tabs.remove(d.tabId); r = { ok: true }; }
    else if (c === 'new') { const t = await chrome.tabs.create({ url: d.url || 'about:blank' }); r = { id: String(t.id) }; }
    else if (c === 'navigate') { await chrome.tabs.update(d.tabId, { url: d.url }); r = { ok: true }; }
    else if (c === 'reload') { await chrome.tabs.reload(d.tabId); r = { ok: true }; }
    else if (c === 'back') { await chrome.tabs.goBack(d.tabId); r = { ok: true }; }
    else if (c === 'forward') { await chrome.tabs.goForward(d.tabId); r = { ok: true }; }
    else if (c === 'cdp') { r = await cdpCmd(d.tabId, d.method, d.params); }
    else if (c === 'winset') { await chrome.windows.update(d.windowId, d.bounds || {}); r = { ok: true }; }
    else throw new Error('unknown cmd: ' + c);
    reply(d, r, null);
  } catch (e) {
    reply(d, null, String((e && e.message) || e));
  }
}
